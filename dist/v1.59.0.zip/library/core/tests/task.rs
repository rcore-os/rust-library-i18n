use core::task::Poll;

#[test]
fn poll_const() {
    // 测试 `Poll` 的方法在 const 上下文中是否可用

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}
