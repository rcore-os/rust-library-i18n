use crate::future::Future;

/// 转换为 `Future`。
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future 完成时将产生的输出。
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// 我们要把它变成哪种 future?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// 根据一个值创建一个 future。
    #[unstable(feature = "into_future", issue = "67644")]
    #[cfg_attr(not(bootstrap), lang = "into_future")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}
