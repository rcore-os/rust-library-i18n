#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro(core_panic)]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // 根据调用者的版本扩展为 `$crate::panic::panic_2015` 或 `$crate::panic::panic_2021`。
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// 断言两个表达式彼此相等 (使用 [`PartialEq`])。
///
/// 在 panic 上，此宏将打印表达式的值及其调试表示。
///
///
/// 像 [`assert!`] 一样，此宏具有第二种形式，可以在其中提供自定义 panic 消息。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // 下面的重新借用是有意的。
                    // 如果没有它们，则即使在比较值之前，也会对借用的栈插槽进行初始化，从而导致速度明显下降。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // 下面的重新借用是有意的。
                    // 如果没有它们，则即使在比较值之前，也会对借用的栈插槽进行初始化，从而导致速度明显下降。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// 断言两个表达式彼此不相等 (使用 [`PartialEq`])。
///
/// 在 panic 上，此宏将打印表达式的值及其调试表示。
///
///
/// 像 [`assert!`] 一样，此宏具有第二种形式，可以在其中提供自定义 panic 消息。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // 下面的重新借用是有意的。
                    // 如果没有它们，则即使在比较值之前，也会对借用的栈插槽进行初始化，从而导致速度明显下降。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // 下面的重新借用是有意的。
                    // 如果没有它们，则即使在比较值之前，也会对借用的栈插槽进行初始化，从而导致速度明显下降。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// 断言表达式匹配任何给定的模式。
///
/// 像在 `match` 表达式中一样，可以在模式后跟 `if` 和可以访问由模式绑定的名称的保护表达式。
///
///
/// 在 panic 时，这个宏将打印表达式的值及其调试表示。
///
/// 像 [`assert!`] 一样，此宏具有第二种形式，可以在其中提供自定义 panic 消息。
///
/// # Examples
///
/// ```
/// #![feature(assert_matches)]
///
/// use std::assert_matches::assert_matches;
///
/// let a = 1u32.checked_add(2);
/// let b = 1u32.checked_sub(2);
/// assert_matches!(a, Some(_));
/// assert_matches!(b, None);
///
/// let c = Ok("abc".to_string());
/// assert_matches!(c, Ok(x) | Err(x) if x.len() < 100);
/// ```
///
///
#[unstable(feature = "assert_matches", issue = "82775")]
#[allow_internal_unstable(core_panic)]
#[rustc_macro_transparency = "semitransparent"]
pub macro assert_matches {
    ($left:expr, $(|)? $( $pattern:pat_param )|+ $( if $guard: expr )? $(,)?) => ({
        match $left {
            $( $pattern )|+ $( if $guard )? => {}
            ref left_val => {
                $crate::panicking::assert_matches_failed(
                    left_val,
                    $crate::stringify!($($pattern)|+ $(if $guard)?),
                    $crate::option::Option::None
                );
            }
        }
    }),
    ($left:expr, $(|)? $( $pattern:pat_param )|+ $( if $guard: expr )?, $($arg:tt)+) => ({
        match $left {
            $( $pattern )|+ $( if $guard )? => {}
            ref left_val => {
                $crate::panicking::assert_matches_failed(
                    left_val,
                    $crate::stringify!($($pattern)|+ $(if $guard)?),
                    $crate::option::Option::Some($crate::format_args!($($arg)+))
                );
            }
        }
    }),
}

/// 声明在运行时布尔表达式为 `true`。
///
/// 如果提供的表达式在运行时无法评估为 `true`，则将调用 [`panic!`] 宏。
///
/// 像 [`assert!`] 一样，此宏还具有第二个版本，可以在其中提供自定义 panic 消息。
///
/// # Uses
///
/// 与 [`assert!`] 不同，默认情况下仅在未优化的构建中启用 `debug_assert!` 语句。
/// 除非将 `-C debug-assertions` 传递给编译器，否则优化的构建将不执行 `debug_assert!` 语句。
/// 这使 `debug_assert!` 对于检查成本太高而无法在发行版本中进行检查，但在开发过程中可能很有用。
/// 扩展 `debug_assert!` 的结果始终是类型检查的。
///
/// 未检查的断言允许处于不一致状态的程序继续运行，这可能会带来意想不到的后果，但不会引入不安全性，只要这种不安全性仅在安全代码中发生即可。
///
/// 但是，断言的性能成本通常无法衡量。
/// 因此，仅在经过全面分析后才鼓励使用 `debug_assert!` 替换 [`assert!`]，更重要的是，仅使用安全代码！
///
/// # Examples
///
/// ```
/// // 这些断言的 panic 消息是给定表达式的字符串化值。
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // 一个非常简单的函数
/// debug_assert!(some_expensive_computation());
///
/// // 使用自定义消息进行断言
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
#[allow_internal_unstable(edition_panic)]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// 断言两个表达式彼此相等。
///
/// 在 panic 上，此宏将打印表达式的值及其调试表示。
///
/// 与 [`assert_eq!`] 不同，默认情况下仅在未优化的构建中启用 `debug_assert_eq!` 语句。
/// 除非将 `-C debug-assertions` 传递给编译器，否则优化的构建将不执行 `debug_assert_eq!` 语句。
/// 这使 `debug_assert_eq!` 对于检查成本太高而无法在发行版本中进行检查，但在开发过程中可能很有用。
///
/// 扩展 `debug_assert_eq!` 的结果始终是类型检查的。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// 断言两个表达式彼此不相等。
///
/// 在 panic 上，此宏将打印表达式的值及其调试表示。
///
/// 与 [`assert_ne!`] 不同，默认情况下仅在未优化的构建中启用 `debug_assert_ne!` 语句。
/// 除非将 `-C debug-assertions` 传递给编译器，否则优化的构建将不执行 `debug_assert_ne!` 语句。
/// 这使 `debug_assert_ne!` 对于检查成本太高而无法在发行版本中进行检查，但在开发过程中可能很有用。
///
/// 扩展 `debug_assert_ne!` 的结果始终是类型检查的。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// 断言表达式匹配任何给定的模式。
///
/// 像在 `match` 表达式中一样，可以在模式后跟 `if` 和可以访问由模式绑定的名称的保护表达式。
///
/// 在 panic 时，这个宏将打印表达式的值及其调试表示。
///
/// 与 [`assert_matches!`] 不同，`debug_assert_matches!` 语句默认仅在非优化构建中启用。
/// 除非将 `-C debug-assertions` 传递给编译器，否则优化的构建将不会执行 `debug_assert_matches!` 语句。
/// 这使得 `debug_assert_matches!` 可用于在发布版本中出现的检查成本太高，但在开发过程中可能会有所帮助。
///
/// 扩展 `debug_assert_matches!` 的结果总是经过类型检查。
///
/// # Examples
///
/// ```
/// #![feature(assert_matches)]
///
/// use std::assert_matches::debug_assert_matches;
///
/// let a = 1u32.checked_add(2);
/// let b = 1u32.checked_sub(2);
/// debug_assert_matches!(a, Some(_));
/// debug_assert_matches!(b, None);
///
/// let c = Ok("abc".to_string());
/// debug_assert_matches!(c, Ok(x) | Err(x) if x.len() < 100);
/// ```
///
///
///
///
#[macro_export]
#[unstable(feature = "assert_matches", issue = "82775")]
#[allow_internal_unstable(assert_matches)]
#[rustc_macro_transparency = "semitransparent"]
pub macro debug_assert_matches($($arg:tt)*) {
    if $crate::cfg!(debug_assertions) { $crate::assert_matches::assert_matches!($($arg)*); }
}

/// 返回给定表达式是否与任何给定模式匹配。
///
/// 像在 `match` 表达式中一样，可以在模式后跟 `if` 和可以访问由模式绑定的名称的保护表达式。
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $(|)? $( $pattern:pat_param )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// 解开结果或传播其错误。
///
/// 添加了 `?` 运算符来替换 `try!`，应该用它来代替。
/// 此外，`try` 是 Rust 2018 中的保留字，因此如果必须使用它，则需要使用 [raw-identifier syntax][ris]: `r#try`。
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` 匹配给定的 [`Result`]。对于 `Ok` 变体，表达式具有包装值的值。
///
/// 对于 `Err` 变体，它检索内部错误。`try!` 然后使用 `From` 执行转换。
/// 这样可以在特殊错误和更常见错误之间进行自动转换。
/// 然后立即返回产生的错误。
///
/// 由于提前返回，因此只能在返回 [`Result`] 的函数中使用 `try!`。
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // 快速返回错误的首选方法
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // 快速返回错误的先前方法
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // 这相当于：
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// 将格式化的数据写入缓冲区。
///
/// 该宏接受 'writer'，格式字符串和参数列表。
/// 参数将根据指定的格式字符串进行格式化，并将结果传递到 writer。
/// 使用 `write_fmt` 方法时，writer 可以是任何值； 通常，这来自 [`fmt::Write`] 或 [`io::Write`] trait 的实现。
/// 宏返回 `write_fmt` 方法返回的任何内容； 通常是 [`fmt::Result`] 或 [`io::Result`]。
///
/// 有关格式字符串语法的更多信息，请参见 [`std::fmt`]。
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// 模块可以同时在实现两者的对象上导入 `std::fmt::Write` 和 `std::io::Write` 以及调用 `write!`，因为对象通常不会同时实现两者。
///
/// 但是，该模块必须导入合格的 traits，以便其名称不会冲突：
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // 使用 fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // 使用 io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: 该宏也可以在 `no_std` 设置中使用。
/// 在 `no_std` 设置中，您负责组件的实现细节。
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// 将格式化的数据写入到缓冲区，并追加一个换行符。
///
/// 在所有平台上，换行符仅是 LINE FEED 字符 (`\n`/`U+000A`) (没有其他的 CARRIAGE RETURN (`\r`/`U+000D`)。
///
/// 有关更多信息，请参见 [`write!`]。有关格式字符串语法的信息，请参见 [`std::fmt`]。
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// 模块可以同时在实现两者的对象上导入 `std::fmt::Write` 和 `std::io::Write` 以及调用 `write!`，因为对象通常不会同时实现两者。
/// 但是，该模块必须导入合格的 traits，以便其名称不会冲突：
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // 使用 fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // 使用 io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// 表示无法访问的代码。
///
/// 每当编译器无法确定某些代码不可访问时，此功能就很有用。例如：
///
/// * 让分支与守卫条件匹配。
/// * 动态终止的循环。
/// * 动态终止的迭代器。
///
/// 如果确定代码不可访问不正确，则程序立即以 [`panic!`] 终止。
///
/// [`unreachable_unchecked`] 函数是该宏中不安全的副本，如果到达代码，它将导致未定义的行为。
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// 这将始终为 [`panic!`]，因为 `unreachable!` 只是 `panic!` 的简写，带有固定的、特定的消息。
///
/// 像 `panic!` 一样，此宏具有用于显示自定义值的第二种形式。
///
/// # Examples
///
/// match 分支：
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // 如果注释掉，就会编译错误
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 最差的实现之一
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!("The loop should always return");
/// }
/// ```
///
///
///
#[cfg(not(bootstrap))]
#[macro_export]
#[rustc_builtin_macro(unreachable)]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "unreachable_macro")]
macro_rules! unreachable {
    // 根据调用者的版本扩展到 `$crate::panic::unreachable_2015` 或 `$crate::panic::unreachable_2021`。
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// unreachable!() 宏
#[cfg(bootstrap)]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! unreachable {
    () => ({
        $crate::panicking::panic("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// 通过 panic 并带有 "not implemented" 的消息来指示未实现的代码。
///
/// 这允许您的代码进行类型检查，如果您正在设计原型或实现需要多个您不打算使用所有方法的特征，这将非常有用。
///
/// `unimplemented!` 和 [`todo!`] 之间的区别在于，尽管 `todo!` 传达了稍后实现该功能的意图，并且消息为 "not yet implemented"，但 `unimplemented!` 并未提出任何此类声明。
/// 它的消息是 "not implemented"。
/// 还有一些 IDE 会标记 `todo!`。
///
/// # Panics
///
/// 这将始终是 [`panic!`]，因为 `unimplemented!` 只是 `panic!` 的简写，带有固定的特定消息。
///
/// 像 `panic!` 一样，此宏具有用于显示自定义值的第二种形式。
///
/// # Examples
///
/// 假设我们有一个 `Foo` trait：
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// 我们想为 'MyStruct' 实现 `Foo`，但是由于某些原因，只有实现 `bar()` 函数才有意义。
/// `baz()` 和 `qux()` 仍然需要在我们的 `Foo` 实现中定义，但我们可以在它们的定义中使用 `unimplemented!` 来允许我们的代码编译。
///
/// 如果达到未实现的方法，我们仍然希望程序停止运行。
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` 和 `MyStruct` 没有任何意义，因此我们完全没有逻辑。
/////
///         // 这将显示 "thread 'main' panicked at 'not implemented'"。
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // 我们这里有一些逻辑，我们可以向未实现中添加一条消息！ 显示我们的遗漏。
///         // 这将显示: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'"。
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! unimplemented {
    () => ($crate::panicking::panic("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// 表示未完成的代码。
///
/// 如果您要进行原型设计并且只是在检查代码类型，这可能会很有用。
///
/// [`unimplemented!`] 和 `todo!` 之间的区别在于，尽管 `todo!` 传达了稍后实现该功能的意图，并且消息为 "not yet implemented"，但 `unimplemented!` 并未提出任何此类声明。
/// 它的消息是 "not implemented"。
/// 还有一些 IDE 会标记 `todo!`。
///
/// # Panics
///
/// 这将始终为 [`panic!`]。
///
/// # Examples
///
/// 这是一些正在进行的代码的示例。我们有一个 `Foo` trait：
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// 我们想在其中一种类型上实现 `Foo`，但我们也想首先仅在 `bar()` 上工作。为了编译我们的代码，我们需要实现 `baz()`，因此我们可以使用 `todo!`：
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // 实现在这里
///     }
///
///     fn baz(&self) {
///         // 让我们现在不必担心实现 baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // 我们甚至没有使用 baz()，所以很好。
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! todo {
    () => ($crate::panicking::panic("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// 内置宏的定义。
///
/// 宏的大多数属性 (稳定性，可见性等) 均来自此处的源代码，除了将宏输入转换为输出的扩展函数外，这些函数由编译器提供。
///
///
pub(crate) mod builtin {

    /// 导致编译失败，并遇到给定的错误消息。
    ///
    /// 当 crate 使用条件编译策略为错误条件提供更好的错误消息时，应使用此宏。
    ///
    /// 它是 [`panic!`] 的编译器级别的形式，但在 *编译* 而不是 *运行时* 会发出错误。
    ///
    /// # Examples
    ///
    /// 宏和 `#[cfg]` 环境就是两个这样的示例。
    ///
    /// 如果传递了无效值，则发出更好的编译器错误。
    /// 没有最终分支，编译器仍然会发出错误，但是错误消息不会提及两个有效值。
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ 将在编译时失败，并显示消息 "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// 如果许多特性之一不可用，则发出编译器错误。
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 构造其他字符串格式宏的参数。
    ///
    /// 此宏函数通过为每个传递的其他参数采用包含 `{}` 的格式字符串字面量来实现。
    /// `format_args!` 准备附加参数以确保输出可以解释为字符串，并将参数规范化为单一类型。
    /// 可以将实现 [`Display`] trait 的任何值传递给 `format_args!`，也可以将任何 [`Debug`] 实现的形式传递给格式化字符串中的 `{:?}`。
    ///
    ///
    /// 该宏产生 [`fmt::Arguments`] 类型的值。可以将该值传递到 [`std::fmt`] 中的宏，以执行有用的重定向。
    /// 所有其他格式化宏 ([`format!`]，[`write!`]，[`println!`] 等) 都通过此代理。
    /// `format_args!` 与其派生的宏不同，它避免了堆分配。
    ///
    /// 您可以使用 `format_args!` 在 `Debug` 和 `Display` 上下文中返回的 [`fmt::Arguments`] 值，如下所示。
    /// 该示例还显示 `Debug` 和 `Display` 的格式相同: `format_args!` 中的插值格式字符串。
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// 有关更多信息，请参见 [`std::fmt`] 中的文档。
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unsafe]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// 与 `format_args` 相同，但可以在某些 const 上下文中使用。
    ///
    /// 这个宏被 panic 宏用于 `const_panic` 特性。
    ///
    /// 一旦在 const 上下文中允许 `format_args`，这个宏将被删除。
    #[unstable(feature = "const_format_args", issue = "none")]
    #[allow_internal_unstable(fmt_internals, const_fmt_arguments_new)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! const_format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// 与 `format_args` 相同，但最后添加一个换行符。
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// 在编译时检查环境变量。
    ///
    /// 该宏将在编译时扩展为指定的环境变量的值，从而产生 `&'static str` 类型的表达式。
    ///
    ///
    /// 如果未定义环境变量，则将发出编译错误。
    /// 为了不产生编译错误，请改用 [`option_env!`] 宏。
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// 您可以通过将字符串作为第二个参数传递来自定义错误消息：
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// 如果未定义 `documentation` 环境变量，则会出现以下错误：
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// (可选) 在编译时检查环境变量。
    ///
    /// 如果在编译时存在指定的环境变量，它将扩展为 `Option<&'static str>` 类型的表达式，其值是环境变量的值的 `Some`。
    /// 如果不存在环境变量，则它将扩展为 `None`。
    /// 有关此类型的更多信息，请参见 [`Option<T>`][Option]。
    ///
    /// 使用此宏时，无论是否存在环境变量，都不会发出编译时错误。
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 将标识符串联为一个标识符。
    ///
    /// 该宏采用任意数量的逗号分隔的标识符，并将它们全部连接为一个，从而产生一个表达式，该表达式是一个新的标识符。
    /// 请注意，卫生使该宏无法捕获本地变量。
    /// 同样，作为一般规则，只允许在项，语句或表达式位置使用宏。
    /// 这意味着尽管您可以使用此宏来引用现有的变量，函数或模块等，但是您无法使用它来定义一个新的宏。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents!(new, fun, name) { } // 无法以这种方式使用！
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 将字面量连接成字节切片。
    ///
    /// 这个宏接受任意数量的逗号分隔的字面量，并将它们全部连接成一个，产生一个类型为 `&[u8, _]` 的表达式，它代表从左到右连接的所有字面量。
    /// 传递的字面量可以是以下任意组合：
    ///
    /// - 字节字面量 (`b'r'`)
    /// - 字节字符串 (`b"Rust"`)
    /// - 由字节或数字组成的数组 (`[b'A', 66, b'C']`)
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_bytes)]
    ///
    /// # fn main() {
    /// let s: &[u8; 6] = concat_bytes!(b'A', b"BC", [68, b'E', 70]);
    /// assert_eq!(s, b"ABCDEF");
    /// # }
    /// ```
    ///
    #[cfg(not(bootstrap))]
    #[unstable(feature = "concat_bytes", issue = "87555")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_bytes {
        ($($e:literal),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 将字面量串联成一个静态字符串切片。
    ///
    /// 该宏采用任意数量的逗号分隔的字面量，产生 `&'static str` 类型的表达式，该表达式表示所有从左到右串联的字面量。
    ///
    ///
    /// 将整数和浮点字面量进行字符串化以将其串联在一起。
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 扩展为在其上被调用的行号。
    ///
    /// 对于 [`column!`] 和 [`file!`]，这些宏为开发人员提供了有关源中位置的调试信息。
    ///
    /// 扩展表达式的类型为 `u32`，基于 1，因此每个文件的第一行求值为 1，第二行求值为 2，依此类推。
    /// 这与常见编译器或常用编辑器的错误消息一致。
    /// 返回的行必定是 *not*`line!` 调用本身的行，而是导致 `line!` 宏调用的第一个宏调用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// 扩展到调用它的列号。
    ///
    /// 对于 [`line!`] 和 [`file!`]，这些宏为开发人员提供了有关源中位置的调试信息。
    ///
    /// 扩展表达式的类型为 `u32`，并且基于 1，因此每行的第一列的值为 1，第二列的值为 2，依此类推。
    /// 这与常见编译器或常用编辑器的错误消息一致。
    /// 返回的列是 *not 必然*`column!` 调用本身的行，而是导致 `column!` 宏调用的第一个宏调用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    /// `column!` 计算 Unicode 代码点，而不是字节或字素。作为结果，前两次调用返回相同的值，但第三次调用没有。
    ///
    /// ```
    /// let a = ("foobar", column!()).1;
    /// let b = ("人之初性本善", column!()).1;
    /// let c = ("f̅o̅o̅b̅a̅r̅", column!()).1; // 使用组合上划线 (U+0305)
    ///
    /// assert_eq!(a, b);
    /// assert_ne!(b, c);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// 扩展为调用该文件的文件名。
    ///
    /// 对于 [`line!`] 和 [`column!`]，这些宏为开发人员提供了有关源中位置的调试信息。
    ///
    /// 扩展表达式的类型为 `&'static str`，返回的文件不是 `file!` 宏本身的调用，而是导致 `file!` 宏调用的第一个宏调用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// 对其参数进行字符串化。
    ///
    /// 该宏将产生 `&'static str` 类型的表达式，该表达式是传递给该宏的所有 tokens 的字符串化。
    /// 宏调用本身的语法没有任何限制。
    ///
    /// 请注意，输入 tokens 的扩展结果可能会在 future 中发生变化。如果您依赖输出，则应格外小心。
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// 包含 UTF-8 编码的文件作为字符串。
    ///
    /// 该文件相对于当前文件位于 (类似于查找模块的方式)。
    /// 提供的路径在编译时以特定于平台的方式进行解释。
    /// 因此，例如，使用 Windows 路径包含反斜杠 `\` 的调用将无法在 Unix 上正确编译。
    ///
    ///
    /// 该宏将产生 `&'static str` 类型的表达式，该表达式是文件的内容。
    ///
    /// # Examples
    ///
    /// 假设在同一目录中有两个文件，其内容如下：
    ///
    /// 文件 'spanish.in'：
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 文件 'main.rs'：
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 编译 'main.rs' 并运行生成的二进制文件将打印 "adiós"。
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 包含一个文件作为对字节数组的引用。
    ///
    /// 该文件相对于当前文件位于 (类似于查找模块的方式)。
    /// 提供的路径在编译时以特定于平台的方式进行解释。
    /// 因此，例如，使用 Windows 路径包含反斜杠 `\` 的调用将无法在 Unix 上正确编译。
    ///
    ///
    /// 该宏将产生 `&'static [u8; N]` 类型的表达式，该表达式是文件的内容。
    ///
    /// # Examples
    ///
    /// 假设在同一目录中有两个文件，其内容如下：
    ///
    /// 文件 'spanish.in'：
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 文件 'main.rs'：
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 编译 'main.rs' 并运行生成的二进制文件将打印 "adiós"。
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 扩展为代表当前模块路径的字符串。
    ///
    /// 当前模块路径可以被认为是引回到 crate root 的模块层次结构。
    /// 返回路径的第一部分是当前正在编译的 crate 的名称。
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// 在编译时评估配置标志的布尔组合。
    ///
    /// 除了 `#[cfg]` 属性，还提供了此宏，以允许对配置标志进行布尔表达式评估。
    /// 这通常会减少重复的代码。
    ///
    /// 该宏的语法与 [`cfg`] 属性的语法相同。
    ///
    /// `cfg!` 与 `#[cfg]` 不同，它不会删除任何代码，只会评估为 true 或 false。
    /// 例如，当将 `cfg!` 用作条件时，无论 `cfg!` 正在评估什么，if/else 表达式中的所有块都必须有效。
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// 根据上下文将文件解析为表达式或项。
    ///
    /// 该文件相对于当前文件位于 (类似于查找模块的方式)。提供的路径在编译时以特定于平台的方式进行解释。
    /// 因此，例如，使用 Windows 路径包含反斜杠 `\` 的调用将无法在 Unix 上正确编译。
    ///
    /// 使用此宏通常不是一个好主意，因为如果将文件解析为表达式，它将被不卫生地放在周围的代码中。
    /// 如果当前文件中有同名的变量或函数，这可能导致变量或函数与文件预期的不同。
    ///
    ///
    /// # Examples
    ///
    /// 假设在同一目录中有两个文件，其内容如下：
    ///
    /// 文件 'monkeys.in'：
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 文件 'main.rs'：
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 编译 'main.rs' 并运行生成的二进制文件将打印 "🙈🙊🙉🙈🙊🙉"。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 声明在运行时布尔表达式为 `true`。
    ///
    /// 如果提供的表达式在运行时无法评估为 `true`，则将调用 [`panic!`] 宏。
    ///
    /// # Uses
    ///
    /// 断言总是在调试和发行版本中被检查，并且不能被禁用。
    /// 有关默认情况下未在发行版中启用的断言，请参见 [`debug_assert!`]。
    ///
    /// 不安全的代码可能依赖 `assert!` 来强制执行运行时不变量，如果违反该规定，可能会导致不安全。
    ///
    /// `assert!` 的其他用例包括在安全代码中测试和强制执行运行时不变量 (违反该规则不会导致不安全)。
    ///
    ///
    /// # 自定义消息
    ///
    /// 此宏具有第二种形式，其中可以提供自定义 panic 消息 (带有或不带有用于格式化的参数)。
    /// 有关此格式的语法，请参见 [`std::fmt`]。
    /// 仅当断言失败时，才对用作 format 参数的表达式求值。
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // 这些断言的 panic 消息是给定表达式的字符串化值。
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // 一个非常简单的函数
    ///
    /// assert!(some_computation());
    ///
    /// // 使用自定义消息进行断言
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// LLVM 样式的内联汇编。
    ///
    /// 请阅读 [unstable 书][unstable book] 中的用法。
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_deprecated(
        since = "1.56",
        reason = "will be removed from the compiler, use asm! instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// 将传递的 tokens 打印到标准输出中。
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// 启用或禁用用于调试其他宏的跟踪功能。
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// 用于应用派生宏的属性宏。
    ///
    /// 有关详细信息，请参见 [参考][the reference]。
    ///
    /// [the reference]: ../../../reference/attributes/derive.html
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// 将属性宏应用于函数以将其转换为单元测试。
    ///
    /// 有关详细信息，请参见 [参考][the reference]。
    ///
    /// [the reference]: ../../../reference/attributes/testing.html#the-test-attribute
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// 属性宏应用于函数以将其转换为基准测试。
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` 和 `#[bench]` 宏的实现细节。
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// 将属性宏应用于静态以将其注册为分配器。
    ///
    /// 另请参见 [`std::alloc::GlobalAlloc`](../../../std/alloc/trait.GlobalAlloc.html)。
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// 如果可以访问传递的路径，则保留适用于它的项，否则将其删除。
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// 扩展其所应用的代码片段中的所有 `#[cfg]` 和 `#[cfg_attr]` 属性。
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` 编译器的不稳定实现细节，请勿使用。
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    #[doc(hidden)] // 虽然技术上稳定，但使用它是不稳定的，并且已弃用。把它隐藏起来。
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` 编译器的不稳定实现细节，请勿使用。
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    #[doc(hidden)] // 虽然技术上稳定，但使用它是不稳定的，并且已弃用。把它隐藏起来。
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}
