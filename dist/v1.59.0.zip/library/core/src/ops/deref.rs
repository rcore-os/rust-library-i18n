/// 用于不可变解引用操作，例如 `*v`。
///
/// `Deref` 除了在不可变上下文中用于 (unary) `*` 运算符的显式解引用操作外，在许多情况下，编译器都隐式使用 `Deref`。
/// 该机制称为 [`Deref` 强制多态][more]。
/// 在可变上下文中，使用 [`DerefMut`]。
///
/// 为智能指针实现 `Deref` 使得访问它们背后的数据变得方便，这就是为什么它们实现 `Deref` 的原因。
/// 另一方面，有关 `Deref` 和 [`DerefMut`] 的规则是专门为容纳智能指针而设计的。
/// 因此，`Deref` 只应为智能指针实现，以避免混淆。
///
/// 出于类似的原因，这个 trait 永远不会失败。当隐式调用 `Deref` 时，解引用过程中的失败可能会造成极大的混乱。
///
/// # 有关 `Deref` 强制多态的更多信息
///
/// 如果 `T` 实现 `Deref<Target = U>`，并且 `x` 是 `T` 类型的值，则：
///
/// * 在不可变的上下文中，`*x` (其中 `T` 既不是引用也不是裸指针) 等效于 `*Deref::deref(&x)`。
/// * `&T` 类型的值被强制为 `&U` 类型的值
/// * `T` 隐式地实现了 `U` 类型的所有 (immutable) 方法。
///
/// 有关更多详细信息，请访问 [Rust 编程语言中的章节][book] 以及 [解引用运算符][ref-deref-op]，[方法解析][method resolution] 和 [类型强制转换][type coercions] 上的引用部分。
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// 具有解引用的结构体可访问的具有单个字段的结构体。
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// 解引用后的结果类型。
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[lang = "deref_target"]
    type Target: ?Sized;

    /// 解引用值。
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_deref", issue = "88955")]
impl<T: ?Sized> const Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_deref", issue = "88955")]
impl<T: ?Sized> const Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// 用于可变解引用操作，例如在 `*v = 1;` 中。
///
/// `DerefMut` 除了可用于 (一元) `*` 运算符在可变上下文中的显式解引用操作外，还可以在许多情况下被编译器隐式使用。
/// 该机制称为 [`Deref` 强制多态][more]。
/// 在不可变的上下文中，使用 [`Deref`]。
///
/// 为智能指针实现 `DerefMut` 可以方便地对其背后的数据进行可变的，这就是为什么它们实现 `DerefMut` 的原因。
/// 另一方面，有关 [`Deref`] 和 `DerefMut` 的规则是专门为容纳智能指针而设计的。
/// 因此，`DerefMut` 仅应针对智能指针实现，以免造成混淆。
///
/// 出于类似的原因，这个 trait 永远不会失败。当隐式调用 `DerefMut` 时，解引用过程中的失败可能会非常令人困惑。
///
/// # 有关 `Deref` 强制多态的更多信息
///
/// 如果 `T` 实现 `DerefMut<Target = U>`，并且 `x` 是 `T` 类型的值，则：
///
/// * 在可变上下文中，`*x` (其中 `T` 既不是引用也不是裸指针) 等效于 `* DerefMut::deref_mut(&mut x)`。
/// * `&mut T` 类型的值被强制为 `&mut U` 类型的值
/// * `T` 隐式地实现了 `U` 类型的所有 (mutable) 方法。
///
/// 有关更多详细信息，请访问 [Rust 编程语言中的章节][book] 以及 [解引用运算符][ref-deref-op]，[方法解析][method resolution] 和 [类型强制转换][type coercions] 上的引用部分。
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// 具有单个字段的结构体，可以通过解引用该结构体进行修改。
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// 可变地解引用该值。
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// 表示可以将结构体用作方法接收器，而无需使用 `arbitrary_self_types` 特性。
///
/// 这是由 stdlib 指针类型实现的 (例如 `Box<T>`，`Rc<T>`，`&T` 和 `Pin<P>`)。
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}
