---
名称：错误报告关于：为 Rust 创建错误报告。
标签: C-bug
---
<!--
感谢您提交错误报告！ 🐛 请提供错误的简短摘要，以及您认为与复制错误相关的任何信息。

-->

我试过这个代码：

```rust
<code>
```

我希望看到这种情况发生: *解释*

相反，这发生了: *解释*

### Meta

`rustc --version --verbose`:

```
<version>
```

`crate version in Cargo.toml`:

```toml
[dependencies]
stdsimd = 
```
<!-- 如果这在 HEAD 指定 repo，请包括最新的提交。-->

<!--
如果回溯可用，请通过在您的环境中设置 `RUST_BACKTRACE=1` 在代码块中包含回溯。e.g. 
`RUST_BACKTRACE=1 cargo build`.
-->
<details><summary>Backtrace</summary>
<p>

```
<backtrace>
```

</p>
</details>
