# Rust 标准库的可移植 SIMD API
![Build Status](https://github.com/rust-lang/portable-simd/actions/workflows/ci.yml/badge.svg?branch=master)

[便携式 SIMD 项目组](https://github.com/rust-lang/project-portable-simd) 的代码仓库。
请参见 [CONTRIBUTING.md](./CONTRIBUTING.md) 了解我们的贡献指南。

这个 crate 的文档是从主分支发布的。
您可以 [在这里阅读][docs]。

如果您对 SIMD 有疑问，我们已经开始编写 [指南][simd-guide]。
我们也可以在 [Zulip][zulip-project-portable-simd] 上找到。

如果您对支持特定架构感兴趣，您可能需要 [stdarch]。

## 您好，世界

现在我们将通过一个小的 SIMD "Hello, World!" 示例深入这个世界。确保您的编译器是最新的并使用 `nightly`。我们可以通过运行来做到这一点 

```bash
rustup update -- nightly
```

或通过设置 `rustup default nightly` 或使用 `cargo +nightly {build,test,run}`。更新后运行 
```bash
cargo new hellosimd
```
创建一个新的 crate。编辑 `hellosimd/Cargo.toml` 为 
```toml
[package]
name = "hellosimd"
version = "0.1.0"
edition = "2018"
[dependencies]
core_simd = { git = "https://github.com/rust-lang/portable-simd" }
```

最后在 `src/main.rs` 中写下这个：
```rust
use core_simd::*;
fn main() {
    let a = f32x4::splat(10.0);
    let b = f32x4::from_array([1.0, 2.0, 3.0, 4.0]);
    println!("{:?}", a + b);
}
```

说明：我们使用第一行从 crate 导入所有绑定。然后，我们使用 `splat` 或 `from_array` 等方法构建我们的 SIMD vectors。最后，我们可以像 `+` 一样对它们使用相同，并且将执行适当的 SIMD 指令。当我们运行 `cargo run` 时，您应该得到 `[11.0, 12.0, 13.0, 14.0]`。

## 代码组织

目前 crate 的组织方式是每个元素类型都是一个文件，然后使用这些类型的 64 位、128 位、256 位和 512 位 vectors 包含在所述文件中。

然后将所有类型导出为单个扁平模块。

根据原始类型的大小，vector 的 lanes 数会有所不同。例如，128 位 vectors 有四个 `f32` lanes 和两个 `f64` lanes。

支持的元素类型如下：
* **浮点数：** `f32`、`f64`
* **有符号整数：** `i8`、`i16`、`i32`、`i64`、`i128`、`isize`
* **无符号整数：** `u8`、`u16`、`u32`、`u64`、`u128`、`usize`
* **掩码：** `mask8`、`mask16`、`mask32`、`mask64`、`mask128`、`masksize`

浮点数、有符号整数和无符号整数是您已经习惯的 [原始类型](https://doc.rust-lang.org/core/primitive/index.html)。
`mask` 类型是 "truthy" 值，但它们使用名称中的位数，而不是像普通 `bool` 使用的那样仅使用 1 位。

[simd-guide]: ./beginners-guide.md
[zulip-project-portable-simd]: https://rust-lang.zulipchat.com/#narrow/stream/257879-project-portable-simd
[stdarch]: https://github.com/rust-lang/stdarch
[docs]: https://rust-lang.github.io/portable-simd/core_simd
