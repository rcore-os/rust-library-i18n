//! 通过栈实现 panics 展开
//!
//! crate 是使用正在编译的平台的 "most native" 栈展开机制在 Rust 中实现 panics 的方法。
//! 目前，这实际上可分为三类：
//!
//! 1. MSVC 目标在 `seh.rs` 文件中使用 SEH。
//! 2. Emscripten 在 `emcc.rs` 文件中使用 C++ 异常。
//! 3. 所有其他目标都使用 `gcc.rs` 文件中的 libunwind/libgcc。
//!
//! 有关每种实现的更多文档可以在各自的模块中找到。
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/")]
#![feature(core_intrinsics)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![panic_runtime]
#![feature(panic_runtime)]
#![feature(c_unwind)]
// `real_imp` 未与 Miri 一起使用，因此警告是沉默的。
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_os = "solid_asp3",
        all(target_family = "unix", not(target_os = "espidf")),
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust 运行时的启动对象取决于这些符号，因此请将它们公开。
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // 不支持的目标展开。
        // - family=wasm
        // - os=none ("bare metal" targets)
        // - os=uefi
        // - os=espidf
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // 使用 Miri 运行时。
        // 我们还需要在上面加载正常的运行时，因为 rustc 希望从那里定义某些 lang 项。
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // 使用实际的运行时。
        use real_imp as imp;
    }
}

extern "C" {
    /// 当在 `catch_unwind` 之外丢弃一个 panic 对象时，libstd 中的处理程序被调用。
    ///
    fn __rust_drop_panic() -> !;

    /// 当捕获到外部异常时，将在 libstd 中调用处理程序。
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// 引发异常的入口点，仅代表特定于平台的实现。
//
#[rustc_std_internal_symbol]
pub unsafe extern "C-unwind" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}
