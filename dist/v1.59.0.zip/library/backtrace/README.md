# backtrace-rs

[Documentation](https://docs.rs/backtrace)

一个用于在运行时获取 Rust 的回溯的库。
该库旨在通过提供程序接口来增强对标准库的支持，但它也支持轻松轻松地打印当前回溯，如 libstd 的 panics。

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

要简单地捕获回溯跟踪并将其推迟到以后再处理，可以使用顶级 `Backtrace` 类型。

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

但是，如果您希望对原始的跟踪功能有更多的原始访问权限，则可以直接使用 `trace` 和 `resolve` 函数。

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // 将此指令指针解析为符号名称
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // 继续前进到下一帧
    });
}
```

# License

该项目获得以下任一许可

 * Apache 许可证，版本 2.0、([LICENSE-APACHE](LICENSE-APACHE) 或 https://www.apache.org/licenses/LICENSE-2.0)
 * MIT 许可证 ([LICENSE-MIT](LICENSE-MIT) 或 https://opensource.org/licenses/MIT)

由您选择。

### Contribution

除非您明确声明，否则 Apache-2.0 许可证中定义的由您有意提交以供包含在 backtrace-rs 中的任何贡献均应如上所述获得双重许可，且无任何其他条款或条件。
