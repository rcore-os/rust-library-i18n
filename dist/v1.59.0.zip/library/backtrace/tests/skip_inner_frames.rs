use backtrace::Backtrace;

// 该测试仅适用于具有适用于框架的 `symbol_address` 函数的平台，该框架报告符号的起始地址。
// 结果，它仅在少数平台上启用。
//
const ENABLED: bool = cfg!(all(
    // Windows 还没有真正经过测试，而且 OSX 不支持实际寻找一个封闭的框架，所以禁用这个
    //
    target_os = "linux",
    // 在 ARM 上，找到封闭的函数只是返回 ip 本身。
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}
