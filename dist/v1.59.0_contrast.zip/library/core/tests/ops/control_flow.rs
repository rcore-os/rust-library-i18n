use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // This isn't stable surface area, but helps keep `?` cheap between them, even if LLVM can't always take advantage of it right now. <br>这不是稳定的表面积，但是即使 LLVM 现在不能总是利用它，也可以使 `?` 便宜。<br>
    //
    // (Sadly Result and Option are inconsistent, so ControlFlow can't match both.) <br>(遗憾的是，结果和选项不一致，因此 ControlFlow 无法同时匹配两者。)<br>

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}
