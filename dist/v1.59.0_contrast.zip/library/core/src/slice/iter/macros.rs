//! Macros used by iterators of slice. <br>切片的迭代器使用的宏。<br>

// Inlining is_empty and len makes a huge performance difference <br>内联 is_empty 和 len 会产生巨大的性能差异<br>
macro_rules! is_empty {
    // The way we encode the length of a ZST iterator, this works both for ZST and non-ZST. <br>我们对 ZST 迭代器的长度进行编码的方式，这对 ZST 和非 ZST 均有效。<br>
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// To get rid of some bounds checks (see `position`), we compute the length in a somewhat unexpected way. <br>为了摆脱某些边界检查 (请参见 `position`)，我们以某种出乎意料的方式来计算长度。<br>
// (Tested by `codegen/slice-position-bounds-check`.) <br>(通过 `codegen/slice-position-bounds-check` 测试。)<br>
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // we're sometimes used within an unsafe block <br>我们有时会在不安全的区域内使用<br>

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // This _cannot_ use `unchecked_sub` because we depend on wrapping to represent the length of long ZST slice iterators. <br>该 _cannot_ 使用 `unchecked_sub`，因为我们依靠包装来表示长 ZST 切片迭代器的长度。<br>
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // We know that `start <= end`, so can do better than `offset_from`, which needs to deal in signed. <br>我们知道 `start <= end` 可以比需要签名处理的 `offset_from` 做得更好。<br>
            // By setting appropriate flags here we can tell LLVM this, which helps it remove bounds checks. <br>通过在此处设置适当的标志，我们可以告诉 LLVM，这有助于消除边界检查。<br>
            // SAFETY: By the type invariant, `start <= end` <br>根据类型不变量，`start <= end`<br>
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // By also telling LLVM that the pointers are apart by an exact multiple of the type size, it can optimize `len() == 0` down to `start == end` instead of `(end - start) < size`. <br>通过还告诉 LLVM 指针相隔一个类型大小的精确倍数，它可以将 `len() == 0` 优化到 `start == end`，而不是 `(end - start) < size`。<br>
            //
            // SAFETY: By the type invariant, the pointers are aligned so the distance between them must be a multiple of pointee size <br>通过类型不变，指针将对齐，因此它们之间的距离必须是指针大小的倍数<br>
            //
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// The shared definition of the `Iter` and `IterMut` iterators <br>`Iter` 和 `IterMut` 迭代器的共享定义<br>
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Returns the first element and moves the start of the iterator forwards by 1. <br>返回第一个元素，并将迭代器的开始向前移动 1。<br>
        // Greatly improves performance compared to an inlined function. <br>与内联函数相比，极大地提高了性能。<br>
        // The iterator must not be empty. <br>迭代器不能为空。<br>
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Returns the last element and moves the end of the iterator backwards by 1. <br>返回最后一个元素，并将迭代器的末尾向后移动 1。<br>
        // Greatly improves performance compared to an inlined function. <br>与内联函数相比，极大地提高了性能。<br>
        // The iterator must not be empty. <br>迭代器不能为空。<br>
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Shrinks the iterator when T is a ZST, by moving the end of the iterator backwards by `n`. <br>当 T 为 ZST 时，通过将迭代器的末尾向后移动 `n` 来缩小迭代器。<br>
        // `n` must not exceed `self.len()`. <br>`n` 不得超过 `self.len()`。<br>
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Helper function for creating a slice from the iterator. <br>用于从迭代器创建切片的 Helper 函数。<br>
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SAFETY: the iterator was created from a slice with pointer `self.ptr` and length `len!(self)`. <br>迭代器是从具有指针 `self.ptr` 和长度 `len!(self)` 的切片创建的。<br>
                // This guarantees that all the prerequisites for `from_raw_parts` are fulfilled. <br>这样可以保证满足 `from_raw_parts` 的所有先决条件。<br>
                //
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Helper function for moving the start of the iterator forwards by `offset` elements, returning the old start. <br>Helper 函数，用于通过 `offset` 元素向前移动迭代器的开始，并返回旧的开始。<br>
            //
            // Unsafe because the offset must not exceed `self.len()`. <br>不安全，因为偏移不得超过 `self.len()`。<br>
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SAFETY: the caller guarantees that `offset` doesn't exceed `self.len()`, so this new pointer is inside `self` and thus guaranteed to be non-null. <br>调用者保证 `offset` 不超过 `self.len()`，因此此新指针位于 `self` 内，因此保证为非空。<br>
                    //
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Helper function for moving the end of the iterator backwards by `offset` elements, returning the new end. <br>Helper 函数，用于通过 `offset` 元素向后移动迭代器的末尾，并返回新的末尾。<br>
            //
            // Unsafe because the offset must not exceed `self.len()`. <br>不安全，因为偏移不得超过 `self.len()`。<br>
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SAFETY: the caller guarantees that `offset` doesn't exceed `self.len()`, which is guaranteed to not overflow an `isize`. <br>调用者保证 `offset` 不超过 `self.len()`，这保证不会溢出 `isize`。<br>
                    // Also, the resulting pointer is in bounds of `slice`, which fulfills the other requirements for `offset`. <br>同样，结果指针位于 `slice` 的范围内，这满足了 `offset` 的其他要求。<br>
                    //
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // could be implemented with slices, but this avoids bounds checks <br>可以用切片实现，但这避免了边界检查<br>

                // SAFETY: `assume` calls are safe since a slice's start pointer must be non-null, and slices over non-ZSTs must also have a non-null end pointer. <br>`assume` 调用是安全的，因为切片的开始指针必须为非空，并且非 ZST 上的切片也必须具有非空的结束指针。<br>
                // The call to `next_unchecked!` is safe since we check if the iterator is empty first. <br>`next_unchecked!` 的调用是安全的，因为我们先检查迭代器是否为空。<br>
                //
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // This iterator is now empty. <br>该迭代器现在为空。<br>
                    if mem::size_of::<T>() == 0 {
                        // We have to do it this way as `ptr` may never be 0, but `end` could be (due to wrapping). <br>我们必须这样做，因为 `ptr` 可能永远不会为 0，但 `end` 可能是 (由于包装)。<br>
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SAFETY: end can't be 0 if T isn't ZST because ptr isn't 0 and end >= ptr <br>如果 T 不是 ZST，则 end 不能为 0，因为 ptr 不为 0 并且 end>=ptr<br>
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SAFETY: We are in bounds. <br>我们无所适从。<br> `post_inc_start` does the right thing even for ZSTs. <br>`post_inc_start` 甚至对 ZST 来说也做对了。<br>
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn advance_by(&mut self, n: usize) -> Result<(), usize> {
                let advance = cmp::min(len!(self), n);
                // SAFETY: By construction, `advance` does not exceed `self.len()`. <br>通过构造，`advance` 不超过 `self.len()`。<br>
                unsafe { self.post_inc_start(advance as isize) };
                if advance == n { Ok(()) } else { Err(advance) }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // We override the default implementation, which uses `try_fold`, because this simple implementation generates less LLVM IR and is faster to compile. <br>我们覆盖了使用 `try_fold` 的默认实现，因为此简单实现生成的 LLVM IR 更少，并且编译速度更快。<br>
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // We override the default implementation, which uses `try_fold`, because this simple implementation generates less LLVM IR and is faster to compile. <br>我们覆盖了使用 `try_fold` 的默认实现，因为此简单实现生成的 LLVM IR 更少，并且编译速度更快。<br>
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // We override the default implementation, which uses `try_fold`, because this simple implementation generates less LLVM IR and is faster to compile. <br>我们覆盖了使用 `try_fold` 的默认实现，因为此简单实现生成的 LLVM IR 更少，并且编译速度更快。<br>
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // We override the default implementation, which uses `try_fold`, because this simple implementation generates less LLVM IR and is faster to compile. <br>我们覆盖了使用 `try_fold` 的默认实现，因为此简单实现生成的 LLVM IR 更少，并且编译速度更快。<br>
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // We override the default implementation, which uses `try_fold`, because this simple implementation generates less LLVM IR and is faster to compile. <br>我们覆盖了使用 `try_fold` 的默认实现，因为此简单实现生成的 LLVM IR 更少，并且编译速度更快。<br>
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // We override the default implementation, which uses `try_fold`, because this simple implementation generates less LLVM IR and is faster to compile. <br>我们覆盖了使用 `try_fold` 的默认实现，因为此简单实现生成的 LLVM IR 更少，并且编译速度更快。<br>
            // Also, the `assume` avoids a bounds check. <br>另外，`assume` 避免了边界检查。<br>
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SAFETY: we are guaranteed to be in bounds by the loop invariant: <br>通过循环不变量，我们可以保证处于边界内：<br>
                        // when `i >= n`, `self.next()` returns `None` and the loop breaks. <br>当 `i >= n` 时，`self.next()` 返回 `None`，循环中断。<br>
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // We override the default implementation, which uses `try_fold`, because this simple implementation generates less LLVM IR and is faster to compile. <br>我们覆盖了使用 `try_fold` 的默认实现，因为此简单实现生成的 LLVM IR 更少，并且编译速度更快。<br>
            // Also, the `assume` avoids a bounds check. <br>另外，`assume` 避免了边界检查。<br>
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SAFETY: `i` must be lower than `n` since it starts at `n` and is only decreasing. <br>`i` 必须低于 `n`，因为它始于 `n`，并且仅在减小。<br>
                        //
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SAFETY: the caller must guarantee that `i` is in bounds of the underlying slice, so `i` cannot overflow an `isize`, and the returned references is guaranteed to refer to an element of the slice and thus guaranteed to be valid. <br>调用者必须保证 `i` 在底层切片的边界内，因此 `i` 不能溢出 `isize`，并且返回的引用保证引用切片的元素，因此保证是有效的。<br>
                //
                // Also note that the caller also guarantees that we're never called with the same index again, and that no other methods that will access this subslice are called, so it is valid for the returned reference to be mutable in the case of `IterMut` <br>还要注意，调用者也保证，我们永远不会再用相同的索引调用，并且不会调用其他访问这个子切片的方法，所以在 `IterMut` 的情况下，返回的引用是可变的是有效的<br>
                //
                //
                //
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // could be implemented with slices, but this avoids bounds checks <br>可以用切片实现，但这避免了边界检查<br>

                // SAFETY: `assume` calls are safe since a slice's start pointer must be non-null, and slices over non-ZSTs must also have a non-null end pointer. <br>`assume` 调用是安全的，因为切片的开始指针必须为非空，并且非 ZST 上的切片也必须具有非空的结束指针。<br>
                //
                // The call to `next_back_unchecked!` is safe since we check if the iterator is empty first. <br>`next_back_unchecked!` 的调用是安全的，因为我们先检查迭代器是否为空。<br>
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // This iterator is now empty. <br>该迭代器现在为空。<br>
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SAFETY: We are in bounds. <br>我们无所适从。<br> `pre_dec_end` does the right thing even for ZSTs. <br>`pre_dec_end` 即使对 ZST 来说也是正确的。<br>
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }

            #[inline]
            fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
                let advance = cmp::min(len!(self), n);
                // SAFETY: By construction, `advance` does not exceed `self.len()`. <br>通过构造，`advance` 不超过 `self.len()`。<br>
                unsafe { self.pre_dec_end(advance as isize) };
                if advance == n { Ok(()) } else { Err(advance) }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}
