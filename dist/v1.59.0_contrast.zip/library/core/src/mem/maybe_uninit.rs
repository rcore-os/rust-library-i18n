use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// A wrapper type to construct uninitialized instances of `T`. <br>包装器类型，用于创建 `T` 的未初始化实例。<br>
///
/// # Initialization invariant <br>初始化不变量<br>
///
/// The compiler, in general, assumes that a variable is properly initialized according to the requirements of the variable's type. <br>通常，编译器假定已根据变量类型的要求正确初始化了变量。<br> For example, a variable of reference type must be aligned and non-null. <br>例如，引用类型的变量必须对齐且非空。<br>
/// This is an invariant that must *always* be upheld, even in unsafe code. <br>即使在不安全的代码中，这也必须始终保持不变。<br>
/// As a consequence, zero-initializing a variable of reference type causes instantaneous [undefined behavior][ub], no matter whether that reference ever gets used to access memory: <br>因此，将引用类型的变量初始化为零会导致瞬时 [未定义的行为][ub]，无论该引用是否曾经用于访问内存：<br>
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // undefined behavior! <br>未定义的行为！<br> ⚠️
/// // The equivalent code with `MaybeUninit<&i32>`: <br>与 `MaybeUninit<&i32>` 等效的代码：<br>
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // undefined behavior! <br>未定义的行为！<br> ⚠️
/// ```
///
/// This is exploited by the compiler for various optimizations, such as eliding run-time checks and optimizing `enum` layout. <br>编译器利用这一点进行各种优化，例如取消运行时检查和优化 `enum` 布局。<br>
///
/// Similarly, entirely uninitialized memory may have any content, while a `bool` must always be `true` or `false`. <br>同样，完全未初始化的存储器可以包含任何内容，而 `bool` 必须始终为 `true` 或 `false`。<br> Hence, creating an uninitialized `bool` is undefined behavior: <br>因此，创建未初始化的 `bool` 是未定义的行为：<br>
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // undefined behavior! <br>未定义的行为！<br> ⚠️
/// // The equivalent code with `MaybeUninit<bool>`: <br>与 `MaybeUninit<bool>` 等效的代码：<br>
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // undefined behavior! <br>未定义的行为！<br> ⚠️
/// ```
///
/// Moreover, uninitialized memory is special in that it does not have a fixed value ("fixed" meaning "it won't change without being written to"). <br>此外，未初始化的存储器的特殊之处在于它没有固定的值 ("fixed" 表示 "it won't change without being written to")。<br> Reading the same uninitialized byte multiple times can give different results. <br>多次读取相同的未初始化字节会产生不同的结果。<br>
/// This makes it undefined behavior to have uninitialized data in a variable even if that variable has an integer type, which otherwise can hold any *fixed* bit pattern: <br>这使得在变量中具有未初始化的数据成为未定义的行为，即使该变量具有整数类型也可以保留任何固定位模式<br>
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // undefined behavior! <br>未定义的行为！<br> ⚠️
/// // The equivalent code with `MaybeUninit<i32>`: <br>与 `MaybeUninit<i32>` 等效的代码：<br>
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // undefined behavior! <br>未定义的行为！<br> ⚠️
/// ```
/// (Notice that the rules around uninitialized integers are not finalized yet, but until they are, it is advisable to avoid them.) <br>(请注意，关于未初始化整数的规则尚未最终确定，但是除非被确定，否则建议避免使用它们。)<br>
///
/// On top of that, remember that most types have additional invariants beyond merely being considered initialized at the type level. <br>最重要的是，请记住，大多数类型都有额外的不变量，而不仅仅是在类型级别被初始化。<br>
/// For example, a `1`-initialized [`Vec<T>`] is considered initialized (under the current implementation; this does not constitute a stable guarantee) because the only requirement the compiler knows about it is that the data pointer must be non-null. <br>例如，将 `1` 初始化的 [`Vec<T>`] 视为已初始化 (在当前实现下; 这并不构成稳定的保证)，因为编译器知道的唯一要求是数据指针必须为非空值。<br>
/// Creating such a `Vec<T>` does not cause *immediate* undefined behavior, but will cause undefined behavior with most safe operations (including dropping it). <br>创建这样的 `Vec<T>` 不会立即导致未定义的行为，但是在大多数安全操作 (包括丢弃操作) 中都将导致未定义的行为。<br>
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` serves to enable unsafe code to deal with uninitialized data. <br>`MaybeUninit<T>` 用于启用不安全代码来处理未初始化的数据。<br>
/// It is a signal to the compiler indicating that the data here might *not* be initialized: <br>这是向编译器发出的信号，指示此处的数据可能不被初始化：<br>
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Create an explicitly uninitialized reference. <br>创建一个显式未初始化的引用。<br>
/// // The compiler knows that data inside a `MaybeUninit<T>` may be invalid, and hence this is not UB: <br>编译器知道 `MaybeUninit<T>` 内部的数据可能无效，因此不是 UB：<br>
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Set it to a valid value. <br>将其设置为有效值。<br>
/// x.write(&0);
/// // Extract the initialized data -- this is only allowed *after* properly initializing `x`! <br>提取已初始化的数据 - 仅在正确初始化 `x` 之后 * 才允许这样做！<br>
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// The compiler then knows to not make any incorrect assumptions or optimizations on this code. <br>然后，编译器知道不会对此代码进行任何错误的假设或优化。<br>
///
/// You can think of `MaybeUninit<T>` as being a bit like `Option<T>` but without any of the run-time tracking and without any of the safety checks. <br>您可以认为 `MaybeUninit<T>` 有点像 `Option<T>`，但是没有任何运行时跟踪且没有任何安全检查。<br>
///
/// ## out-pointers
///
/// You can use `MaybeUninit<T>` to implement "out-pointers": instead of returning data from a function, pass it a pointer to some (uninitialized) memory to put the result into. <br>您可以使用 `MaybeUninit<T>` 来实现 "out-pointers": 与其从函数中返回数据，还不如将其传递给某个 (uninitialized) 内存的指针以将结果放入其中。<br>
/// This can be useful when it is important for the caller to control how the memory the result is stored in gets allocated, and you want to avoid unnecessary moves. <br>当对调用者来说，控制结果存储在内存中的分配方式很重要并且您希望避免不必要的移动时，这很有用。<br>
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` does not drop the old contents, which is important. <br>`write` 不丢弃旧内容，这一点很重要。<br>
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Now we know `v` is initialized! <br>现在我们知道 `v` 已初始化！<br> This also makes sure the vector gets properly dropped. <br>这也可以确保正确丢弃 vector。<br>
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initializing an array element-by-element <br>逐元素初始化数组<br>
///
/// `MaybeUninit<T>` can be used to initialize a large array element-by-element: <br>`MaybeUninit<T>` 可用于逐个元素初始化大数组：<br>
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Create an uninitialized array of `MaybeUninit`. <br>创建一个未初始化的 `MaybeUninit` 数组。<br>
///     // The `assume_init` is safe because the type we are claiming to have initialized here is a bunch of `MaybeUninit`s, which do not require initialization. <br>`assume_init` 是安全的，因为我们声称这里已经初始化的类型是一堆 `MaybeUninit`，不需要初始化。<br>
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Dropping a `MaybeUninit` does nothing. <br>丢弃 `MaybeUninit` 不会执行任何操作。<br>
///     // Thus using raw pointer assignment instead of `ptr::write` does not cause the old uninitialized value to be dropped. <br>因此，使用裸指针分配代替 `ptr::write` 不会导致旧的未初始化值被丢弃。<br>
/////
///     // Also if there is a panic during this loop, we have a memory leak, but there is no memory safety issue. <br>此外，如果在此循环期间存在 panic，则可能会发生内存泄漏，但不会出现内存安全问题。<br>
/////
///     for elem in &mut data[..] {
///         elem.write(vec![42]);
///     }
///
///     // Everything is initialized. <br>一切都已初始化。<br>
///     // Transmute the array to the initialized type. <br>将数组转换为初始化的类型。<br>
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// You can also work with partially initialized arrays, which could be found in low-level datastructures. <br>您也可以使用部分初始化的数组，这些数组可以在不稳定的数据结构中找到。<br>
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Create an uninitialized array of `MaybeUninit`. <br>创建一个未初始化的 `MaybeUninit` 数组。<br>
/// // The `assume_init` is safe because the type we are claiming to have initialized here is a bunch of `MaybeUninit`s, which do not require initialization. <br>`assume_init` 是安全的，因为我们声称这里已经初始化的类型是一堆 `MaybeUninit`，不需要初始化。<br>
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Count the number of elements we have assigned. <br>计算我们分配的元素数。<br>
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     elem.write(String::from("hello"));
///     data_len += 1;
/// }
///
/// // For each item in the array, drop if we allocated it. <br>对于数组中的每个项，如果我们分配了它，则将其丢弃。<br>
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initializing a struct field-by-field <br>逐字段初始化结构体<br>
///
/// You can use `MaybeUninit<T>`, and the [`std::ptr::addr_of_mut`] macro, to initialize structs field by field: <br>您可以使用 `MaybeUninit<T>` 和 [`std::ptr::addr_of_mut`] 宏来逐字段初始化结构体：<br>
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initializing the `name` field Using `write` instead of assignment via `=` to not call `drop` on the old, uninitialized value. <br>初始化 `name` 字段 使用 `write` 而不是通过 `=` 赋值，而不是在旧的、未初始化的值上调用 `drop`。<br>
/////
/////
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initializing the `list` field If there is a panic here, then the `String` in the `name` field leaks. <br>初始化 `list` 字段如果此处存在 panic，则 `name` 字段中的 `String` 泄漏。<br>
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // All the fields are initialized, so we call `assume_init` to get an initialized Foo. <br>所有字段都已初始化，因此我们调用 `assume_init` 来获取已初始化的 Foo。<br>
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` is guaranteed to have the same size, alignment, and ABI as `T`: <br>`MaybeUninit<T>` 保证与 `T` 具有相同的大小、对齐方式和 ABI：<br>
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// However remember that a type *containing* a `MaybeUninit<T>` is not necessarily the same layout; <br>但是请记住，*包含*`MaybeUninit<T>` 的类型不一定是相同的布局。<br> Rust does not in general guarantee that the fields of a `Foo<T>` have the same order as a `Foo<U>` even if `T` and `U` have the same size and alignment. <br>Rust 通常不保证 `Foo<T>` 的字段具有与 `Foo<U>` 相同的顺序，即使 `T` 和 `U` 具有相同的大小和对齐方式。<br>
///
/// Furthermore because any bit value is valid for a `MaybeUninit<T>` the compiler can't apply non-zero/niche-filling optimizations, potentially resulting in a larger size: <br>此外，由于任何位值对于 `MaybeUninit<T>` 都是有效的，因此编译器无法应用 non-zero/niche-filling 优化，从而可能导致更大的大小：<br>
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// If `T` is FFI-safe, then so is `MaybeUninit<T>`. <br>如果 `T` 是 FFI 安全的，则 `MaybeUninit<T>` 也是如此。<br>
///
/// While `MaybeUninit` is `#[repr(transparent)]` (indicating it guarantees the same size, alignment, and ABI as `T`), this does *not* change any of the previous caveats. <br>虽然 `MaybeUninit` 是 `#[repr(transparent)]` (表示它保证与 `T` 相同的大小，对齐方式和 ABI)，但是这 *不会* 更改任何先前的警告。<br>
/// `Option<T>` and `Option<MaybeUninit<T>>` may still have different sizes, and types containing a field of type `T` may be laid out (and sized) differently than if that field were `MaybeUninit<T>`. <br>`Option<T>` 和 `Option<MaybeUninit<T>>` 可能仍然具有不同的大小，并且包含 `T` 类型字段的类型的布局 (和大小) 可能与该字段为 `MaybeUninit<T>` 时不同。<br>
/// `MaybeUninit` is a union type, and `#[repr(transparent)]` on unions is unstable (see [the tracking issue](https://github.com/rust-lang/rust/issues/60405)). <br>`MaybeUninit` 是 union 类型，union 上的 `#[repr(transparent)]` 不稳定 (参见 [跟踪问题](https://github.com/rust-lang/rust/issues/60405)).<br>
/// Over time, the exact guarantees of `#[repr(transparent)]` on unions may evolve, and `MaybeUninit` may or may not remain `#[repr(transparent)]`. <br>随着时间的推移，对 union 的 `#[repr(transparent)]` 的确切保证可能会发生变化，并且 `MaybeUninit` 可能会或可能不会保留 `#[repr(transparent)]`。<br>
/// That said, `MaybeUninit<T>` will *always* guarantee that it has the same size, alignment, and ABI as `T`; <br>就是说，`MaybeUninit<T>` 将总是保证它具有与 `T` 有相同的大小、对齐方式和 ABI；<br> it's just that the way `MaybeUninit` implements that guarantee may evolve. <br>只是 `MaybeUninit` 实现保证的方式可能会演变。<br>
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang item so we can wrap other types in it. <br>Lang 项，因此我们可以在其中包装其他类型。<br> This is useful for generators. <br>这对于生成器很有用。<br>
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Not calling `T::clone()`, we cannot know if we are initialized enough for that. <br>不调用 `T::clone()`，我们不知道我们是否已足够初始化。<br>
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Creates a new `MaybeUninit<T>` initialized with the given value. <br>创建一个使用给定值初始化的新 `MaybeUninit<T>`。<br>
    /// It is safe to call [`assume_init`] on the return value of this function. <br>在此函数的返回值上调用 [`assume_init`] 是安全的。<br>
    ///
    /// Note that dropping a `MaybeUninit<T>` will never call `T`'s drop code. <br>注意，丢弃 `MaybeUninit<T>` 永远不会调用 T 的丢弃代码。<br>
    /// It is your responsibility to make sure `T` gets dropped if it got initialized. <br>确保 `T` 在初始化时被丢弃是您的责任。<br>
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[must_use = "use `forget` to avoid running Drop code"]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Creates a new `MaybeUninit<T>` in an uninitialized state. <br>以未初始化的状态创建一个新的 `MaybeUninit<T>`。<br>
    ///
    /// Note that dropping a `MaybeUninit<T>` will never call `T`'s drop code. <br>注意，丢弃 `MaybeUninit<T>` 永远不会调用 T 的丢弃代码。<br>
    /// It is your responsibility to make sure `T` gets dropped if it got initialized. <br>确保 `T` 在初始化时被丢弃是您的责任。<br>
    ///
    /// See the [type-level documentation][MaybeUninit] for some examples. <br>有关一些示例，请参见 [类型级文档][MaybeUninit]。<br>
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[must_use]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Create a new array of `MaybeUninit<T>` items, in an uninitialized state. <br>在未初始化状态下创建 `MaybeUninit<T>` 项的新数组。<br>
    ///
    /// Note: in a future Rust version this method may become unnecessary when Rust allows [inline const expressions](https://github.com/rust-lang/rust/issues/76001). <br>在 future Rust 版本中，当 Rust 允许 [内联常量表达式](https://github.com/rust-lang/rust/issues/76001) 时，此方法可能变得不必要。<br>
    ///
    /// The example below could then use `let mut buf = [const { MaybeUninit::<u8>::uninit() }; 32];`. <br>下面的示例可以使用 `let mut buf = [const { MaybeUninit::<u8>::uninit() }; 32];`。<br>
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Returns a (possibly smaller) slice of data that was actually read <br>返回实际读取的 (可能较小的) 数据切片<br>
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[must_use]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SAFETY: An uninitialized `[MaybeUninit<_>; LEN]` is valid. <br>未初始化的 `[MaybeUninit<_>; LEN]` 有效。<br>
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Creates a new `MaybeUninit<T>` in an uninitialized state, with the memory being filled with `0` bytes. <br>在未初始化状态下创建新的 `MaybeUninit<T>`，并用 `0` 字节填充内存。<br> It depends on `T` whether that already makes for proper initialization. <br>取决于 `T` 是否已经进行了正确的初始化。<br>
    ///
    /// For example, `MaybeUninit<usize>::zeroed()` is initialized, but `MaybeUninit<&'static i32>::zeroed()` is not because references must not be null. <br>例如，初始化 `MaybeUninit<usize>::zeroed()`，但不初始化 `MaybeUninit<&'static i32>::zeroed()`，因为引用不能为空。<br>
    ///
    /// Note that dropping a `MaybeUninit<T>` will never call `T`'s drop code. <br>注意，丢弃 `MaybeUninit<T>` 永远不会调用 T 的丢弃代码。<br>
    /// It is your responsibility to make sure `T` gets dropped if it got initialized. <br>确保 `T` 在初始化时被丢弃是您的责任。<br>
    ///
    /// # Example
    ///
    /// Correct usage of this function: initializing a struct with zero, where all fields of the struct can hold the bit-pattern 0 as a valid value. <br>此函数的正确用法：用零初始化结构体，其中结构体的所有字段都可以将位模式 0 保留为有效值。<br>
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Incorrect* usage of this function: calling `x.zeroed().assume_init()` when `0` is not a valid bit-pattern for the type: <br>该函数的 *错误* 用法：当 `0` 不是该类型的有效位模式时，调用 `x.zeroed().assume_init()`：<br>
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Inside a pair, we create a `NotZero` that does not have a valid discriminant. <br>在一个对中，我们创建一个没有有效判别式的 `NotZero`。<br>
    /// // This is undefined behavior. <br>这是未定义的行为。<br> ⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_zeroed", issue = "91850")]
    #[must_use]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub const fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SAFETY: `u.as_mut_ptr()` points to allocated memory. <br>`u.as_mut_ptr()` 指向分配的内存。<br>
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Sets the value of the `MaybeUninit<T>`. <br>设置 `MaybeUninit<T>` 的值。<br>
    ///
    /// This overwrites any previous value without dropping it, so be careful not to use this twice unless you want to skip running the destructor. <br>这将覆盖任何先前的值而不将其丢弃，因此请注意不要重复使用此两次，除非您要跳过运行析构函数。<br>
    /// For your convenience, this also returns a mutable reference to the (now safely initialized) contents of `self`. <br>为了您的方便，这也将 `self` 的内容 (现在已安全初始化) 返回变量引用。<br>
    ///
    /// As the content is stored inside a `MaybeUninit`, the destructor is not run for the inner data if the MaybeUninit leaves scope without a call to [`assume_init`], [`assume_init_drop`], or similar. <br>由于内容存储在 `MaybeUninit` 中，如果 MaybeUninit 离开作用域而没有调用到 [`assume_init`]、[`assume_init_drop`] 或类似对象，则不会为内部数据运行析构函数。<br>
    /// Code that receives the mutable reference returned by this function needs to keep this in mind. <br>接收该函数返回的可变引用的代码需要记住这一点。<br>
    /// The safety model of Rust regards leaks as safe, but they are usually still undesirable. <br>Rust 的安全模型认为泄漏是安全的，但它们通常仍然是不可取的。<br>
    /// This being said, the mutable reference behaves like any other mutable reference would, so assigning a new value to it will drop the old content. <br>话虽这么说，但借用引用与其他任何一个借用引用一样，因此为其赋予新的值将摒弃旧的内容。<br>
    ///
    /// [`assume_init`]: Self::assume_init
    /// [`assume_init_drop`]: Self::assume_init_drop
    ///
    /// # Examples
    ///
    /// Correct usage of this method: <br>正确使用此方法：<br>
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u8>>::uninit();
    ///
    /// {
    ///     let hello = x.write((&b"Hello, world!").to_vec());
    ///     // Setting hello does not leak prior allocations, but drops them <br>设置 hello 不会预先分配，但不会泄漏它们<br>
    ///     *hello = (&b"Hello").to_vec();
    ///     hello[0] = 'h' as u8;
    /// }
    /// // x is initialized now: <br>x 现在初始化：<br>
    /// let s = unsafe { x.assume_init() };
    /// assert_eq!(b"hello", s.as_slice());
    /// ```
    ///
    /// This usage of the method causes a leak: <br>该方法的这种用法会导致泄漏：<br>
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<String>::uninit();
    ///
    /// x.write("Hello".to_string());
    /// // This leaks the contained string: <br>这会泄漏包含的字符串：<br>
    /// x.write("hello".to_string());
    /// // x is initialized now: <br>x 现在初始化：<br>
    /// let s = unsafe { x.assume_init() };
    /// ```
    ///
    /// This method can be used to avoid unsafe in some cases. <br>这种方法可以用来避免在某些情况下不安全。<br> The example below shows a part of an implementation of a fixed sized arena that lends out pinned references. <br>下面的例子展示了一个固定大小的 arena 实现的一部分，它提供了固定的引用。<br>
    /// With `write`, we can avoid the need to write through a raw pointer: <br>有了 `write`，我们就可以避免通过裸指针路径来写：<br>
    ///
    /// ```rust
    /// use core::pin::Pin;
    /// use core::mem::MaybeUninit;
    ///
    /// struct PinArena<T> {
    ///     memory: Box<[MaybeUninit<T>]>,
    ///     len: usize,
    /// }
    ///
    /// impl <T> PinArena<T> {
    ///     pub fn capacity(&self) -> usize {
    ///         self.memory.len()
    ///     }
    ///     pub fn push(&mut self, val: T) -> Pin<&mut T> {
    ///         if self.len >= self.capacity() {
    ///             panic!("Attempted to push to a full pin arena!");
    ///         }
    ///         let ref_ = self.memory[self.len].write(val);
    ///         self.len += 1;
    ///         unsafe { Pin::new_unchecked(ref_) }
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit_write", since = "1.55.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_write", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SAFETY: We just initialized this value. <br>我们刚刚初始化了这个值。<br>
        unsafe { self.assume_init_mut() }
    }

    /// Gets a pointer to the contained value. <br>获取指向所包含值的指针。<br>
    /// Reading from this pointer or turning it into a reference is undefined behavior unless the `MaybeUninit<T>` is initialized. <br>除非初始化 `MaybeUninit<T>`，否则从该指针读取或将其转换为 quot 是未定义的行为。<br>
    /// Writing to memory that this pointer (non-transitively) points to is undefined behavior (except inside an `UnsafeCell<T>`). <br>写入该指针 (non-transitively) 指向的内存是未定义的行为 (`UnsafeCell<T>` 内部除外)。<br>
    ///
    /// # Examples
    ///
    /// Correct usage of this method: <br>正确使用此方法：<br>
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// x.write(vec![0, 1, 2]);
    /// // Create a reference into the `MaybeUninit<T>`. <br>在 `MaybeUninit<T>` 中创建引用。<br> This is okay because we initialized it. <br>可以，因为我们已将其初始化。<br>
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Incorrect* usage of this method: <br>这个方法的错误用法：<br>
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // We have created a reference to an uninitialized vector! <br>我们创建了对未初始化的 vector 的引用！<br> This is undefined behavior. <br>这是未定义的行为。<br> ⚠️
    /// ```
    ///
    /// (Notice that the rules around references to uninitialized data are not finalized yet, but until they are, it is advisable to avoid them.) <br>(请注意，围绕未初始化数据引用的规则尚未最终确定，但是除非被确定，否则建议避免使用它们。)<br>
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit_as_ptr", since = "1.59.0")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` and `ManuallyDrop` are both `repr(transparent)` so we can cast the pointer. <br>`MaybeUninit` 和 `ManuallyDrop` 都是 `repr(transparent)`，所以我们可以转换指针。<br>
        self as *const _ as *const T
    }

    /// Gets a mutable pointer to the contained value. <br>获取指向包含值的可变指针。<br>
    /// Reading from this pointer or turning it into a reference is undefined behavior unless the `MaybeUninit<T>` is initialized. <br>除非初始化 `MaybeUninit<T>`，否则从该指针读取或将其转换为 quot 是未定义的行为。<br>
    ///
    /// # Examples
    ///
    /// Correct usage of this method: <br>正确使用此方法：<br>
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// x.write(vec![0, 1, 2]);
    /// // Create a reference into the `MaybeUninit<Vec<u32>>`. <br>在 `MaybeUninit<Vec<u32>>` 中创建引用。<br>
    /// // This is okay because we initialized it. <br>可以，因为我们已将其初始化。<br>
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Incorrect* usage of this method: <br>这个方法的错误用法：<br>
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // We have created a reference to an uninitialized vector! <br>我们创建了对未初始化的 vector 的引用！<br> This is undefined behavior. <br>这是未定义的行为。<br> ⚠️
    /// ```
    ///
    /// (Notice that the rules around references to uninitialized data are not finalized yet, but until they are, it is advisable to avoid them.) <br>(请注意，围绕未初始化数据引用的规则尚未最终确定，但是除非被确定，否则建议避免使用它们。)<br>
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_mut_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` and `ManuallyDrop` are both `repr(transparent)` so we can cast the pointer. <br>`MaybeUninit` 和 `ManuallyDrop` 都是 `repr(transparent)`，所以我们可以转换指针。<br>
        self as *mut _ as *mut T
    }

    /// Extracts the value from the `MaybeUninit<T>` container. <br>从 `MaybeUninit<T>` 容器中提取值。<br> This is a great way to ensure that the data will get dropped, because the resulting `T` is subject to the usual drop handling. <br>这是确保数据将被丢弃的好方法，因为生成的 `T` 受到通常的丢弃处理。<br>
    ///
    /// # Safety
    ///
    /// It is up to the caller to guarantee that the `MaybeUninit<T>` really is in an initialized state. <br>取决于调用者，以确保 `MaybeUninit<T>` 确实处于初始化状态。<br> Calling this when the content is not yet fully initialized causes immediate undefined behavior. <br>在内容尚未完全初始化时调用此方法会立即导致未定义的行为。<br>
    /// The [type-level documentation][inv] contains more information about this initialization invariant. <br>[类型级文档][inv] 中包含了有关此初始化不变量的更多信息。<br>
    ///
    /// [inv]: #initialization-invariant
    ///
    /// On top of that, remember that most types have additional invariants beyond merely being considered initialized at the type level. <br>最重要的是，请记住，大多数类型都有额外的不变量，而不仅仅是在类型级别被初始化。<br>
    /// For example, a `1`-initialized [`Vec<T>`] is considered initialized (under the current implementation; this does not constitute a stable guarantee) because the only requirement the compiler knows about it is that the data pointer must be non-null. <br>例如，将 `1` 初始化的 [`Vec<T>`] 视为已初始化 (在当前实现下; 这并不构成稳定的保证)，因为编译器知道的唯一要求是数据指针必须为非空值。<br>
    ///
    /// Creating such a `Vec<T>` does not cause *immediate* undefined behavior, but will cause undefined behavior with most safe operations (including dropping it). <br>创建这样的 `Vec<T>` 不会立即导致未定义的行为，但是在大多数安全操作 (包括丢弃操作) 中都将导致未定义的行为。<br>
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Correct usage of this method: <br>正确使用此方法：<br>
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// x.write(true);
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Incorrect* usage of this method: <br>这个方法的错误用法：<br>
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` had not been initialized yet, so this last line caused undefined behavior. <br>`x` 尚未初始化，因此最后一行导致未定义的行为。<br> ⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit_assume_init", since = "1.59.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    #[track_caller]
    pub const unsafe fn assume_init(self) -> T {
        // SAFETY: the caller must guarantee that `self` is initialized. <br>调用者必须保证 `self` 已初始化。<br>
        // This also means that `self` must be a `value` variant. <br>这也意味着 `self` 必须是 `value` 变体。<br>
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Reads the value from the `MaybeUninit<T>` container. <br>从 `MaybeUninit<T>` 容器中读取值。<br> The resulting `T` is subject to the usual drop handling. <br>结果 `T` 受通常的 drop 处理影响。<br>
    ///
    /// Whenever possible, it is preferable to use [`assume_init`] instead, which prevents duplicating the content of the `MaybeUninit<T>`. <br>只要有可能，最好改用 [`assume_init`]，这样可以防止重复 `MaybeUninit<T>` 的内容。<br>
    ///
    /// # Safety
    ///
    /// It is up to the caller to guarantee that the `MaybeUninit<T>` really is in an initialized state. <br>取决于调用者，以确保 `MaybeUninit<T>` 确实处于初始化状态。<br> Calling this when the content is not yet fully initialized causes undefined behavior. <br>在内容尚未完全初始化时调用此方法会导致未定义的行为。<br>
    /// The [type-level documentation][inv] contains more information about this initialization invariant. <br>[类型级文档][inv] 中包含了有关此初始化不变量的更多信息。<br>
    ///
    /// Moreover, similar to the [`ptr::read`] function, this function creates a bitwise copy of the contents, regardless whether the contained type implements the [`Copy`] trait or not. <br>此外，类似于 [`ptr::read`] 函数，该函数创建内容的按位副本，无论所包含的类型是否实现 [`Copy`] trait。<br>
    /// When using multiple copies of the data (by calling `assume_init_read` multiple times, or first calling `assume_init_read` and then [`assume_init`]), it is your responsibility to ensure that that data may indeed be duplicated. <br>使用数据的多个副本时 (通过多次调用 `assume_init_read`，或先调用 `assume_init_read`，然后再调用 [`assume_init`])，您有责任确保确实可以复制数据。<br>
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Correct usage of this method: <br>正确使用此方法：<br>
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` is `Copy`, so we may read multiple times. <br>`u32` 是 `Copy`，因此我们可能会读取多次。<br>
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplicating a `None` value is okay, so we may read multiple times. <br>复制 `None` 值是可以的，因此我们可能会多次读取。<br>
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Incorrect* usage of this method: <br>这个方法的错误用法：<br>
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // We now created two copies of the same vector, leading to a double-free ⚠️ when they both get dropped! <br>现在，我们创建了同一 vector 的两个副本，当它们都被丢弃时，将导致双重释放！<br>
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    #[track_caller]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SAFETY: the caller must guarantee that `self` is initialized. <br>调用者必须保证 `self` 已初始化。<br>
        // Reading from `self.as_ptr()` is safe since `self` should be initialized. <br>从 `self.as_ptr()` 读取数据是安全的，因为应该初始化 `self`。<br>
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Drops the contained value in place. <br>将包含的值放置到位。<br>
    ///
    /// If you have ownership of the `MaybeUninit`, you can also use [`assume_init`] as an alternative. <br>如果您拥有 `MaybeUninit`，您也可以使用 [`assume_init`] 作为替代。<br>
    ///
    /// # Safety
    ///
    /// It is up to the caller to guarantee that the `MaybeUninit<T>` really is in an initialized state. <br>取决于调用者，以确保 `MaybeUninit<T>` 确实处于初始化状态。<br>
    /// Calling this when the content is not yet fully initialized causes undefined behavior. <br>在内容尚未完全初始化时调用此方法会导致未定义的行为。<br>
    ///
    /// On top of that, all additional invariants of the type `T` must be satisfied, as the `Drop` implementation of `T` (or its members) may rely on this. <br>最重要的是，必须满足类型 `T` 的所有附加不变量，因为 `T` (或其变体) 的 `Drop` 实现可能依赖于此。<br>
    ///
    /// For example, setting a [`Vec<T>`] to an invalid but non-null address makes it initialized (under the current implementation; <br>例如，将 [`Vec<T>`] 设置为无效但非空的地址使其初始化 (在当前实现下；<br>
    /// this does not constitute a stable guarantee), because the only requirement the compiler knows about it is that the data pointer must be non-null. <br>这并不构成稳定的保证)，因为编译器知道的唯一要求是数据指针必须非空。<br>
    /// Dropping such a `Vec<T>` however will cause undefined behaviour. <br>但是，丢弃这样的 `Vec<T>` 会导致不确定的行为。<br>
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SAFETY: the caller must guarantee that `self` is initialized and satisfies all invariants of `T`. <br>调用者必须保证 `self` 已初始化并且满足 `T` 的所有不变量。<br>
        //
        // Dropping the value in place is safe if that is the case. <br>在这种情况下，将值放到适当的位置是安全的。<br>
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Gets a shared reference to the contained value. <br>获取对包含的值的共享引用。<br>
    ///
    /// This can be useful when we want to access a `MaybeUninit` that has been initialized but don't have ownership of the `MaybeUninit` (preventing the use of `.assume_init()`). <br>当我们要访问已初始化但没有 `MaybeUninit` 所有权 (防止使用 `.assume_init()`) 的 `MaybeUninit` 时，这很有用。<br>
    ///
    /// # Safety
    ///
    /// Calling this when the content is not yet fully initialized causes undefined behavior: it is up to the caller to guarantee that the `MaybeUninit<T>` really is in an initialized state. <br>在内容尚未完全初始化时调用此方法会导致未定义的行为：取决于调用者，以确保 `MaybeUninit<T>` 确实处于初始化状态。<br>
    ///
    ///
    /// # Examples
    ///
    /// ### Correct usage of this method: <br>正确使用此方法：<br>
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialize `x`: <br>初始化 `x`：<br>
    /// x.write(vec![1, 2, 3]);
    /// // Now that our `MaybeUninit<_>` is known to be initialized, it is okay to create a shared reference to it: <br>现在已知我们的 `MaybeUninit<_>` 已初始化，可以创建对其的共享引用：<br>
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SAFETY: `x` has been initialized. <br>`x` 已初始化。<br>
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Incorrect* usages of this method: <br>这个方法的错误用法：<br>
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // We have created a reference to an uninitialized vector! <br>我们创建了对未初始化的 vector 的引用！<br> This is undefined behavior. <br>这是未定义的行为。<br> ⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialize the `MaybeUninit` using `Cell::set`: <br>使用 `Cell::set` 初始化 `MaybeUninit`：<br>
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Reference to an uninitialized `Cell<bool>`: UB! <br>引用未初始化的 `Cell<bool>`: UB!<br>
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit_ref", since = "1.55.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit_assume_init", since = "1.59.0")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SAFETY: the caller must guarantee that `self` is initialized. <br>调用者必须保证 `self` 已初始化。<br>
        // This also means that `self` must be a `value` variant. <br>这也意味着 `self` 必须是 `value` 变体。<br>
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Gets a mutable (unique) reference to the contained value. <br>获取所包含值的可变 (unique) 引用。<br>
    ///
    /// This can be useful when we want to access a `MaybeUninit` that has been initialized but don't have ownership of the `MaybeUninit` (preventing the use of `.assume_init()`). <br>当我们要访问已初始化但没有 `MaybeUninit` 所有权 (防止使用 `.assume_init()`) 的 `MaybeUninit` 时，这很有用。<br>
    ///
    /// # Safety
    ///
    /// Calling this when the content is not yet fully initialized causes undefined behavior: it is up to the caller to guarantee that the `MaybeUninit<T>` really is in an initialized state. <br>在内容尚未完全初始化时调用此方法会导致未定义的行为：取决于调用者，以确保 `MaybeUninit<T>` 确实处于初始化状态。<br>
    /// For instance, `.assume_init_mut()` cannot be used to initialize a `MaybeUninit`. <br>例如，`.assume_init_mut()` 不能用于初始化 `MaybeUninit`。<br>
    ///
    /// # Examples
    ///
    /// ### Correct usage of this method: <br>正确使用此方法：<br>
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 1024]) { *buf = [0; 1024] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes *all* the bytes of the input buffer. <br>初始化所有输入缓冲区的字节。<br>
    ///     fn initialize_buffer(buf: *mut [u8; 1024]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 1024]>::uninit();
    ///
    /// // Initialize `buf`: <br>初始化 `buf`：<br>
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Now we know that `buf` has been initialized, so we could `.assume_init()` it. <br>现在我们知道 `buf` 已被初始化，因此我们可以对其进行 `.assume_init()`。<br>
    /// // However, using `.assume_init()` may trigger a `memcpy` of the 1024 bytes. <br>但是，使用 `.assume_init()` 可能会触发 1024 字节的 `memcpy`。<br>
    /// // To assert our buffer has been initialized without copying it, we upgrade the `&mut MaybeUninit<[u8; 1024]>` to a `&mut [u8; 1024]`: <br>为了断言我们的缓冲区已经初始化而不复制它，我们将 `&mut MaybeUninit<[u8; 1024]>` 升级为 `&mut [u8; 1024]`：<br>
    /////
    /// let buf: &mut [u8; 1024] = unsafe {
    ///     // SAFETY: `buf` has been initialized. <br>`buf` 已初始化。<br>
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Now we can use `buf` as a normal slice: <br>现在我们可以将 `buf` 用作普通切片：<br>
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Incorrect* usages of this method: <br>这个方法的错误用法：<br>
    ///
    /// You cannot use `.assume_init_mut()` to initialize a value: <br>您不能使用 `.assume_init_mut()` 初始化值：<br>
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // We have created a (mutable) reference to an uninitialized `bool`! <br>我们已经创建了 (mutable) 引用未初始化的 `bool`!<br>
    ///     // This is undefined behavior. <br>这是未定义的行为。<br> ⚠️
    /// }
    /// ```
    ///
    /// For instance, you cannot [`Read`] into an uninitialized buffer: <br>例如，您不能 [`Read`] 进入未初始化的缓冲区：<br>
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) reference to uninitialized memory! <br>(mutable) 引用到未初始化的内存！<br>
    ///                             // This is undefined behavior. <br>这是未定义的行为。<br>
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Nor can you use direct field access to do field-by-field gradual initialization: <br>也不能使用直接字段访问来进行逐字段逐步初始化：<br>
    ///
    /// ```rust,no_run
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) reference to uninitialized memory! <br>(mutable) 引用到未初始化的内存！<br>
    ///                  // This is undefined behavior. <br>这是未定义的行为。<br>
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) reference to uninitialized memory! <br>(mutable) 引用到未初始化的内存！<br>
    ///                  // This is undefined behavior. <br>这是未定义的行为。<br>
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit_ref", since = "1.55.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SAFETY: the caller must guarantee that `self` is initialized. <br>调用者必须保证 `self` 已初始化。<br>
        // This also means that `self` must be a `value` variant. <br>这也意味着 `self` 必须是 `value` 变体。<br>
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extracts the values from an array of `MaybeUninit` containers. <br>从 `MaybeUninit` 容器数组中提取值。<br>
    ///
    /// # Safety
    ///
    /// It is up to the caller to guarantee that all elements of the array are in an initialized state. <br>调用者有责任保证数组的所有元素都处于初始化状态。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0].write(0);
    /// array[1].write(1);
    /// array[2].write(2);
    ///
    /// // SAFETY: Now safe as we initialised all elements <br>现在安全了，因为我们初始化了所有元素<br>
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    #[track_caller]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * The caller guarantees that all elements of the array are initialized <br>调用者保证数组的所有元素都已初始化<br>
        // * `MaybeUninit<T>` and T are guaranteed to have the same layout <br>`MaybeUninit<T>` 和 T 保证有相同的布局<br>
        // * `MaybeUninit` does not drop, so there are no double-frees And thus the conversion is safe <br>`MaybeUninit` 不丢弃，因此没有双重释放，因此转换是安全的<br>
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Assuming all the elements are initialized, get a slice to them. <br>假设所有元素都已初始化，请对其进行切片。<br>
    ///
    /// # Safety
    ///
    /// It is up to the caller to guarantee that the `MaybeUninit<T>` elements really are in an initialized state. <br>取决于调用者，以确保 `MaybeUninit<T>` 元素确实处于初始化状态。<br>
    ///
    /// Calling this when the content is not yet fully initialized causes undefined behavior. <br>在内容尚未完全初始化时调用此方法会导致未定义的行为。<br>
    ///
    /// See [`assume_init_ref`] for more details and examples. <br>有关更多详细信息和示例，请参见 [`assume_init_ref`]。<br>
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SAFETY: casting `slice` to a `*const [T]` is safe since the caller guarantees that `slice` is initialized, and `MaybeUninit` is guaranteed to have the same layout as `T`. <br>将 `slice` 转换为 `*const [T]` 是安全的，因为调用者保证 `slice` 已初始化，并且 `MaybeUninit` 保证与 `T` 具有相同的布局。<br>
        //
        // The pointer obtained is valid since it refers to memory owned by `slice` which is a reference and thus guaranteed to be valid for reads. <br>所获得的指针是有效的，因为它引用 `slice` 拥有的内存，该内存是一个引用，因此可以保证对读取有效。<br>
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Assuming all the elements are initialized, get a mutable slice to them. <br>假设所有元素都已初始化，请为其获取可变切片。<br>
    ///
    /// # Safety
    ///
    /// It is up to the caller to guarantee that the `MaybeUninit<T>` elements really are in an initialized state. <br>取决于调用者，以确保 `MaybeUninit<T>` 元素确实处于初始化状态。<br>
    ///
    /// Calling this when the content is not yet fully initialized causes undefined behavior. <br>在内容尚未完全初始化时调用此方法会导致未定义的行为。<br>
    ///
    /// See [`assume_init_mut`] for more details and examples. <br>有关更多详细信息和示例，请参见 [`assume_init_mut`]。<br>
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SAFETY: similar to safety notes for `slice_get_ref`, but we have a mutable reference which is also guaranteed to be valid for writes. <br>类似于 `slice_get_ref` 的安全说明，但我们有一个可变引用，也保证对写操作有效。<br>
        //
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Gets a pointer to the first element of the array. <br>获取指向数组第一个元素的指针。<br>
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Gets a mutable pointer to the first element of the array. <br>获取指向数组第一个元素的可变指针。<br>
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Copies the elements from `src` to `this`, returning a mutable reference to the now initialized contents of `this`. <br>从 `src` 复制元素，将 `this` 现在初始化的内容返回给 `this` 的资源引用。<br>
    ///
    /// If `T` does not implement `Copy`, use [`write_slice_cloned`] <br>如果 `T` 未实现 `Copy`，请使用 [`write_slice_cloned`]<br>
    ///
    /// This is similar to [`slice::copy_from_slice`]. <br>这类似于 [`slice::copy_from_slice`]。<br>
    ///
    /// # Panics
    ///
    /// This function will panic if the two slices have different lengths. <br>如果两个切片的长度不同，则此函数将为 panic。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: we have just copied all the elements of len into the spare capacity the first src.len() elements of the vec are valid now. <br>我们刚刚将 len 的所有元素复制到了备用容量中，vec 的第一个 src.len() 元素现在有效。<br>
    /////
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SAFETY: &[T] and &[MaybeUninit<T>] have the same layout <br>&[T] and &[MaybeUninit<T>] 具有相同的布局<br>
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SAFETY: Valid elements have just been copied into `this` so it is initialized <br>有效元素刚刚被复制到 `this` 中，因此它被初始化<br>
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clones the elements from `src` to `this`, returning a mutable reference to the now initialized contents of `this`. <br>将元素从 `src` 克隆到 `this`，返回对 `this` 现在初始化内容的可变引用。<br>
    /// Any already initialized elements will not be dropped. <br>任何已经初始化的元素都不会被丢弃。<br>
    ///
    /// If `T` implements `Copy`, use [`write_slice`] <br>如果 `T` 实现 `Copy`，请使用 [`write_slice`]<br>
    ///
    /// This is similar to [`slice::clone_from_slice`] but does not drop existing elements. <br>这类似于 [`slice::clone_from_slice`]，但不会丢弃现有元素。<br>
    ///
    /// # Panics
    ///
    /// This function will panic if the two slices have different lengths, or if the implementation of `Clone` panics. <br>如果两个切片的长度不同，或者 `Clone` panics 的实现，则此函数将为 panic。<br>
    ///
    /// If there is a panic, the already cloned elements will be dropped. <br>如果存在 panic，将丢弃已经克隆的元素。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: we have just cloned all the elements of len into the spare capacity the first src.len() elements of the vec are valid now. <br>我们刚刚将 len 的所有元素克隆到了备用容量中，vec 的第一个 src.len() 元素现在有效。<br>
    /////
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // unlike copy_from_slice this does not call clone_from_slice on the slice this is because `MaybeUninit<T: Clone>` does not implement Clone. <br>与 copy_from_slice 不同，这不会在切片上调用 clone_from_slice，这是因为 `MaybeUninit<T: Clone>` 没有实现 Clone。<br>
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SAFETY: this raw slice will contain only initialized objects that's why, it is allowed to drop it. <br>此原始切片将仅包含初始化的对象，这就是为什么允许将其丢弃。<br>
                //
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: We need to explicitly slice them to the same length for bounds checking to be elided, and the optimizer will generate memcpy for simple cases (for example T = u8). <br>我们需要显式地将它们切成相同的长度，以消除边界检查，优化器将为简单情况生成 memcpy (例如 T= u8)。<br>
        //
        //
        let len = this.len();
        let src = &src[..len];

        // guard is needed b/c panic might happen during a clone <br>需要保护 b/c 在克隆过程中可能会发生 panic<br>
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SAFETY: Valid elements have just been written into `this` so it is initialized <br>有效元素刚刚被写入 `this`，因此它被初始化<br>
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}
