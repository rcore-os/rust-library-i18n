//! Constants for the 64-bit unsigned integer type. <br>64 位无符号整数类型的常量。<br>
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! New code should use the associated constants directly on the primitive type. <br>新代码应直接在原始类型上使用关联的常量。<br>

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }
