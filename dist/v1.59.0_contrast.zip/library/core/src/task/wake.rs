#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` allows the implementor of a task executor to create a [`Waker`] which provides customized wakeup behavior. <br>`RawWaker` 允许任务执行器的实现者创建 [`Waker`]，该 [`Waker`] 提供自定义的唤醒行为。<br>
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// It consists of a data pointer and a [virtual function pointer table (vtable)][vtable] that customizes the behavior of the `RawWaker`. <br>它由一个数据指针和一个自定义 `RawWaker` 行为的 [虚函数指针表 (vtable)][vtable] 组成。<br>
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// A data pointer, which can be used to store arbitrary data as required by the executor. <br>数据指针，可用于根据执行程序的要求存储任意数据。<br>
    /// This could be e.g. <br>这可能是，例如<br>
    /// a type-erased pointer to an `Arc` that is associated with the task. <br>指向与任务关联的 `Arc` 的类型擦除的指针。<br>
    /// The value of this field gets passed to all functions that are part of the vtable as the first parameter. <br>该字段的值作为第一个参数传递给 vtable 一部分的所有函数。<br>
    ///
    data: *const (),
    /// Virtual function pointer table that customizes the behavior of this waker. <br>虚拟函数指针表，可自定义此唤醒程序的行为。<br>
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Creates a new `RawWaker` from the provided `data` pointer and `vtable`. <br>根据提供的 `data` 指针和 `vtable` 创建新的 `RawWaker`。<br>
    ///
    /// The `data` pointer can be used to store arbitrary data as required by the executor. <br>`data` 指针可用于存储执行程序所需的任意数据。<br> This could be e.g. <br>这可能是，例如<br>
    /// a type-erased pointer to an `Arc` that is associated with the task. <br>指向与任务关联的 `Arc` 的类型擦除的指针。<br>
    /// The value of this pointer will get passed to all functions that are part of the `vtable` as the first parameter. <br>该指针的值将作为第一个参数传递给 `vtable` 一部分的所有函数。<br>
    ///
    /// The `vtable` customizes the behavior of a `Waker` which gets created from a `RawWaker`. <br>`vtable` 自定义从 `RawWaker` 创建的 `Waker` 的行为。<br>
    /// For each operation on the `Waker`, the associated function in the `vtable` of the underlying `RawWaker` will be called. <br>对于 `Waker` 上的每个操作，将调用底层 `RawWaker` 的 `vtable` 中的关联函数。<br>
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[must_use]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// A virtual function pointer table (vtable) that specifies the behavior of a [`RawWaker`]. <br>虚拟函数指针表 (vtable)，用于指定 [`RawWaker`] 的行为。<br>
///
/// The pointer passed to all functions inside the vtable is the `data` pointer from the enclosing [`RawWaker`] object. <br>传递给 vtable 内所有函数的指针是来自封闭的 [`RawWaker`] 对象的 `data` 指针。<br>
///
/// The functions inside this struct are only intended to be called on the `data` pointer of a properly constructed [`RawWaker`] object from inside the [`RawWaker`] implementation. <br>仅应在 [`RawWaker`] 实现内部从正确构造的 [`RawWaker`] 对象的 `data` 指针上调用此结构体内部的函数。<br>
/// Calling one of the contained functions using any other `data` pointer will cause undefined behavior. <br>使用任何其他 `data` 指针调用所包含的函数之一将导致未定义的行为。<br>
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// This function will be called when the [`RawWaker`] gets cloned, e.g. when the [`Waker`] in which the [`RawWaker`] is stored gets cloned. <br>克隆 [`RawWaker`] 时，例如克隆存储 [`RawWaker`] 的 [`Waker`] 时，将调用此函数。<br>
    ///
    /// The implementation of this function must retain all resources that are required for this additional instance of a [`RawWaker`] and associated task. <br>此函数的实现必须保留 [`RawWaker`] 的此附加实例和关联任务所需的所有资源。<br>
    /// Calling `wake` on the resulting [`RawWaker`] should result in a wakeup of the same task that would have been awoken by the original [`RawWaker`]. <br>在生成的 [`RawWaker`] 上调用 `wake` 应该会唤醒原 [`RawWaker`] 会唤醒的相同任务。<br>
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// This function will be called when `wake` is called on the [`Waker`]. <br>在 [`Waker`] 上调用 `wake` 时将调用此函数。<br>
    /// It must wake up the task associated with this [`RawWaker`]. <br>它必须唤醒与此 [`RawWaker`] 相关的任务。<br>
    ///
    /// The implementation of this function must make sure to release any resources that are associated with this instance of a [`RawWaker`] and associated task. <br>此函数的实现必须确保释放与该 [`RawWaker`] 实例和关联任务相关联的所有资源。<br>
    ///
    ///
    wake: unsafe fn(*const ()),

    /// This function will be called when `wake_by_ref` is called on the [`Waker`]. <br>在 [`Waker`] 上调用 `wake_by_ref` 时将调用此函数。<br>
    /// It must wake up the task associated with this [`RawWaker`]. <br>它必须唤醒与此 [`RawWaker`] 相关的任务。<br>
    ///
    /// This function is similar to `wake`, but must not consume the provided data pointer. <br>该函数与 `wake` 相似，但不能消耗提供的数据指针。<br>
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// This function gets called when a [`RawWaker`] gets dropped. <br>丢弃 [`RawWaker`] 时将调用此函数。<br>
    ///
    /// The implementation of this function must make sure to release any resources that are associated with this instance of a [`RawWaker`] and associated task. <br>此函数的实现必须确保释放与该 [`RawWaker`] 实例和关联任务相关联的所有资源。<br>
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Creates a new `RawWakerVTable` from the provided `clone`, `wake`, `wake_by_ref`, and `drop` functions. <br>从提供的 `clone`，`wake`，`wake_by_ref` 和 `drop` 函数创建新的 `RawWakerVTable`。<br>
    ///
    /// # `clone`
    ///
    /// This function will be called when the [`RawWaker`] gets cloned, e.g. when the [`Waker`] in which the [`RawWaker`] is stored gets cloned. <br>克隆 [`RawWaker`] 时，例如克隆存储 [`RawWaker`] 的 [`Waker`] 时，将调用此函数。<br>
    ///
    /// The implementation of this function must retain all resources that are required for this additional instance of a [`RawWaker`] and associated task. <br>此函数的实现必须保留 [`RawWaker`] 的此附加实例和关联任务所需的所有资源。<br>
    /// Calling `wake` on the resulting [`RawWaker`] should result in a wakeup of the same task that would have been awoken by the original [`RawWaker`]. <br>在生成的 [`RawWaker`] 上调用 `wake` 应该会唤醒原 [`RawWaker`] 会唤醒的相同任务。<br>
    ///
    /// # `wake`
    ///
    /// This function will be called when `wake` is called on the [`Waker`]. <br>在 [`Waker`] 上调用 `wake` 时将调用此函数。<br>
    /// It must wake up the task associated with this [`RawWaker`]. <br>它必须唤醒与此 [`RawWaker`] 相关的任务。<br>
    ///
    /// The implementation of this function must make sure to release any resources that are associated with this instance of a [`RawWaker`] and associated task. <br>此函数的实现必须确保释放与该 [`RawWaker`] 实例和关联任务相关联的所有资源。<br>
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// This function will be called when `wake_by_ref` is called on the [`Waker`]. <br>在 [`Waker`] 上调用 `wake_by_ref` 时将调用此函数。<br>
    /// It must wake up the task associated with this [`RawWaker`]. <br>它必须唤醒与此 [`RawWaker`] 相关的任务。<br>
    ///
    /// This function is similar to `wake`, but must not consume the provided data pointer. <br>该函数与 `wake` 相似，但不能消耗提供的数据指针。<br>
    ///
    /// # `drop`
    ///
    /// This function gets called when a [`RawWaker`] gets dropped. <br>丢弃 [`RawWaker`] 时将调用此函数。<br>
    ///
    /// The implementation of this function must make sure to release any resources that are associated with this instance of a [`RawWaker`] and associated task. <br>此函数的实现必须确保释放与该 [`RawWaker`] 实例和关联任务相关联的所有资源。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// The `Context` of an asynchronous task. <br>异步任务的 `Context`。<br>
///
/// Currently, `Context` only serves to provide access to a `&Waker` which can be used to wake the current task. <br>当前，`Context` 仅用于提供对可用于唤醒当前任务的 `&Waker` 的访问。<br>
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Ensure we future-proof against variance changes by forcing the lifetime to be invariant (argument-position lifetimes are contravariant while return-position lifetimes are covariant). <br>通过强制生命周期不变，确保我们能够抵御未来的变化 (参数位置生命周期是逆变的，而返回位置生命周期是协变的)。<br>
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Create a new `Context` from a `&Waker`. <br>从 `&Waker` 创建一个新的 `Context`。<br>
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[must_use]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Returns a reference to the `Waker` for the current task. <br>返回对当前任务的 `Waker` 的引用。<br>
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[must_use]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// A `Waker` is a handle for waking up a task by notifying its executor that it is ready to be run. <br>`Waker` 是通过通知执行者准备运行来唤醒任务的句柄。<br>
///
/// This handle encapsulates a [`RawWaker`] instance, which defines the executor-specific wakeup behavior. <br>该句柄封装了 [`RawWaker`] 实例，该实例定义了特定于执行者的唤醒行为。<br>
///
///
/// Implements [`Clone`], [`Send`], and [`Sync`]. <br>实现 [`Clone`]，[`Send`] 和 [`Sync`]。<br>
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Wake up the task associated with this `Waker`. <br>唤醒与此 `Waker` 相关的任务。<br>
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // The actual wakeup call is delegated through a virtual function call to the implementation which is defined by the executor. <br>实际的唤醒调用通过虚拟函数调用委托给执行程序定义的实现。<br>
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Don't call `drop` -- the waker will be consumed by `wake`. <br>不要调用 `drop` - `wake` 将消耗唤醒器。<br>
        crate::mem::forget(self);

        // SAFETY: This is safe because `Waker::from_raw` is the only way to initialize `wake` and `data` requiring the user to acknowledge that the contract of `RawWaker` is upheld. <br>这是安全的，因为 `Waker::from_raw` 是初始化 `wake` 和 `data` 的唯一方法，要求用户确认 `RawWaker` 的契约已得到遵守。<br>
        //
        //
        unsafe { (wake)(data) };
    }

    /// Wake up the task associated with this `Waker` without consuming the `Waker`. <br>唤醒与此 `Waker` 相关的任务，而不消耗 `Waker`。<br>
    ///
    /// This is similar to `wake`, but may be slightly less efficient in the case where an owned `Waker` is available. <br>这与 `wake` 相似，但是在拥有 `Waker` 的情况下效率可能稍低。<br>
    /// This method should be preferred to calling `waker.clone().wake()`. <br>此方法应该比调用 `waker.clone().wake()` 更可取。<br>
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // The actual wakeup call is delegated through a virtual function call to the implementation which is defined by the executor. <br>实际的唤醒调用通过虚拟函数调用委托给执行程序定义的实现。<br>
        //

        // SAFETY: see `wake` <br>请参见 `wake`<br>
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Returns `true` if this `Waker` and another `Waker` have awoken the same task. <br>如果此 `Waker` 和另一个 `Waker` 唤醒了同一任务，则返回 `true`。<br>
    ///
    /// This function works on a best-effort basis, and may return false even when the `Waker`s would awaken the same task. <br>该函数在尽力而为的基础上起作用，即使 `Waker`s 唤醒相同的任务，也可能返回 false。<br>
    /// However, if this function returns `true`, it is guaranteed that the `Waker`s will awaken the same task. <br>但是，如果此函数返回 `true`，则可以确保 Waker 唤醒相同的任务。<br>
    ///
    /// This function is primarily used for optimization purposes. <br>该函数主要用于优化目的。<br>
    ///
    #[inline]
    #[must_use]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Creates a new `Waker` from [`RawWaker`]. <br>从 [`RawWaker`] 创建一个新的 `Waker`。<br>
    ///
    /// The behavior of the returned `Waker` is undefined if the contract defined in [`RawWaker`]'s and [`RawWakerVTable`]'s documentation is not upheld. <br>如果未遵守 [`RawWaker`] 和 [`RawWakerVTable`] 文档中定义的契约，则返回的 `Waker` 的行为是不确定的。<br>
    ///
    /// Therefore this method is unsafe. <br>因此，此方法是不安全的。<br>
    #[inline]
    #[must_use]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SAFETY: This is safe because `Waker::from_raw` is the only way to initialize `clone` and `data` requiring the user to acknowledge that the contract of [`RawWaker`] is upheld. <br>这是安全的，因为 `Waker::from_raw` 是初始化 `clone` 和 `data` 的唯一方法，要求用户确认 [`RawWaker`] 的契约已得到遵守。<br>
            //
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SAFETY: This is safe because `Waker::from_raw` is the only way to initialize `drop` and `data` requiring the user to acknowledge that the contract of `RawWaker` is upheld. <br>这是安全的，因为 `Waker::from_raw` 是初始化 `drop` 和 `data` 的唯一方法，要求用户确认 `RawWaker` 的契约已得到遵守。<br>
        //
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}
