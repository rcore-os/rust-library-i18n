#![allow(unused_imports, unused_macros)] // items are used by the macro <br>由宏使用的项<br>

use crate::cell::UnsafeCell;
use crate::future::{poll_fn, Future};
use crate::mem;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Polls multiple futures simultaneously, returning a tuple of all results once complete. <br>同时轮询多个 futures，完成后，返回所有结果的元组。<br>
///
/// While `join!(a, b)` is similar to `(a.await, b.await)`, `join!` polls both futures concurrently and is therefore more efficient. <br>虽然 `join!(a, b)` 与 `(a.await, b.await)` 相似，但 `join!` 同时轮询两个 futures，因此效率更高。<br>
///
///
/// # Examples
///
/// ```
/// #![feature(future_join, future_poll_fn)]
///
/// use std::future::join;
///
/// async fn one() -> usize { 1 }
/// async fn two() -> usize { 2 }
///
/// # let _ =  async {
/// let x = join!(one(), two()).await;
/// assert_eq!(x, (1, 2));
/// # };
/// ```
///
/// `join!` is variadic, so you can pass any number of futures: <br>`join!` 的参数是可变的，因此您可以传递任意数量的 futures：<br>
///
/// ```
/// #![feature(future_join, future_poll_fn)]
///
/// use std::future::join;
///
/// async fn one() -> usize { 1 }
/// async fn two() -> usize { 2 }
/// async fn three() -> usize { 3 }
///
/// # let _ = async {
/// let x = join!(one(), two(), three()).await;
/// assert_eq!(x, (1, 2, 3));
/// # };
/// ```
///
#[unstable(feature = "future_join", issue = "91642")]
pub macro join( $($fut:expr),+ $(,)? ) {
    // Funnel through an internal macro not to leak implementation details. <br>通过内部宏传递信息，不泄露实现细节。<br>
    join_internal! {
        current_position: []
        futures_and_positions: []
        munching: [ $($fut)+ ]
    }
}

// FIXME(danielhenrymantilla): a private macro should need no stability guarantee. <br>私有宏应该不需要稳定性保证。<br>
#[unstable(feature = "future_join", issue = "91642")]
/// To be able to *name* the i-th future in the tuple (say we want the .4-th), the following trick will be used: `let (_, _, _, _, it, ..) = tuple;` In order to do that, we need to generate a `i`-long repetition of `_`, for each i-th fut. <br>为了能够*命名*元组中的第 `i` 个 future (假设我们想要第 .4 个)，将使用以下技巧: `let (_, , , _, it, ..) = tuple;` 为了做到这一点，我们需要为每个第 `i` 个 fut 生成一个 `i` 长的重复 `_`。<br>
/// Hence the recursive muncher approach. <br>因此，递归 muncher 方法。<br>
///
///
macro join_internal {
    // Recursion step: map each future with its "position" (underscore count). <br>递归步骤：映射每个 future 及其 "position" (下划线计数)。<br>
    (
        // Accumulate a token for each future that has been expanded: "_ _ _". <br>为每个已扩展的 future 累积一个 token: "_ _ _"。<br>
        current_position: [
            $($underscores:tt)*
        ]
        // Accumulate Futures and their positions in the tuple: `_0th ()   _1st ( _ ) …`. <br>累积 Futures 及其在元组中的位置: `_0th () _1st ( _ )…`。<br>
        futures_and_positions: [
            $($acc:tt)*
        ]
        // Munch one future. <br>Munch 一个 future。<br>
        munching: [
            $current:tt
            $($rest:tt)*
        ]
    ) => (
        join_internal! {
            current_position: [
                $($underscores)*
                _
            ]
            futures_and_positions: [
                $($acc)*
                $current ( $($underscores)* )
            ]
            munching: [
                $($rest)*
            ]
        }
    ),

    // End of recursion: generate the output future. <br>递归结束：生成输出 future。<br>
    (
        current_position: $_:tt
        futures_and_positions: [
            $(
                $fut_expr:tt ( $($pos:tt)* )
            )*
        ]
        // Nothing left to munch. <br>没有什么可 munch 的。<br>
        munching: []
    ) => (
        match ( $( MaybeDone::Future($fut_expr), )* ) { futures => async {
            let mut futures = futures;
            // SAFETY: this is `pin_mut!`. <br>这是 `pin_mut!`。<br>
            let mut futures = unsafe { Pin::new_unchecked(&mut futures) };
            poll_fn(move |cx| {
                let mut done = true;
                // For each `fut`, pin-project to it, and poll it. <br>对于每个 `fut`，将其固定并轮询它。<br>
                $(
                    // SAFETY: pinning projection <br>固定推断 (pinning projection)<br>
                    let fut = unsafe {
                        futures.as_mut().map_unchecked_mut(|it| {
                            let ( $($pos,)* fut, .. ) = it;
                            fut
                        })
                    };
                    // Despite how tempting it may be to `let () = fut.poll(cx).ready()?;` doing so would defeat the point of `join!`: to start polling eagerly all of the futures, to allow parallelizing the waits. <br>尽管 `let () = fut.poll(cx).ready()?;` 可能很诱人，但这样做会破坏 `join!` 的意义：急切地开始轮询所有 futures，以允许并行等待。<br>
                    //
                    //
                    done &= fut.poll(cx).is_ready();
                )*
                if !done {
                    return Poll::Pending;
                }
                // All ready; <br>一切就绪；<br> time to extract all the outputs. <br>是时候提取所有输出了。<br>

                // SAFETY: `.take_output()` does not break the `Pin` invariants for that `fut`. <br>`.take_output()` 不会破坏该 `fut` 的 `Pin` 不变量。<br>
                let futures = unsafe {
                    futures.as_mut().get_unchecked_mut()
                };
                Poll::Ready(
                    ($(
                        {
                            let ( $($pos,)* fut, .. ) = &mut *futures;
                            fut.take_output().unwrap()
                        }
                    ),*) // <- no trailing comma since we don't want 1-tuples. <br>没有尾随逗号，因为我们不需要一元组。<br>
                )
            }).await
        }}
    ),
}

/// Future used by `join!` that stores it's output to be later taken and doesn't panic when polled after ready. <br>Future 使用 `join!` 存储它的输出，以供以后使用，并且在 ready 后轮询时不会发生 panic。<br>
///
///
/// This type is public in a private module for use by the macro. <br>这种类型在私有模块中是公共的，供宏使用。<br>
#[allow(missing_debug_implementations)]
#[unstable(feature = "future_join", issue = "91642")]
pub enum MaybeDone<F: Future> {
    Future(F),
    Done(F::Output),
    Taken,
}

#[unstable(feature = "future_join", issue = "91642")]
impl<F: Future> MaybeDone<F> {
    pub fn take_output(&mut self) -> Option<F::Output> {
        match *self {
            MaybeDone::Done(_) => match mem::replace(self, Self::Taken) {
                MaybeDone::Done(val) => Some(val),
                _ => unreachable!(),
            },
            _ => None,
        }
    }
}

#[unstable(feature = "future_join", issue = "91642")]
impl<F: Future> Future for MaybeDone<F> {
    type Output = ();

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        // SAFETY: pinning in structural for `f` <br>`f` 的结构固定<br>
        unsafe {
            // Do not mix match ergonomics with unsafe. <br>不要将符合人体工程学的设计与不安全混为一谈。<br>
            match *self.as_mut().get_unchecked_mut() {
                MaybeDone::Future(ref mut f) => {
                    let val = Pin::new_unchecked(f).poll(cx).ready()?;
                    self.set(Self::Done(val));
                }
                MaybeDone::Done(_) => {}
                MaybeDone::Taken => unreachable!(),
            }
        }

        Poll::Ready(())
    }
}
