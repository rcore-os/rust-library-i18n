#![stable(feature = "core_hint", since = "1.27.0")]

//! Hints to compiler that affects how code should be emitted or optimized. <br>对编译器的提示，该提示会影响应如何发出或优化代码。<br>
//! Hints may be compile time or runtime. <br>提示可能是编译时或运行时。<br>

use crate::intrinsics;

/// Informs the compiler that this point in the code is not reachable, enabling further optimizations. <br>通知编译器代码中的这一点不可访问，从而可以进行进一步的优化。<br>
///
/// # Safety
///
/// Reaching this function is completely *undefined behavior* (UB). <br>达到此函数完全是 *未定义的行为* (UB)。<br> In particular, the compiler assumes that all UB must never happen, and therefore will eliminate all branches that reach to a call to `unreachable_unchecked()`. <br>特别是，编译器假定所有 UB 都绝不会发生，因此将消除到达 `unreachable_unchecked()` 调用的所有分支。<br>
///
/// Like all instances of UB, if this assumption turns out to be wrong, i.e., the `unreachable_unchecked()` call is actually reachable among all possible control flow, the compiler will apply the wrong optimization strategy, and may sometimes even corrupt seemingly unrelated code, causing difficult-to-debug problems. <br>与 UB 的所有实例一样，如果这种假设被证明是错误的，即 `unreachable_unchecked()` 调用实际上在所有可能的控制流中都是可以到达的，则编译器将应用错误的优化策略，有时甚至可能破坏看似无关的代码，从而导致难以解决的问题 - 调试问题。<br>
///
///
/// Use this function only when you can prove that the code will never call it. <br>仅当您可以证明该代码永远不会调用它时，才使用此函数。<br>
/// Otherwise, consider using the [`unreachable!`] macro, which does not allow optimizations but will panic when executed. <br>否则，请考虑使用 [`unreachable!`] 宏，该宏不允许进行优化，但是在执行时将为 panic。<br>
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` is always positive (not zero), hence `checked_div` will never return `None`. <br>`b.saturating_add(1)` 始终为正 (非零)，因此 `checked_div` 永远不会返回 `None`。<br>
/////
///     // Therefore, the else branch is unreachable. <br>因此，else 分支不可访问。<br>
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_stable(feature = "const_unreachable_unchecked", since = "1.57.0")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SAFETY: the safety contract for `intrinsics::unreachable` must be upheld by the caller. <br>调用者必须遵守 `intrinsics::unreachable` 的安全保证。<br>
    //
    unsafe { intrinsics::unreachable() }
}

/// Emits a machine instruction to signal the processor that it is running in a busy-wait spin-loop ("spin lock"). <br>发出一条机器指令，以向处理器发送信号，指示其正在忙于等待的自旋循环 (自旋锁) 中运行。<br>
///
/// Upon receiving the spin-loop signal the processor can optimize its behavior by, for example, saving power or switching hyper-threads. <br>在接收到自旋环信号后，处理器可以通过例如节省功率或切换 hyper 线程来优化其行为。<br>
///
/// This function is different from [`thread::yield_now`] which directly yields to the system's scheduler, whereas `spin_loop` does not interact with the operating system. <br>此函数不同于 [`thread::yield_now`]，后者直接产生系统的调度程序，而 `spin_loop` 不与操作系统交互。<br>
///
/// A common use case for `spin_loop` is implementing bounded optimistic spinning in a CAS loop in synchronization primitives. <br>`spin_loop` 的一个常见用例是在同步原语的 CAS 循环中实现有界乐观旋转。<br>
/// To avoid problems like priority inversion, it is strongly recommended that the spin loop is terminated after a finite amount of iterations and an appropriate blocking syscall is made. <br>为避免优先级倒置之类的问题，强烈建议在有限次数的迭代后终止旋转循环，并进行适当的阻塞系统调用。<br>
///
///
/// **Note**: On platforms that do not support receiving spin-loop hints this function does not do anything at all. <br>在不支持接收自旋循环提示的平台上，此函数完全不执行任何操作。<br>
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // A shared atomic value that threads will use to coordinate <br>线程将用于协调的共享原子值<br>
/// let live = Arc::new(AtomicBool::new(false));
///
/// // In a background thread we'll eventually set the value <br>在后台线程中，我们最终将设置该值<br>
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Do some work, then make the value live <br>做一些工作，然后创造值<br>
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Back on our current thread, we wait for the value to be set <br>回到我们当前的线程，我们等待该值被设置<br>
/// while !live.load(Ordering::Acquire) {
///     // The spin loop is a hint to the CPU that we're waiting, but probably not for very long <br>自旋循环是对我们正在等待的 CPU 的提示，但可能不会持续很长时间<br>
/////
///     hint::spin_loop();
/// }
///
/// // The value is now set <br>现在设置该值<br>
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SAFETY: the `cfg` attr ensures that we only execute this on x86 targets. <br>`cfg` 属性确保我们仅在 x86 目标上执行此操作。<br>
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SAFETY: the `cfg` attr ensures that we only execute this on x86_64 targets. <br>`cfg` 属性确保我们仅在 x86_64 目标上执行此操作。<br>
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    // RISC-V platform spin loop hint implementation <br>RISC-V 平台自旋循环提示实现<br>
    {
        // RISC-V RV32 and RV64 share the same PAUSE instruction, but they are located in different modules in `core::arch`. <br>RISC-V RV32 和 RV64 共享相同的 PAUSE 指令，但它们位于 `core::arch` 中的不同模块中。<br>
        //
        // In this case, here we call `pause` function in each core arch module. <br>在这种情况下，我们在每个核心 arch 模块中调用 `pause` 函数。<br>
        #[cfg(target_arch = "riscv32")]
        {
            crate::arch::riscv32::pause();
        }
        #[cfg(target_arch = "riscv64")]
        {
            crate::arch::riscv64::pause();
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SAFETY: the `cfg` attr ensures that we only execute this on aarch64 targets. <br>`cfg` 属性确保我们仅在 aarch64 目标上执行此操作。<br>
            unsafe { crate::arch::aarch64::__isb(crate::arch::aarch64::SY) };
        }
        #[cfg(target_arch = "arm")]
        {
            // SAFETY: the `cfg` attr ensures that we only execute this on arm targets with support for the v6 feature. <br>`cfg` 属性确保我们仅在支持 v6 特性的 arm 目标上执行此操作。<br>
            //
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// An identity function that *__hints__* to the compiler to be maximally pessimistic about what `black_box` could do. <br>一个标识函数，*__hints__* 编译器对 `black_box` 能做的事情保持最大限度的悲观。<br>
///
/// Unlike [`std::convert::identity`], a Rust compiler is encouraged to assume that `black_box` can use `dummy` in any possible valid way that Rust code is allowed to without introducing undefined behavior in the calling code. <br>与 [`std::convert::identity`] 不同，鼓励 Rust 编译器假定 `black_box` 可以以允许 Rust 代码使用的任何可能有效方式使用 `dummy`，而不会在调用代码中引入未定义的行为。<br>
///
/// This property makes `black_box` useful for writing code in which certain optimizations are not desired, such as benchmarks. <br>此属性使 `black_box` 可用于编写不需要进行某些优化 (例如基准测试) 的代码。<br>
///
/// Note however, that `black_box` is only (and can only be) provided on a "best-effort" basis. <br>但是请注意，`black_box` 仅 (并且只能) 以 "best-effort" 为基础提供。<br> The extent to which it can block optimisations may vary depending upon the platform and code-gen backend used. <br>它可以阻止优化的程度可能会有所不同，具体取决于所使用的平台和代码源后端。<br>
/// Programs cannot rely on `black_box` for *correctness* in any way. <br>程序不能以任何方式依靠 `black_box` 的正确性。<br>
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[inline]
#[unstable(feature = "bench_black_box", issue = "64102")]
#[rustc_const_unstable(feature = "const_black_box", issue = "none")]
pub const fn black_box<T>(dummy: T) -> T {
    crate::intrinsics::black_box(dummy)
}
