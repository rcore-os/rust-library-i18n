//! impl char {} <br>展示字符 {}<br>

use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// The highest valid code point a `char` can have. <br>`char` 可以具有的最高有效代码点。<br>
    ///
    /// A `char` is a [Unicode Scalar Value], which means that it is a [Code Point], but only ones within a certain range. <br>`char` 是 [Unicode 标量值][Unicode Scalar Value]，这意味着它是 [代码点][Code Point]，但仅在一定范围内。<br>
    /// `MAX` is the highest valid code point that's a valid [Unicode Scalar Value]. <br>`MAX` 是有效的 [Unicode 标量值][Unicode Scalar Value] 的最高有效代码点。<br>
    ///
    /// [Unicode Scalar Value]: https://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: https://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () is used in Unicode to represent a decoding error. <br>`U+FFFD REPLACEMENT CHARACTER` () 在 Unicode 中用于表示解码错误。<br>
    ///
    /// It can occur, for example, when giving ill-formed UTF-8 bytes to [`String::from_utf8_lossy`](../std/string/struct.String.html#method.from_utf8_lossy). <br>例如，当将格式错误的 UTF-8 字节提供给 [`String::from_utf8_lossy`](../std/string/struct.String.html#method.from_utf8_lossy) 时，就会发生这种情况。<br>
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// The version of [Unicode](https://www.unicode.org/) that the Unicode parts of `char` and `str` methods are based on. <br>`char` 和 `str` 方法的 Unicode 部分所基于的 [Unicode](https://www.unicode.org/) 版本。<br>
    ///
    /// New versions of Unicode are released regularly and subsequently all methods in the standard library depending on Unicode are updated. <br>Unicode 的新版本会定期发布，随后会更新标准库中取决于 Unicode 的所有方法。<br>
    /// Therefore the behavior of some `char` and `str` methods and the value of this constant changes over time. <br>因此，某些 `char` 和 `str` 方法的行为以及该常量的值会随时间变化。<br>
    /// This is *not* considered to be a breaking change. <br>这不是一个突破性的改变。<br>
    ///
    /// The version numbering scheme is explained in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4). <br>版本编号方案在 [Unicode 11.0 或更高版本，第 3.1 节 Unicode 标准版本](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) 中进行了说明。<br>
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Creates an iterator over the UTF-16 encoded code points in `iter`, returning unpaired surrogates as `Err`s. <br>在 `iter` 中的 UTF-16 编码的代码点上创建一个迭代器，将不成对的代理返回为 `Err`s。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v)
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// A lossy decoder can be obtained by replacing `Err` results with the replacement character: <br>通过用替换字符替换 `Err` 结果，可以获得有损解码器：<br>
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v)
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Converts a `u32` to a `char`. <br>将 `u32` 转换为 `char`。<br>
    ///
    /// Note that all `char`s are valid [`u32`]s, and can be cast to one with <br>请注意，所有的 `char`s 都是有效的 [`u32`]，并且可以使用以下命令将其强制转换为 1<br>
    /// [`as`](../std/keyword.as.html):
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// However, the reverse is not true: not all valid [`u32`]s are valid `char`s. <br>但是，相反的情况并非如此：并非所有有效的 [u32] 都是有效的 char。<br>
    /// `from_u32()` will return `None` if the input is not a valid value for a `char`. <br>如果输入不是 `char` 的有效值，`from_u32()` 将返回 `None`。<br>
    ///
    /// For an unsafe version of this function which ignores these checks, see [`from_u32_unchecked`]. <br>有关忽略这些检查的该函数的不安全版本，请参见 [`from_u32_unchecked`]。<br>
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Returning `None` when the input is not a valid `char`: <br>当输入不是有效的 `char` 时返回 `None`：<br>
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[rustc_const_unstable(feature = "const_char_convert", issue = "89259")]
    #[must_use]
    #[inline]
    pub const fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Converts a `u32` to a `char`, ignoring validity. <br>将 `u32` 转换为 `char`，而忽略有效性。<br>
    ///
    /// Note that all `char`s are valid [`u32`]s, and can be cast to one with <br>请注意，所有的 `char`s 都是有效的 [`u32`]，并且可以使用以下命令将其强制转换为 1<br>
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// However, the reverse is not true: not all valid [`u32`]s are valid `char`s. <br>但是，相反的情况并非如此：并非所有有效的 [u32] 都是有效的 char。<br>
    /// `from_u32_unchecked()` will ignore this, and blindly cast to `char`, possibly creating an invalid one. <br>`from_u32_unchecked()` 将忽略这一点，并盲目地转换为 `char`，可能会创建一个无效的。<br>
    ///
    ///
    /// # Safety
    ///
    /// This function is unsafe, as it may construct invalid `char` values. <br>该函数是不安全的，因为它可能创建无效的 `char` 值。<br>
    ///
    /// For a safe version of this function, see the [`from_u32`] function. <br>有关此函数的安全版本，请参见 [`from_u32`] 函数。<br>
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[rustc_const_unstable(feature = "const_char_convert", issue = "89259")]
    #[must_use]
    #[inline]
    pub const unsafe fn from_u32_unchecked(i: u32) -> char {
        // SAFETY: the safety contract must be upheld by the caller. <br>调用者必须坚持安全保证。<br>
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Converts a digit in the given radix to a `char`. <br>将给定基数中的数字转换为 `char`。<br>
    ///
    /// A 'radix' here is sometimes also called a 'base'. <br>这里的 'radix' 有时也称为 'base'。<br>
    /// A radix of two indicates a binary number, a radix of ten, decimal, and a radix of sixteen, hexadecimal, to give some common values. <br>基数 2 表示二进制数，以十进制表示的十进制，以十六进制表示十六进制的基数，以给出一些公共值。<br>
    ///
    /// Arbitrary radices are supported. <br>支持任意基数。<br>
    ///
    /// `from_digit()` will return `None` if the input is not a digit in the given radix. <br>如果输入不是给定基数中的数字，`from_digit()` 将返回 `None`。<br>
    ///
    /// # Panics
    ///
    /// Panics if given a radix larger than 36. <br>如果给定的基数大于 36，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimal 11 is a single digit in base 16 <br>十进制 11 是以 16 为底的一位数字<br>
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Returning `None` when the input is not a digit: <br>当输入不是数字时返回 `None`：<br>
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Passing a large radix, causing a panic: <br>传递较大的基数，导致 panic：<br>
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics <br>这个 panics<br>
    /// let _c = char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[rustc_const_unstable(feature = "const_char_convert", issue = "89259")]
    #[must_use]
    #[inline]
    pub const fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Checks if a `char` is a digit in the given radix. <br>检查 `char` 是否为给定基数中的数字。<br>
    ///
    /// A 'radix' here is sometimes also called a 'base'. <br>这里的 'radix' 有时也称为 'base'。<br>
    /// A radix of two indicates a binary number, a radix of ten, decimal, and a radix of sixteen, hexadecimal, to give some common values. <br>基数 2 表示二进制数，以十进制表示的十进制，以十六进制表示十六进制的基数，以给出一些公共值。<br>
    ///
    /// Arbitrary radices are supported. <br>支持任意基数。<br>
    ///
    /// Compared to [`is_numeric()`], this function only recognizes the characters `0-9`, `a-z` and `A-Z`. <br>与 [`is_numeric()`] 相比，此函数仅识别字符 `0-9`，`a-z` 和 `A-Z`。<br>
    ///
    /// 'Digit' is defined to be only the following characters: <br>'Digit' 定义为仅以下字符：<br>
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// For a more comprehensive understanding of 'digit', see [`is_numeric()`]. <br>要更全面地了解 'digit'，请参见 [`is_numeric()`]。<br>
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics if given a radix larger than 36. <br>如果给定的基数大于 36，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Passing a large radix, causing a panic: <br>传递较大的基数，导致 panic：<br>
    ///
    /// ```should_panic
    /// // this panics <br>这个 panics<br>
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Converts a `char` to a digit in the given radix. <br>将 `char` 转换为给定基数的数字。<br>
    ///
    /// A 'radix' here is sometimes also called a 'base'. <br>这里的 'radix' 有时也称为 'base'。<br>
    /// A radix of two indicates a binary number, a radix of ten, decimal, and a radix of sixteen, hexadecimal, to give some common values. <br>基数 2 表示二进制数，以十进制表示的十进制，以十六进制表示十六进制的基数，以给出一些公共值。<br>
    ///
    /// Arbitrary radices are supported. <br>支持任意基数。<br>
    ///
    /// 'Digit' is defined to be only the following characters: <br>'Digit' 定义为仅以下字符：<br>
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Returns `None` if the `char` does not refer to a digit in the given radix. <br>如果 `char` 未引用给定基数中的数字，则返回 `None`。<br>
    ///
    /// # Panics
    ///
    /// Panics if given a radix larger than 36. <br>如果给定的基数大于 36，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Passing a non-digit results in failure: <br>传递非数字会导致失败：<br>
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Passing a large radix, causing a panic: <br>传递较大的基数，导致 panic：<br>
    ///
    /// ```should_panic
    /// // this panics <br>这个 panics<br>
    /// let _ = '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_char_convert", issue = "89259")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    pub const fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // If not a digit, a number greater than radix will be created. <br>如果不是数字，则将创建一个大于基数的数字。<br>
        let mut digit = (self as u32).wrapping_sub('0' as u32);
        if radix > 10 {
            if digit < 10 {
                return Some(digit);
            }
            // Force the 6th bit to be set to ensure ascii is lower case. <br>强制设置第 6 位以确保 ascii 是小写的。<br>
            digit = (self as u32 | 0b10_0000).wrapping_sub('a' as u32).saturating_add(10);
        }
        // FIXME: once then_some is const fn, use it here <br>一旦 then_some 是 const fn，就在这里使用它<br>
        if digit < radix { Some(digit) } else { None }
    }

    /// Returns an iterator that yields the hexadecimal Unicode escape of a character as `char`s. <br>返回一个迭代器，该迭代器将字符的十六进制 Unicode 转义生成为 `char`s。<br>
    ///
    /// This will escape characters with the Rust syntax of the form `\u{NNNNNN}` where `NNNNNN` is a hexadecimal representation. <br>这将使用 `\u{NNNNNN}` 格式的 Rust 语法对字符进行转义，其中 `NNNNNN` 是十六进制表示形式。<br>
    ///
    ///
    /// # Examples
    ///
    /// As an iterator: <br>作为迭代器：<br>
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Using `println!` directly: <br>直接使用 `println!`：<br>
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Both are equivalent to: <br>两者都等同于：<br>
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Using [`to_string`](../std/string/trait.ToString.html#tymethod.to_string): <br>使用 [`to_string`](../std/string/trait.ToString.html#tymethod.to_string)：<br>
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[must_use = "this returns the escaped char as an iterator, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 ensures that for c==0 the code computes that one digit should be printed and (which is the same) avoids the (31 - 32) underflow <br>or-ing 1 确保在 c == 0 时代码计算出应该打印一位，并且 (相同) 避免 (31-32) 下溢<br>
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // the index of the most significant hex digit <br>最高有效十六进制数字的索引<br>
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// An extended version of `escape_debug` that optionally permits escaping Extended Grapheme codepoints, single quotes, and double quotes. <br>`escape_debug` 的扩展版本，可选择允许转义扩展字素代码点、单引号和双引号。<br>
    /// This allows us to format characters like nonspacing marks better when they're at the start of a string, and allows escaping single quotes in characters, and double quotes in strings. <br>这允许我们在字符串开头时更好地格式化像非空格标记这样的字符，并允许转义字符中的单引号和字符串中的双引号。<br>
    ///
    ///
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, args: EscapeDebugExtArgs) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' => EscapeDefaultState::Backslash(self),
            '"' if args.escape_double_quote => EscapeDefaultState::Backslash(self),
            '\'' if args.escape_single_quote => EscapeDefaultState::Backslash(self),
            _ if args.escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Returns an iterator that yields the literal escape code of a character as `char`s. <br>返回一个迭代器，该迭代器将字符的字面量转义码生成为 `char`s。<br>
    ///
    /// This will escape the characters similar to the [`Debug`](core::fmt::Debug) implementations of `str` or `char`. <br>这将转义类似于 `str` 或 `char` 的 [`Debug`](core::fmt::Debug) 实现的字符。<br>
    ///
    ///
    /// # Examples
    ///
    /// As an iterator: <br>作为迭代器：<br>
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Using `println!` directly: <br>直接使用 `println!`：<br>
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Both are equivalent to: <br>两者都等同于：<br>
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Using [`to_string`](../std/string/trait.ToString.html#tymethod.to_string): <br>使用 [`to_string`](../std/string/trait.ToString.html#tymethod.to_string)：<br>
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[must_use = "this returns the escaped char as an iterator, \
                  without modifying the original"]
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(EscapeDebugExtArgs::ESCAPE_ALL)
    }

    /// Returns an iterator that yields the literal escape code of a character as `char`s. <br>返回一个迭代器，该迭代器将字符的字面量转义码生成为 `char`s。<br>
    ///
    /// The default is chosen with a bias toward producing literals that are legal in a variety of languages, including C++11 and similar C-family languages. <br>选择默认值时会偏向于生成在多种语言 (包括 C++ 11 和类似的 C 系列语言) 中都合法的字面量。<br>
    /// The exact rules are: <br>确切的规则是：<br>
    ///
    /// * Tab is escaped as `\t`. <br>制表符被转义为 `\t`。<br>
    /// * Carriage return is escaped as `\r`. <br>回车符被转义为 `\r`。<br>
    /// * Line feed is escaped as `\n`. <br>换行符转为 `\n`。<br>
    /// * Single quote is escaped as `\'`. <br>单引号转义为 `\'`。<br>
    /// * Double quote is escaped as `\"`. <br>双引号转义为 `\"`。<br>
    /// * Backslash is escaped as `\\`. <br>反斜杠转义为 `\\`。<br>
    /// * Any character in the 'printable ASCII' range `0x20` .. <br>`可打印 ASCII` 范围 `0x20` .. 中的任何字符<br> `0x7e` inclusive is not escaped. <br>`0x7e` (含 `0x7e`) 不会转义。<br>
    /// * All other characters are given hexadecimal Unicode escapes; <br>所有其他字符均使用十六进制 Unicode 转义；<br> see [`escape_unicode`]. <br>请参见 [`escape_unicode`]。<br>
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// As an iterator: <br>作为迭代器：<br>
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Using `println!` directly: <br>直接使用 `println!`：<br>
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Both are equivalent to: <br>两者都等同于：<br>
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Using [`to_string`](../std/string/trait.ToString.html#tymethod.to_string): <br>使用 [`to_string`](../std/string/trait.ToString.html#tymethod.to_string)：<br>
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[must_use = "this returns the escaped char as an iterator, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Returns the number of bytes this `char` would need if encoded in UTF-8. <br>返回以 UTF-8 编码时此 `char` 所需的字节数。<br>
    ///
    /// That number of bytes is always between 1 and 4, inclusive. <br>该字节数始终在 1 到 4 之间 (含 1 和 4)。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// The `&str` type guarantees that its contents are UTF-8, and so we can compare the length it would take if each code point was represented as a `char` vs in the `&str` itself: <br>`&str` 类型保证其内容为 UTF-8，因此我们可以比较将每个代码点表示为 `char` 相对于 `&str` 本身所花费的长度：<br>
    ///
    ///
    /// ```
    /// // as chars <br>作为字符<br>
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // both can be represented as three bytes <br>两者都可以表示为三个字节<br>
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // as a &str, these two are encoded in UTF-8 <br>作为 &str，这两个编码为 UTF-8<br>
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // we can see that they take six bytes total... <br>我们可以看到它们总共占用了六个字节...<br>
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... just like the &str <br>就像 &str<br>
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Returns the number of 16-bit code units this `char` would need if encoded in UTF-16. <br>返回以 UTF-16 编码时 `char` 所需的 16 位代码单元的数量。<br>
    ///
    ///
    /// See the documentation for [`len_utf8()`] for more explanation of this concept. <br>有关此概念的更多说明，请参见 [`len_utf8()`] 的文档。<br>
    /// This function is a mirror, but for UTF-16 instead of UTF-8. <br>该函数是一个镜像，但是用于 UTF-16 而不是 UTF-8。<br>
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Encodes this character as UTF-8 into the provided byte buffer, and then returns the subslice of the buffer that contains the encoded character. <br>将此字符编码为 UTF-8 到提供的字节缓冲区中，然后返回包含编码字符的缓冲区的子切片。<br>
    ///
    ///
    /// # Panics
    ///
    /// Panics if the buffer is not large enough. <br>如果缓冲区不够大，就会出现 panics。<br>
    /// A buffer of length four is large enough to encode any `char`. <br>长度为四的缓冲区足够大，可以对任何 `char` 进行编码。<br>
    ///
    /// # Examples
    ///
    /// In both of these examples, 'ß' takes two bytes to encode. <br>在这两个示例中，'ß' 占用两个字节进行编码。<br>
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// A buffer that's too small: <br>缓冲区太小：<br>
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics <br>这个 panics<br>
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SAFETY: `char` is not a surrogate, so this is valid UTF-8. <br>`char` 不是代理，所以这是有效的 UTF-8。<br>
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Encodes this character as UTF-16 into the provided `u16` buffer, and then returns the subslice of the buffer that contains the encoded character. <br>将此字符编码为 UTF-16 到提供的 `u16` 缓冲区中，然后返回包含编码字符的缓冲区的子切片。<br>
    ///
    ///
    /// # Panics
    ///
    /// Panics if the buffer is not large enough. <br>如果缓冲区不够大，就会出现 panics。<br>
    /// A buffer of length 2 is large enough to encode any `char`. <br>长度为 2 的缓冲区足够大，可以对任何 `char` 进行编码。<br>
    ///
    /// # Examples
    ///
    /// In both of these examples, '𝕊' takes two `u16`s to encode. <br>在这两个示例中，'𝕊' 都需要两个 u16 进行编码。<br>
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// A buffer that's too small: <br>缓冲区太小：<br>
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics <br>这个 panics<br>
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Returns `true` if this `char` has the `Alphabetic` property. <br>如果此 `char` 具有 `Alphabetic` 属性，则返回 `true`。<br>
    ///
    /// `Alphabetic` is described in Chapter 4 (Character Properties) of the [Unicode Standard] and specified in the [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]. <br>`Alphabetic` 在 [Unicode 标准][Unicode Standard] 的第 4 章 (字符属性) 中描述并在 [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] 中指定。<br>
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // love is many things, but it is not alphabetic <br>love 有很多东西，但它不是按字母顺序排列的<br>
    /// assert!(!c.is_alphabetic());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Returns `true` if this `char` has the `Lowercase` property. <br>如果此 `char` 具有 `Lowercase` 属性，则返回 `true`。<br>
    ///
    /// `Lowercase` is described in Chapter 4 (Character Properties) of the [Unicode Standard] and specified in the [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]. <br>`Lowercase` 在 [Unicode 标准][Unicode Standard] 的第 4 章 (字符属性) 中描述并在 [Unicode 字符数据库][ucd] [`DerivedCoreProperties.txt`] 中指定。<br>
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // The various Chinese scripts and punctuation do not have case, and so: <br>各种中文脚本和标点符号没有大小写，因此：<br>
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Returns `true` if this `char` has the `Uppercase` property. <br>如果此 `char` 具有 `Uppercase` 属性，则返回 `true`。<br>
    ///
    /// `Uppercase` is described in Chapter 4 (Character Properties) of the [Unicode Standard] and specified in the [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]. <br>`Uppercase` 在 [Unicode 标准][Unicode Standard] 的第 4 章 (字符属性) 中描述并在 [Unicode 字符数据库][ucd] [`DerivedCoreProperties.txt`] 中指定。<br>
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // The various Chinese scripts and punctuation do not have case, and so: <br>各种中文脚本和标点符号没有大小写，因此：<br>
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Returns `true` if this `char` has the `White_Space` property. <br>如果此 `char` 具有 `White_Space` 属性，则返回 `true`。<br>
    ///
    /// `White_Space` is specified in the [Unicode Character Database][ucd] [`PropList.txt`]. <br>`White_Space` 在 [Unicode 字符数据库][ucd] [`PropList.txt`] 中指定。<br>
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // a non-breaking space <br>一个不间断空格<br>
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Returns `true` if this `char` satisfies either [`is_alphabetic()`] or [`is_numeric()`]. <br>如果此 `char` 满足 [`is_alphabetic()`] 或 [`is_numeric()`]，则返回 `true`。<br>
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Returns `true` if this `char` has the general category for control codes. <br>如果此 `char` 具有控制代码的常规类别，则返回 `true`。<br>
    ///
    /// Control codes (code points with the general category of `Cc`) are described in Chapter 4 (Character Properties) of the [Unicode Standard] and specified in the [Unicode Character Database][ucd] [`UnicodeData.txt`]. <br>[Unicode 标准] 的第 4 章 (字符属性) 中描述了控制代码 (具有 `Cc` 的常规类别的代码点)，并在 [Unicode 字符数据库][ucd] [`UnicodeData.txt`] 中进行了指定。<br>
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// // U+009C, STRING TERMINATOR <br>U+009C，字符串终止符<br>
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Returns `true` if this `char` has the `Grapheme_Extend` property. <br>如果此 `char` 具有 `Grapheme_Extend` 属性，则返回 `true`。<br>
    ///
    /// `Grapheme_Extend` is described in [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] and specified in the [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]. <br>`Grapheme_Extend` 在 [Unicode 标准附件 #29 (Unicode 文本分割)][uax29] 中描述并在 [Unicode 字符数据库][ucd] [`DerivedCoreProperties.txt`] 中指定。<br>
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[must_use]
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Returns `true` if this `char` has one of the general categories for numbers. <br>如果此 `char` 具有数字的常规类别之一，则返回 `true`。<br>
    ///
    /// The general categories for numbers (`Nd` for decimal digits, `Nl` for letter-like numeric characters, and `No` for other numeric characters) are specified in the [Unicode Character Database][ucd] [`UnicodeData.txt`]. <br>在 [Unicode 字符数据库][ucd] [`UnicodeData.txt`] 中指定了数字的常规类别 (`Nd` 表示十进制数字，`Nl` 表示类似字母的数字字符，`No` 表示其他数字字符)。<br>
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Returns an iterator that yields the lowercase mapping of this `char` as one or more <br>返回一个迭代器，该迭代器将这个 `char` 的小写字母映射为一个或多个<br>
    /// `char`s.
    ///
    /// If this `char` does not have a lowercase mapping, the iterator yields the same `char`. <br>如果此 `char` 没有小写映射，则迭代器将产生相同的 `char`。<br>
    ///
    /// If this `char` has a one-to-one lowercase mapping given by the [Unicode Character Database][ucd] [`UnicodeData.txt`], the iterator yields that `char`. <br>如果此 `char` 具有 [Unicode 字符数据库][ucd] [`UnicodeData.txt`] 给出的一对一小写映射，则迭代器将产生该 `char`。<br>
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// If this `char` requires special considerations (e.g. multiple `char`s) the iterator yields the `char`(s) given by [`SpecialCasing.txt`]. <br>如果此 `char` 需要特殊考虑 (例如，多个 char)，则迭代器将产生 [`SpecialCasing.txt`] 给定的 char。<br>
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// This operation performs an unconditional mapping without tailoring. <br>此操作无需裁剪即可执行无条件映射。<br> That is, the conversion is independent of context and language. <br>即，转换独立于上下文和语言。<br>
    ///
    /// In the [Unicode Standard], Chapter 4 (Character Properties) discusses case mapping in general and Chapter 3 (Conformance) discusses the default algorithm for case conversion. <br>在 [Unicode 标准][Unicode Standard] 中，第 4 章 (字符属性) 通常讨论大小写映射，而第 3 章 (一致性) 讨论大小写转换的默认算法。<br>
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// As an iterator: <br>作为迭代器：<br>
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Using `println!` directly: <br>直接使用 `println!`：<br>
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Both are equivalent to: <br>两者都等同于：<br>
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Using [`to_string`](../std/string/trait.ToString.html#tymethod.to_string): <br>使用 [`to_string`](../std/string/trait.ToString.html#tymethod.to_string)：<br>
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Sometimes the result is more than one character: <br>有时结果是多个字符：<br>
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Characters that do not have both uppercase and lowercase convert into themselves. <br>同时没有大写和小写字母的字符会转换成自己。<br>
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the lowercase character as a new iterator, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Returns an iterator that yields the uppercase mapping of this `char` as one or more <br>返回一个迭代器，该迭代器将这个 `char` 的大写映射生成为一个或多个<br>
    /// `char`s.
    ///
    /// If this `char` does not have an uppercase mapping, the iterator yields the same `char`. <br>如果此 `char` 没有大写映射，则迭代器生成相同的 `char`。<br>
    ///
    /// If this `char` has a one-to-one uppercase mapping given by the [Unicode Character Database][ucd] [`UnicodeData.txt`], the iterator yields that `char`. <br>如果此 `char` 具有 [Unicode 字符数据库][ucd] [`UnicodeData.txt`] 给出的一对一大写映射，则迭代器将产生该 `char`。<br>
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// If this `char` requires special considerations (e.g. multiple `char`s) the iterator yields the `char`(s) given by [`SpecialCasing.txt`]. <br>如果此 `char` 需要特殊考虑 (例如，多个 char)，则迭代器将产生 [`SpecialCasing.txt`] 给定的 char。<br>
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// This operation performs an unconditional mapping without tailoring. <br>此操作无需裁剪即可执行无条件映射。<br> That is, the conversion is independent of context and language. <br>即，转换独立于上下文和语言。<br>
    ///
    /// In the [Unicode Standard], Chapter 4 (Character Properties) discusses case mapping in general and Chapter 3 (Conformance) discusses the default algorithm for case conversion. <br>在 [Unicode 标准][Unicode Standard] 中，第 4 章 (字符属性) 通常讨论大小写映射，而第 3 章 (一致性) 讨论大小写转换的默认算法。<br>
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// As an iterator: <br>作为迭代器：<br>
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Using `println!` directly: <br>直接使用 `println!`：<br>
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Both are equivalent to: <br>两者都等同于：<br>
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Using [`to_string`](../std/string/trait.ToString.html#tymethod.to_string): <br>使用 [`to_string`](../std/string/trait.ToString.html#tymethod.to_string)：<br>
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Sometimes the result is more than one character: <br>有时结果是多个字符：<br>
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Characters that do not have both uppercase and lowercase convert into themselves. <br>同时没有大写和小写字母的字符会转换成自己。<br>
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Note on locale <br>关于语言环境说明<br>
    ///
    /// In Turkish, the equivalent of 'i' in Latin has five forms instead of two: <br>在土耳其语中，相当于 'i' 的拉丁语具有 5 种形式，而不是 2 种形式：<br>
    ///
    /// * 'Dotless': I / ı, sometimes written ï <br>'Dotless': I/ı，有时写成 ï<br>
    /// * 'Dotted': İ / i
    ///
    /// Note that the lowercase dotted 'i' is the same as the Latin. <br>注意，小写的点缀 'i' 与拉丁字母相同。<br> Therefore:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// The value of `upper_i` here relies on the language of the text: if we're in `en-US`, it should be `"I"`, but if we're in `tr_TR`, it should be `"İ"`. <br>`upper_i` 的值在此取决于文本的语言：如果我们在 `en-US` 中，则应为 `"I"`，但如果我们在 `tr_TR` 中，则应为 `"İ"`。<br>
    /// `to_uppercase()` does not take this into account, and so: <br>`to_uppercase()` 没有考虑到这一点，因此：<br>
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// holds across languages. <br>适用于多种语言。<br>
    ///
    ///
    ///
    ///
    #[must_use = "this returns the uppercase character as a new iterator, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Checks if the value is within the ASCII range. <br>检查该值是否在 ASCII 范围内。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Makes a copy of the value in its ASCII upper case equivalent. <br>使值的副本等效于其 ASCII 大写字母。<br>
    ///
    /// ASCII letters 'a' to 'z' are mapped to 'A' to 'Z', but non-ASCII letters are unchanged. <br>ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不变。<br>
    ///
    /// To uppercase the value in-place, use [`make_ascii_uppercase()`]. <br>要就地将值大写，请使用 [`make_ascii_uppercase()`]。<br>
    ///
    /// To uppercase ASCII characters in addition to non-ASCII characters, use [`to_uppercase()`]. <br>要除非 ASCII 字符外还使用大写 ASCII 字符，请使用 [`to_uppercase()`]。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[must_use = "to uppercase the value in-place, use `make_ascii_uppercase()`"]
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Makes a copy of the value in its ASCII lower case equivalent. <br>以等效的 ASCII 小写形式复制值。<br>
    ///
    /// ASCII letters 'A' to 'Z' are mapped to 'a' to 'z', but non-ASCII letters are unchanged. <br>ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不变。<br>
    ///
    /// To lowercase the value in-place, use [`make_ascii_lowercase()`]. <br>要就地小写该值，请使用 [`make_ascii_lowercase()`]。<br>
    ///
    /// To lowercase ASCII characters in addition to non-ASCII characters, use [`to_lowercase()`]. <br>要除非 ASCII 字符外还使用小写 ASCII 字符，请使用 [`to_lowercase()`]。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[must_use = "to lowercase the value in-place, use `make_ascii_lowercase()`"]
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Checks that two values are an ASCII case-insensitive match. <br>检查两个值是否为 ASCII 不区分大小写的匹配。<br>
    ///
    /// Equivalent to <code>[to_ascii_lowercase]\(a) == [to_ascii_lowercase]\(b)</code>. <br>相当于 <code>[to_ascii_lowercase]\(a) == [to_ascii_lowercase]\(b)</code>。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    ///
    /// [to_ascii_lowercase]: #method.to_ascii_lowercase
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Converts this type to its ASCII upper case equivalent in-place. <br>将此类型就地转换为其 ASCII 大写等效项。<br>
    ///
    /// ASCII letters 'a' to 'z' are mapped to 'A' to 'Z', but non-ASCII letters are unchanged. <br>ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不变。<br>
    ///
    /// To return a new uppercased value without modifying the existing one, use [`to_ascii_uppercase()`]. <br>要返回新的大写值而不修改现有值，请使用 [`to_ascii_uppercase()`]。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Converts this type to its ASCII lower case equivalent in-place. <br>将此类型就地转换为其 ASCII 小写等效项。<br>
    ///
    /// ASCII letters 'A' to 'Z' are mapped to 'a' to 'z', but non-ASCII letters are unchanged. <br>ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不变。<br>
    ///
    /// To return a new lowercased value without modifying the existing one, use [`to_ascii_lowercase()`]. <br>要返回新的小写值而不修改现有值，请使用 [`to_ascii_lowercase()`]。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Checks if the value is an ASCII alphabetic character: <br>检查值是否为 ASCII 字母字符：<br>
    ///
    /// - U+0041 'A' ..= U+005A 'Z', or
    /// - U+0061 'a' ..= U+007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc = '\x1b';
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Checks if the value is an ASCII uppercase character: <br>检查值是否为 ASCII 大写字符：<br>
    /// U+0041 'A' ..= U+005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc = '\x1b';
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Checks if the value is an ASCII lowercase character: <br>检查值是否为 ASCII 小写字符：<br>
    /// U+0061 'a' ..= U+007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc = '\x1b';
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Checks if the value is an ASCII alphanumeric character: <br>检查值是否为 ASCII 字母数字字符：<br>
    ///
    /// - U+0041 'A' ..= U+005A 'Z', or
    /// - U+0061 'a' ..= U+007A 'z', or
    /// - U+0030 '0' ..= U+0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc = '\x1b';
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Checks if the value is an ASCII decimal digit: <br>检查值是否为 ASCII 十进制数字：<br>
    /// U+0030 '0' ..= U+0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc = '\x1b';
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Checks if the value is an ASCII hexadecimal digit: <br>检查值是否为 ASCII 十六进制数字：<br>
    ///
    /// - U+0030 '0' ..= U+0039 '9', or
    /// - U+0041 'A' ..= U+0046 'F', or
    /// - U+0061 'a' ..= U+0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc = '\x1b';
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Checks if the value is an ASCII punctuation character: <br>检查值是否为 ASCII 标点符号：<br>
    ///
    /// - U+0021 ..= U+002F `! " # $ % & ' ( ) * + , - . /`, or
    /// - U+003A ..= U+0040 `: ; < = > ? @`, or
    /// - U+005B ..= U+0060 ``[ \ ] ^ _ ` ``, or
    /// - U+007B ..= U+007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc = '\x1b';
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Checks if the value is an ASCII graphic character: <br>检查值是否为 ASCII 图形字符：<br>
    /// U+0021 '!' ..= U+007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc = '\x1b';
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Checks if the value is an ASCII whitespace character: <br>检查值是否为 ASCII 空格字符：<br>
    /// U+0020 SPACE, U+0009 HORIZONTAL TAB, U+000A LINE FEED, U+000C FORM FEED, or U+000D CARRIAGE RETURN. <br>U+0020 空格、U+0009 水平制表符、U+000A 换行、U+000C 换页或 U+000D 回车。<br>
    ///
    /// Rust uses the WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw]. <br>Rust 使用 WhatWG 基础标准的 [ASCII 空格的定义][infra-aw]。<br> There are several other definitions in wide use. <br>还有其他几种广泛使用的定义。<br>
    /// For instance, [the POSIX locale][pct] includes U+000B VERTICAL TAB as well as all the above characters, but—from the very same specification—[the default rule for "field splitting" in the Bourne shell][bfs] considers *only* SPACE, HORIZONTAL TAB, and LINE FEED as whitespace. <br>例如，[POSIX 语言环境][pct] 包括 U+000B 垂直标签以及所有上述字符，但是 - 从相同的规格来看 -[Bourne shell 中 "field splitting" 的默认规则][bfs] 仅考虑空格，水平标签和 LINE FEED 作为空白。<br>
    ///
    ///
    /// If you are writing a program that will process an existing file format, check what that format's definition of whitespace is before using this function. <br>如果要编写将处理现有文件格式的程序，请在使用此函数之前检查该格式的空格定义。<br>
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc = '\x1b';
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Checks if the value is an ASCII control character: <br>检查值是否为 ASCII 控制字符：<br>
    /// U+0000 NUL ..= U+001F UNIT SEPARATOR, or U+007F DELETE. <br>U+0000 NUL ..= U+001F 单元分隔符，或 U+007F 删除。<br>
    /// Note that most ASCII whitespace characters are control characters, but SPACE is not. <br>请注意，大多数 ASCII 空格字符是控制字符，而 SPACE 不是。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc = '\x1b';
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

pub(crate) struct EscapeDebugExtArgs {
    /// Escape Extended Grapheme codepoints? <br>转义扩展字素代码点？<br>
    pub(crate) escape_grapheme_extended: bool,

    /// Escape single quotes? <br>转义单引号？<br>
    pub(crate) escape_single_quote: bool,

    /// Escape double quotes? <br>转义双引号？<br>
    pub(crate) escape_double_quote: bool,
}

impl EscapeDebugExtArgs {
    pub(crate) const ESCAPE_ALL: Self = Self {
        escape_grapheme_extended: true,
        escape_single_quote: true,
        escape_double_quote: true,
    };
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Encodes a raw u32 value as UTF-8 into the provided byte buffer, and then returns the subslice of the buffer that contains the encoded character. <br>将原始 u32 值编码为 UTF-8 到提供的字节缓冲区中，然后返回包含编码字符的缓冲区的子切片。<br>
///
///
/// Unlike `char::encode_utf8`, this method also handles codepoints in the surrogate range. <br>与 `char::encode_utf8` 不同，此方法还处理代理范围内的代码点。<br>
/// (Creating a `char` in the surrogate range is UB.) The result is valid [generalized UTF-8] but not valid UTF-8. <br>(在代理范围内创建 `char` 是 UB。) 结果是有效的 [广义的 UTF-8]，但无效的 UTF-8。<br>
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics if the buffer is not large enough. <br>如果缓冲区不够大，就会出现 panics。<br>
/// A buffer of length four is large enough to encode any `char`. <br>长度为四的缓冲区足够大，可以对任何 `char` 进行编码。<br>
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Encodes a raw u32 value as UTF-16 into the provided `u16` buffer, and then returns the subslice of the buffer that contains the encoded character. <br>将原始 u32 值编码为 UTF-16 到提供的 `u16` 缓冲区中，然后返回包含编码字符的缓冲区的子切片。<br>
///
///
/// Unlike `char::encode_utf16`, this method also handles codepoints in the surrogate range. <br>与 `char::encode_utf16` 不同，此方法还处理代理范围内的代码点。<br>
/// (Creating a `char` in the surrogate range is UB.) <br>(在代理范围内创建 `char` 是 UB。)<br>
///
/// # Panics
///
/// Panics if the buffer is not large enough. <br>如果缓冲区不够大，就会出现 panics。<br>
/// A buffer of length 2 is large enough to encode any `char`. <br>长度为 2 的缓冲区足够大，可以对任何 `char` 进行编码。<br>
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SAFETY: each arm checks whether there are enough bits to write into <br>每个 arm 检查是否有足够的位可写入<br>
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // The BMP falls through <br>BMP 失败了<br>
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Supplementary planes break into surrogates. <br>辅助展开分解为代理。<br>
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}
