Hello, welcome to `std::simd`! <br>您好，欢迎来到 `std::simd`!<br>

It seems this pull request template checklist was created while a lot of vector math ops were being implemented, and only really applies to ops. <br>看起来这个拉取请求模板清单是在许多 vector 数学运算被实现时创建的，并且只真正适用于运算。<br> Feel free to delete everything here if it's not applicable, or ask for help if you're not sure what it means! <br>如果不适用，请随意删除这里的所有内容，或者如果不确定这意味着什么，请寻求帮助！<br>

For a given vector math operation on TxN, please add tests for interactions with: <br>对于 TxN 上的给定 vector 数学运算，请添加与以下交互的测试：<br>
  - [ ] `T::MAX`
  - [ ] `T::MIN`
  - [ ] -1
  - [ ] 1
  - [ ] 0


For a given vector math operation on TxN where T is a float, please add tests for test interactions with: <br>对于 TxN 上的给定 vector 数学运算，其中 T 是浮点数，请添加测试以测试与以下各项的交互：<br>
  - [ ] a really large number, larger than the mantissa <br>[ ] 一个非常大的数字，比尾数还要大<br>
  - [ ] a really small "subnormal" number <br>[ ] 一个非常小的 "subnormal" 数字<br>
  - [ ] NaN
  - [ ] Infinity <br>[ ] 无穷大<br>
  - [ ] Negative Infinity <br>[ ] 负无穷大<br>
