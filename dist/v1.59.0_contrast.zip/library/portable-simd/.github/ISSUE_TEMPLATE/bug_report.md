---
name: Bug Report about: Create a bug report for Rust. <br>名称：错误报告关于：为 Rust 创建错误报告。<br>
labels: C-bug <br>标签: C-bug<br>
---
<!--
Thank you for filing a bug report! <br>感谢您提交错误报告！<br> 🐛 Please provide a short summary of the bug, along with any information you feel relevant to replicating the bug. <br>🐛 请提供错误的简短摘要，以及您认为与复制错误相关的任何信息。<br>

-->

I tried this code: <br>我试过这个代码：<br>

```rust
<code>
```

I expected to see this happen: *explanation* <br>我希望看到这种情况发生: *解释*<br>

Instead, this happened: *explanation* <br>相反，这发生了: *解释*<br>

### Meta

`rustc --version --verbose`:

```
<version>
```

`crate version in Cargo.toml`:

```toml
[dependencies]
stdsimd = 
```
<!-- If this specifies the repo at HEAD, please include the latest commit. <br>如果这在 HEAD 指定 repo，请包括最新的提交。<br> -->

<!--
If a backtrace is available, please include a backtrace in the code block by setting `RUST_BACKTRACE=1` in your environment. <br>如果回溯可用，请通过在您的环境中设置 `RUST_BACKTRACE=1` 在代码块中包含回溯。<br> e.g. 
`RUST_BACKTRACE=1 cargo build`.
-->
<details><summary>Backtrace</summary>
<p>

```
<backtrace>
```

</p>
</details>
