---
name: Feature Request about: Request an addition to the core::simd API labels: C-feature-request <br>名称：特性请求关于：请求添加到 core::simd API 标签: C-feature-request<br>
---
<!--
  Hello!

  We are very interested in any feature requests you may have. <br>我们对您可能提出的任何特性请求非常感兴趣。<br>

  However, please be aware that core::simd exists to address concerns with creating a portable SIMD API for Rust. <br>但是，请注意 core::simd 的存在是为了解决为 Rust 创建可移植 SIMD API 的问题。<br>
  
  Requests for extensions to compiler features, such as `target_feature`, binary versioning for SIMD APIs, or <br>对编译器特性扩展的请求，例如 `target_feature`、SIMD API 的二进制版本控制，或<br>
  improving specific compilation issues in general should be discussed at https://internals.rust-lang.org/
-->
