# The Rust standard library's portable SIMD API <br>Rust 标准库的可移植 SIMD API<br>
![Build Status](https://github.com/rust-lang/portable-simd/actions/workflows/ci.yml/badge.svg?branch=master)

Code repository for the [Portable SIMD Project Group](https://github.com/rust-lang/project-portable-simd). <br>[便携式 SIMD 项目组](https://github.com/rust-lang/project-portable-simd) 的代码仓库。<br>
Please refer to [CONTRIBUTING.md](./CONTRIBUTING.md) for our contributing guidelines. <br>请参见 [CONTRIBUTING.md](./CONTRIBUTING.md) 了解我们的贡献指南。<br>

The docs for this crate are published from the main branch. <br>这个 crate 的文档是从主分支发布的。<br>
You can [read them here][docs]. <br>您可以 [在这里阅读][docs]。<br>

If you have questions about SIMD, we have begun writing a [guide][simd-guide]. <br>如果您对 SIMD 有疑问，我们已经开始编写 [指南][simd-guide]。<br>
We can also be found on [Zulip][zulip-project-portable-simd]. <br>我们也可以在 [Zulip][zulip-project-portable-simd] 上找到。<br>

If you are interested in support for a specific architecture, you may want [stdarch] instead. <br>如果您对支持特定架构感兴趣，您可能需要 [stdarch]。<br>

## Hello World <br>您好，世界<br>

Now we're gonna dip our toes into this world with a small SIMD "Hello, World!" example. <br>现在我们将通过一个小的 SIMD "Hello, World!" 示例深入这个世界。<br> Make sure your compiler is up to date and using `nightly`. <br>确保您的编译器是最新的并使用 `nightly`。<br> We can do that by running <br>我们可以通过运行来做到这一点<br> 

```bash
rustup update -- nightly
```

or by setting up `rustup default nightly` or else with `cargo +nightly {build,test,run}`. <br>或通过设置 `rustup default nightly` 或使用 `cargo +nightly {build,test,run}`。<br> After updating, run <br>更新后运行<br> 
```bash
cargo new hellosimd
```
to create a new crate. <br>创建一个新的 crate。<br> Edit `hellosimd/Cargo.toml` to be <br>编辑 `hellosimd/Cargo.toml` 为<br> 
```toml
[package]
name = "hellosimd"
version = "0.1.0"
edition = "2018"
[dependencies]
core_simd = { git = "https://github.com/rust-lang/portable-simd" }
```

and finally write this in `src/main.rs`: <br>最后在 `src/main.rs` 中写下这个：<br>
```rust
use core_simd::*;
fn main() {
    let a = f32x4::splat(10.0);
    let b = f32x4::from_array([1.0, 2.0, 3.0, 4.0]);
    println!("{:?}", a + b);
}
```

Explanation: We import all the bindings from the crate with the first line. <br>说明：我们使用第一行从 crate 导入所有绑定。<br> Then, we construct our SIMD vectors with methods like `splat` or `from_array`. <br>然后，我们使用 `splat` 或 `from_array` 等方法构建我们的 SIMD vectors。<br> Finally, we can use operators on them like `+` and the appropriate SIMD instructions will be carried out. <br>最后，我们可以像 `+` 一样对它们使用相同，并且将执行适当的 SIMD 指令。<br> When we run `cargo run` you should get `[11.0, 12.0, 13.0, 14.0]`. <br>当我们运行 `cargo run` 时，您应该得到 `[11.0, 12.0, 13.0, 14.0]`。<br>

## Code Organization <br>代码组织<br>

Currently the crate is organized so that each element type is a file, and then the 64-bit, 128-bit, 256-bit, and 512-bit vectors using those types are contained in said file. <br>目前 crate 的组织方式是每个元素类型都是一个文件，然后使用这些类型的 64 位、128 位、256 位和 512 位 vectors 包含在所述文件中。<br>

All types are then exported as a single, flat module. <br>然后将所有类型导出为单个扁平模块。<br>

Depending on the size of the primitive type, the number of lanes the vector will have varies. <br>根据原始类型的大小，vector 的 lanes 数会有所不同。<br> For example, 128-bit vectors have four `f32` lanes and two `f64` lanes. <br>例如，128 位 vectors 有四个 `f32` lanes 和两个 `f64` lanes。<br>

The supported element types are as follows: <br>支持的元素类型如下：<br>
* **Floating Point:** `f32`, `f64` <br>**浮点数：** `f32`、`f64`<br>
* **Signed Integers:** `i8`, `i16`, `i32`, `i64`, `i128`, `isize` <br>**有符号整数：** `i8`、`i16`、`i32`、`i64`、`i128`、`isize`<br>
* **Unsigned Integers:** `u8`, `u16`, `u32`, `u64`, `u128`, `usize` <br>**无符号整数：** `u8`、`u16`、`u32`、`u64`、`u128`、`usize`<br>
* **Masks:** `mask8`, `mask16`, `mask32`, `mask64`, `mask128`, `masksize` <br>**掩码：** `mask8`、`mask16`、`mask32`、`mask64`、`mask128`、`masksize`<br>

Floating point, signed integers, and unsigned integers are the [primitive types](https://doc.rust-lang.org/core/primitive/index.html) you're already used to. <br>浮点数、有符号整数和无符号整数是您已经习惯的 [原始类型](https://doc.rust-lang.org/core/primitive/index.html)。<br>
The `mask` types are "truthy" values, but they use the number of bits in their name instead of just 1 bit like a normal `bool` uses. <br>`mask` 类型是 "truthy" 值，但它们使用名称中的位数，而不是像普通 `bool` 使用的那样仅使用 1 位。<br>

[simd-guide]: ./beginners-guide.md
[zulip-project-portable-simd]: https://rust-lang.zulipchat.com/#narrow/stream/257879-project-portable-simd
[stdarch]: https://github.com/rust-lang/stdarch
[docs]: https://rust-lang.github.io/portable-simd/core_simd
