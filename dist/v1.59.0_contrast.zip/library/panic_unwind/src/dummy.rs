//! Unwinding for unsupported target. <br>展开不受支持的目标。<br>
//!
//! Stubs that simply abort for targets that don't support unwinding otherwise. <br>对不支持展开的目标简单地中止的 stubs。<br>

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}
