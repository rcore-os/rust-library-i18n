//! Unwinding panics for Miri. <br>展开 Miri 的 panics。<br>
use alloc::boxed::Box;
use core::any::Any;

// The type of the payload that the Miri engine propagates through unwinding for us. <br>Miri 引擎通过展开为我们传播的有效载荷的类型。<br>
// Must be pointer-sized. <br>必须为指针大小。<br>
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-provided extern function to begin unwinding. <br>Miri 提供的外部函数开始展开。<br>
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // The payload we pass to `miri_start_panic` will be exactly the argument we get in `cleanup` below. <br>我们传递给 `miri_start_panic` 的有效载荷将恰好是我们在下面的 `cleanup` 中获得的参数。<br>
    // So we just box it up once, to get something pointer-sized. <br>因此，我们只需将 box 设置一次，即可获得指针大小的对象。<br>
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Recover the underlying `Box`. <br>恢复底层 `Box`。<br>
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}
