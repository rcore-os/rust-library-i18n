//! Backtrace support using libunwind/gcc_s/etc APIs. <br>使用 libunwind/gcc_s/etc API 的 Backtrace 支持。<br>
//!
//! This module contains the ability to unwind the stack using libunwind-style APIs. <br>该模块包含了使用 libunwind 样式的 API 展开栈的功能。<br>
//! Note that there's a whole bunch of implementations of the libunwind-like API, and this is just trying to be compatible with most of them all at once instead of being picky. <br>请注意，有很多类似 libunwind 的 API 的实现，这只是想一次与大多数兼容，而不是挑剔。<br>
//!
//!
//! The libunwind API is powered by `_Unwind_Backtrace` and is in practice very reliable at generating a backtrace. <br>libunwind API 由 `_Unwind_Backtrace` 提供支持，实际上在生成回溯方面非常可靠。<br>
//! It's not entirely clear how it does it (frame pointers? eh_frame info? both?) but it seems to work! <br>尚不清楚它是如何工作的 (帧指针？eh_frame 信息？两者都有？)，但似乎可行！<br>
//!
//! Most of the complexity of this module is handling the various platform differences across libunwind implementations. <br>该模块的大部分复杂性是处理 libunwind 实现中的各种平台差异。<br>
//! Otherwise this is a pretty straightforward Rust binding to the libunwind APIs. <br>否则，这是对 libunwind API 的非常简单的 Rust 绑定。<br>
//!
//! This is the default unwinding API for all non-Windows platforms currently. <br>这是当前所有非 Windows 平台的默认展开 API。<br>
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// With a raw libunwind pointer it should only ever be access in a readonly threadsafe fashion, so it's `Sync`. <br>使用原始的 libunwind 指针，它只能以只读线程安全的方式进行访问，因此它是 `Sync`。<br>
// When sending to other threads via `Clone` we always switch to a version which doesn't retain interior pointers, so we should be `Send` as well. <br>通过 `Clone` 发送到其他线程时，我们总是切换到不保留内部指针的版本，因此我们也应该是 `Send`。<br>
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // The macOS linker emits a "compact" unwind table that only includes an entry for a function if that function either has an LSDA or its encoding differs from that of the previous entry. <br>macOS 链接器发出一个 "compact" 展开表，如果函数有 LSDA 或其编码与前一个条目不同，则该表只包含该函数的一个条目。<br>
        // Consequently, on macOS, `_Unwind_FindEnclosingFunction` is unreliable (it can return a pointer to some totally unrelated function). <br>因此，在 macOS 上，`_Unwind_FindEnclosingFunction` 是不可靠的 (它可以返回一个指向一些完全不相关的函数的指针)。<br>
        // Instead, we just always return the ip. <br>相反，我们总是返回 ip。<br>
        //
        // https://github.com/rust-lang/rust/issues/74771#issuecomment-664056788
        //
        // Note the `skip_inner_frames.rs` test is skipped on macOS due to this clause, and if this is fixed that test in theory can be run on macOS! <br>请注意，由于此条款，在 macOS 上跳过了 `skip_inner_frames.rs` 测试，如果修复了该问题，理论上可以在 macOS 上运行该测试！<br>
        //
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Unwind library interface used for backtraces <br>展开用于回溯的库接口<br>
///
/// Note that dead code is allowed as here are just bindings iOS doesn't use all of them it but adding more platform-specific configs pollutes the code too much <br>请注意，死代码是允许的，因为这里只是绑定 iOS 并没有使用所有绑定，但是添加更多特定于平台的配置会严重污染代码<br>
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // used only by ARM EABI <br>仅由 ARM EABI 使用<br>
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;
    }

    cfg_if::cfg_if! {
        // available since GCC 4.2.0, should be fine for our purpose <br>自 GCC 4.2.0 以来可用，应该可以满足我们的目的<br>
        if #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "horizon", target_arch = "arm"))
        ))] {
            extern "C" {
                pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
                pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

                #[cfg(not(all(target_os = "linux", target_arch = "s390x")))]
                // This function is a misnomer: rather than getting this frame's Canonical Frame Address (aka the caller frame's SP) it returns this frame's SP. <br>此函数用词不当：它没有获得此框架的规范框架地址 (即调用者框架的 SP)，而是返回了该框架的 SP。<br>
                //
                //
                // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
                //
                #[link_name = "_Unwind_GetCFA"]
                pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

            }

            // s390x uses a biased CFA value, therefore we need to use _Unwind_GetGR to get the stack pointer register (%r15) instead of relying on _Unwind_GetCFA. <br>s390x 使用了一个有偏差的 CFA 值，因此我们需要使用 _Unwind_GetGR 来获取栈指针寄存器 (%r15)，而不是依赖于 _Unwind_GetCFA。<br>
            //
            //
            #[cfg(all(target_os = "linux", target_arch = "s390x"))]
            pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
                extern "C" {
                    pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
                }
                _Unwind_GetGR(ctx, 15)
            }
        } else {
            // On android and arm, the function `_Unwind_GetIP` and a bunch of others are macros, so we define functions containing the expansion of the macros. <br>在 android 和 arm 上，函数 `_Unwind_GetIP` 和其他许多函数都是宏，因此我们定义了包含宏扩展的函数。<br>
            //
            //
            // TODO: link to the header file that defines these macros, if you can find it. <br>链接到定义这些宏的头文件 (如果可以找到的话)。<br>
            // (I, fitzgen, cannot find the header file that some of these macro expansions were originally borrowed from.) <br>(我，fitzgen，找不到这些宏扩展中的某些最初从中借用的头文件。)<br>
            //
            //
            #[repr(C)]
            enum _Unwind_VRS_Result {
                _UVRSR_OK = 0,
                _UVRSR_NOT_IMPLEMENTED = 1,
                _UVRSR_FAILED = 2,
            }
            #[repr(C)]
            enum _Unwind_VRS_RegClass {
                _UVRSC_CORE = 0,
                _UVRSC_VFP = 1,
                _UVRSC_FPA = 2,
                _UVRSC_WMMXD = 3,
                _UVRSC_WMMXC = 4,
            }
            #[repr(C)]
            enum _Unwind_VRS_DataRepresentation {
                _UVRSD_UINT32 = 0,
                _UVRSD_VFPX = 1,
                _UVRSD_FPAX = 2,
                _UVRSD_UINT64 = 3,
                _UVRSD_FLOAT = 4,
                _UVRSD_DOUBLE = 5,
            }

            type _Unwind_Word = libc::c_uint;
            extern "C" {
                fn _Unwind_VRS_Get(
                    ctx: *mut _Unwind_Context,
                    klass: _Unwind_VRS_RegClass,
                    word: _Unwind_Word,
                    repr: _Unwind_VRS_DataRepresentation,
                    data: *mut c_void,
                ) -> _Unwind_VRS_Result;
            }

            pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
                let mut val: _Unwind_Word = 0;
                let ptr = &mut val as *mut _Unwind_Word;
                let _ = _Unwind_VRS_Get(
                    ctx,
                    _Unwind_VRS_RegClass::_UVRSC_CORE,
                    15,
                    _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                    ptr as *mut c_void,
                );
                (val & !1) as libc::uintptr_t
            }

            // R13 is the stack pointer on arm. <br>R13 是 arm 上的栈指针。<br>
            const SP: _Unwind_Word = 13;

            pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
                let mut val: _Unwind_Word = 0;
                let ptr = &mut val as *mut _Unwind_Word;
                let _ = _Unwind_VRS_Get(
                    ctx,
                    _Unwind_VRS_RegClass::_UVRSC_CORE,
                    SP,
                    _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                    ptr as *mut c_void,
                );
                val as libc::uintptr_t
            }

            // This function also doesn't exist on Android or ARM/Linux, so make it a no-op. <br>Android 或 ARM/Linux 上也不存在此函数，因此请使其成为 no-op。<br>
            //
            pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
                pc
            }
        }
    }
}
