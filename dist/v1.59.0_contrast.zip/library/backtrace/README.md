# backtrace-rs

[Documentation](https://docs.rs/backtrace)

A library for acquiring backtraces at runtime for Rust. <br>一个用于在运行时获取 Rust 的回溯的库。<br>
This library aims to enhance the support of the standard library by providing a programmatic interface to work with, but it also supports simply easily printing the current backtrace like libstd's panics. <br>该库旨在通过提供程序接口来增强对标准库的支持，但它也支持轻松轻松地打印当前回溯，如 libstd 的 panics。<br>

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

To simply capture a backtrace and defer dealing with it until a later time, you can use the top-level `Backtrace` type. <br>要简单地捕获回溯跟踪并将其推迟到以后再处理，可以使用顶级 `Backtrace` 类型。<br>

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

If, however, you'd like more raw access to the actual tracing functionality, you can use the `trace` and `resolve` functions directly. <br>但是，如果您希望对原始的跟踪功能有更多的原始访问权限，则可以直接使用 `trace` 和 `resolve` 函数。<br>

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Resolve this instruction pointer to a symbol name <br>将此指令指针解析为符号名称<br>
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // keep going to the next frame <br>继续前进到下一帧<br>
    });
}
```

# License

This project is licensed under either of <br>该项目获得以下任一许可<br>

 * Apache License, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) or https://www.apache.org/licenses/LICENSE-2.0) <br>Apache 许可证，版本 2.0、([LICENSE-APACHE](LICENSE-APACHE) 或 https://www.apache.org/licenses/LICENSE-2.0)<br>
 * MIT license ([LICENSE-MIT](LICENSE-MIT) or https://opensource.org/licenses/MIT) <br>MIT 许可证 ([LICENSE-MIT](LICENSE-MIT) 或 https://opensource.org/licenses/MIT)<br>

at your option. <br>由您选择。<br>

### Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted for inclusion in backtrace-rs by you, as defined in the Apache-2.0 license, shall be dual licensed as above, without any additional terms or conditions. <br>除非您明确声明，否则 Apache-2.0 许可证中定义的由您有意提交以供包含在 backtrace-rs 中的任何贡献均应如上所述获得双重许可，且无任何其他条款或条件。<br>
