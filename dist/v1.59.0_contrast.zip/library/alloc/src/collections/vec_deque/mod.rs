//! A double-ended queue implemented with a growable ring buffer. <br>使用可增长的环形缓冲区实现的双端队列。<br>
//!
//! This queue has *O*(1) amortized inserts and removals from both ends of the container. <br>此队列具有 *O*(1) 容器两端的摊销插入和删除。<br>
//! It also has *O*(1) indexing like a vector. <br>它还具有像 vector 一样的 *O*(1) 索引。<br>
//! The contained elements are not required to be copyable, and the queue will be sendable if the contained type is sendable. <br>所包含的元素不需要是可复制的，并且如果所包含的类型是可发送的，则队列将是可发送的。<br>
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::alloc::{Allocator, Global};
use crate::collections::TryReserveError;
use crate::collections::TryReserveErrorKind;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2^3 - 1
const MINIMUM_CAPACITY: usize = 1; // 2 - 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (usize::BITS - 1); // Largest possible power of two <br>可能的最大两倍<br>

/// A double-ended queue implemented with a growable ring buffer. <br>使用可增长的环形缓冲区实现的双端队列。<br>
///
/// The "default" usage of this type as a queue is to use [`push_back`] to add to the queue, and [`pop_front`] to remove from the queue. <br>"default" 作为队列的这种用法是使用 [`push_back`] 添加到队列，使用 [`pop_front`] 从队列中删除。<br>
///
/// [`extend`] and [`append`] push onto the back in this manner, and iterating over `VecDeque` goes front to back. <br>[`extend`] 和 [`append`] 以这种方式推到后面，并从前到后迭代 `VecDeque`。<br>
///
/// A `VecDeque` with a known list of items can be initialized from an array: <br>可以从数组初始化具有已知项列表的 `VecDeque`：<br>
///
/// ```
/// use std::collections::VecDeque;
///
/// let deq = VecDeque::from([-1, 0, 1]);
/// ```
///
/// Since `VecDeque` is a ring buffer, its elements are not necessarily contiguous in memory. <br>由于 `VecDeque` 是环形缓冲区，因此它的元素在内存中不一定是连续的。<br>
/// If you want to access the elements as a single slice, such as for efficient sorting, you can use [`make_contiguous`]. <br>如果要以单个切片的形式访问元素 (例如为了进行有效的排序)，则可以使用 [`make_contiguous`]。<br>
/// It rotates the `VecDeque` so that its elements do not wrap, and returns a mutable slice to the now-contiguous element sequence. <br>它旋转 `VecDeque`，以使其元素不环绕，并向当前连续的元素序列返回可变切片。<br>
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "VecDeque")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_insignificant_dtor]
pub struct VecDeque<
    T,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> {
    // tail and head are pointers into the buffer. <br>tail 和 head 是指向缓冲区的指针。<br>
    // Tail always points to the first element that could be read, Head always points to where data should be written. <br>Tail 总是指向可以读取的第一个元素，Head 总是指向应该写入数据的位置。<br>
    //
    // If tail == head the buffer is empty. <br>如果 tail == head，则缓冲区为空。<br> The length of the ringbuffer is defined as the distance between the two. <br>环形缓冲区的长度定义为两者之间的距离。<br>
    //
    tail: usize,
    head: usize,
    buf: RawVec<T, A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for VecDeque<T, A> {
    fn clone(&self) -> Self {
        let mut deq = Self::with_capacity_in(self.len(), self.allocator().clone());
        deq.extend(self.iter().cloned());
        deq
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for VecDeque<T, A> {
    fn drop(&mut self) {
        /// Runs the destructor for all items in the slice when it gets dropped (normally or during unwinding). <br>当切片被丢弃时 (正常情况下或在展开期间)，对切片中的所有项运行析构函数。<br>
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // use drop for [T]
            ptr::drop_in_place(front);
        }
        // RawVec handles deallocation <br>RawVec 处理重新分配<br>
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Creates an empty `VecDeque<T>`. <br>创建一个空的 `VecDeque<T>`。<br>
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T, A: Allocator> VecDeque<T, A> {
    /// Marginally more convenient <br>稍微方便一点<br>
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginally more convenient <br>稍微方便一点<br>
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // For zero sized types, we are always at maximum capacity <br>对于零大小类型，我们始终处于最大容量<br>
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Turn ptr into a slice <br>将 ptr 变成切片<br>
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Turn ptr into a mut slice <br>将 ptr 变成 mut 切片<br>
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Moves an element out of the buffer <br>将元素移出缓冲区<br>
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Writes an element into the buffer, moving it. <br>将元素写入缓冲区，然后将其移动。<br>
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Returns `true` if the buffer is at full capacity. <br>如果缓冲区已满，则返回 `true`。<br>
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Returns the index in the underlying buffer for a given logical element index. <br>返回给定逻辑元素索引的底层缓冲区中的索引。<br>
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Returns the index in the underlying buffer for a given logical element index + addend. <br>返回给定逻辑元素索引 + 加数的底层缓冲区中的索引。<br>
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Returns the index in the underlying buffer for a given logical element index - subtrahend. <br>返回给定逻辑元素索引 - 减数的底层缓冲区中的索引。<br>
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Copies a contiguous block of memory len long from src to dst <br>将一个连续的 len 长的内存块从 src 复制到 dst<br>
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Copies a contiguous block of memory len long from src to dst <br>将一个连续的 len 长的内存块从 src 复制到 dst<br>
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Copies a potentially wrapping block of memory len long from src to dest. <br>从 src 复制一个长度为 len 的潜在包装内存块到 dest。<br>
    /// (abs(dst - src) + len) must be no larger than cap() (There must be at most one continuous overlapping region between src and dest). <br>(abs(dst - src) + len) 不得大于 cap() (src 与 dest 之间最多应有一个连续的重叠区域)。<br>
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src doesn't wrap, dst doesn't wrap <br>src 不换行，dst 不换行<br>
                //
                //
                //        S . . .
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D . . .
                //
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst before src, src doesn't wrap, dst wraps <br>src 之前的 dst，src 不环绕，dst 环绕<br>
                //
                //
                //    S . . .
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] ..  D .
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src before dst, src doesn't wrap, dst wraps <br>dst 之前的 src，src 不换行，dst 换行<br>
                //
                //
                //              S . . .
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] ..  D .
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst before src, src wraps, dst doesn't wrap <br>src 之前的 dst，src 换行，dst 不换行<br>
                //
                //
                //    .. S .
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D . . .
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src before dst, src wraps, dst doesn't wrap <br>dst 之前的 src，src 换行，dst 不换行<br>
                //
                //
                //    .. S .
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D . . .
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst before src, src wraps, dst wraps <br>src 之前的 dst，src 换行，dst 换行<br>
                //
                //
                //    . .. S .
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] ..  D . .
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src before dst, src wraps, dst wraps <br>dst 之前的 src，src 换行，dst 换行<br>
                //
                //
                //    .. S . .
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G] . ..  D .
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Copies all values from `src` to `dst`, wrapping around if needed. <br>将所有值从 `src` 复制到 `dst`，并在需要时进行包装。<br>
    /// Assumes capacity is sufficient. <br>假设容量足够。<br>
    #[inline]
    unsafe fn copy_slice(&mut self, dst: usize, src: &[T]) {
        debug_assert!(src.len() <= self.cap());
        let head_room = self.cap() - dst;
        if src.len() <= head_room {
            unsafe {
                ptr::copy_nonoverlapping(src.as_ptr(), self.ptr().add(dst), src.len());
            }
        } else {
            let (left, right) = src.split_at(head_room);
            unsafe {
                ptr::copy_nonoverlapping(left.as_ptr(), self.ptr().add(dst), left.len());
                ptr::copy_nonoverlapping(right.as_ptr(), self.ptr(), right.len());
            }
        }
    }

    /// Frobs the head and tail sections around to handle the fact that we just reallocated. <br>绕着 head 和 tail 进行处理，以处理我们刚刚重新分配的事实。<br>
    /// Unsafe because it trusts old_capacity. <br>不安全，因为它信任 old_capacity。<br>
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Move the shortest contiguous section of the ring buffer T             H <br>移动环形缓冲区 TH 的最短连续部分<br>
        //
        //   [o o o o o o o . ]
        //    T             H A [o o o o o o o . . . . . . . . . ] H T
        //   [o o . o o o o o ]
        //          T             H B [. . . o o o o o o o . . . . . . ] H T
        //   [o o o o o . o o ]
        //              H                 T C [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Creates an empty `VecDeque`. <br>创建一个空的 `VecDeque`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    pub fn new() -> VecDeque<T> {
        VecDeque::new_in(Global)
    }

    /// Creates an empty `VecDeque` with space for at least `capacity` elements. <br>创建一个空的 `VecDeque`，其中至少有 `capacity` 元素的空间。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        Self::with_capacity_in(capacity, Global)
    }
}

impl<T, A: Allocator> VecDeque<T, A> {
    /// Creates an empty `VecDeque`. <br>创建一个空的 `VecDeque`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn new_in(alloc: A) -> VecDeque<T, A> {
        VecDeque::with_capacity_in(INITIAL_CAPACITY, alloc)
    }

    /// Creates an empty `VecDeque` with space for at least `capacity` elements. <br>创建一个空的 `VecDeque`，其中至少有 `capacity` 元素的空间。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> VecDeque<T, A> {
        assert!(capacity < 1_usize << usize::BITS - 1, "capacity overflow");
        // +1 since the ringbuffer always leaves one space empty <br>+1，因为环形缓冲区始终将一个空间留空<br>
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity_in(cap, alloc) }
    }

    /// Provides a reference to the element at the given index. <br>提供给定索引处元素的引用。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Provides a mutable reference to the element at the given index. <br>提供给定索引处元素的可变引用。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Swaps elements at indices `i` and `j`. <br>交换索引为 `i` 和 `j` 的元素。<br>
    ///
    /// `i` and `j` may be equal. <br>`i` 和 `j` 可能是相等的。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Panics
    ///
    /// Panics if either index is out of bounds. <br>如果任一索引越界，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Returns the number of elements the `VecDeque` can hold without reallocating. <br>返回 `VecDeque` 无需重新分配即可容纳的元素数。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Reserves the minimum capacity for exactly `additional` more elements to be inserted in the given `VecDeque`. <br>保留最小容量，以便在给定的 `VecDeque` 中精确插入 `additional` 个元素。<br>
    /// Does nothing if the capacity is already sufficient. <br>如果容量已经足够，则不执行任何操作。<br>
    ///
    /// Note that the allocator may give the collection more space than it requests. <br>请注意，分配器可能会给集合提供比其请求更多的空间。<br>
    /// Therefore capacity can not be relied upon to be precisely minimal. <br>因此，不能依靠容量来精确地将其最小化。<br>
    /// Prefer [`reserve`] if future insertions are expected. <br>如果预计将来会插入，则最好使用 [`reserve`]。<br>
    ///
    /// # Panics
    ///
    /// Panics if the new capacity overflows `usize`. <br>如果新容量溢出 `usize`，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Reserves capacity for at least `additional` more elements to be inserted in the given `VecDeque`. <br>为给定的 `VecDeque` 至少保留 `additional` 个要插入的元素保留容量。<br>
    /// The collection may reserve more space to avoid frequent reallocations. <br>该集合可以保留更多空间，以避免频繁的重新分配。<br>
    ///
    /// # Panics
    ///
    /// Panics if the new capacity overflows `usize`. <br>如果新容量溢出 `usize`，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Tries to reserve the minimum capacity for exactly `additional` more elements to be inserted in the given `VecDeque<T>`. <br>尝试保留最小容量，以便在给定的 `VecDeque<T>` 中精确插入 `additional` 个元素。<br>
    ///
    /// After calling `try_reserve_exact`, capacity will be greater than or equal to `self.len() + additional`. <br>调用 `try_reserve_exact` 后，容量将大于或等于 `self.len() + additional`。<br>
    /// Does nothing if the capacity is already sufficient. <br>如果容量已经足够，则不执行任何操作。<br>
    ///
    /// Note that the allocator may give the collection more space than it requests. <br>请注意，分配器可能会给集合提供比其请求更多的空间。<br>
    /// Therefore, capacity can not be relied upon to be precisely minimal. <br>因此，不能依靠容量来精确地最小化。<br>
    /// Prefer [`try_reserve`] if future insertions are expected. <br>如果希望将来插入，则首选 [`try_reserve`]。<br>
    ///
    /// [`try_reserve`]: VecDeque::try_reserve
    ///
    /// # Errors
    ///
    /// If the capacity overflows `usize`, or the allocator reports a failure, then an error is returned. <br>如果容量溢出 `usize`，或者分配器报告失败，则返回错误。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Pre-reserve the memory, exiting if we can't <br>预先保留内存，如果不能，则退出<br>
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Now we know this can't OOM(Out-Of-Memory) in the middle of our complex work <br>现在我们知道这不能 OOM(Out-Of-Memory) 完成我们复杂的工作<br>
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // very complicated <br>非常复杂<br>
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[stable(feature = "try_reserve", since = "1.57.0")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Tries to reserve capacity for at least `additional` more elements to be inserted in the given `VecDeque<T>`. <br>尝试为给 `VecDeque<T>` 至少插入 `additional` 个元素保留容量。<br>
    /// The collection may reserve more space to avoid frequent reallocations. <br>该集合可以保留更多空间，以避免频繁的重新分配。<br>
    /// After calling `try_reserve`, capacity will be greater than or equal to `self.len() + additional`. <br>调用 `try_reserve` 后，容量将大于或等于 `self.len() + additional`。<br>
    /// Does nothing if capacity is already sufficient. <br>如果容量已经足够，则不执行任何操作。<br>
    ///
    /// # Errors
    ///
    /// If the capacity overflows `usize`, or the allocator reports a failure, then an error is returned. <br>如果容量溢出 `usize`，或者分配器报告失败，则返回错误。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Pre-reserve the memory, exiting if we can't <br>预先保留内存，如果不能，则退出<br>
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Now we know this can't OOM in the middle of our complex work <br>现在我们知道在我们复杂的工作中这不能 OOM<br>
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // very complicated <br>非常复杂<br>
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[stable(feature = "try_reserve", since = "1.57.0")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveErrorKind::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Shrinks the capacity of the `VecDeque` as much as possible. <br>尽可能缩小 `VecDeque` 的容量。<br>
    ///
    /// It will drop down as close as possible to the length but the allocator may still inform the `VecDeque` that there is space for a few more elements. <br>它将 drop 到尽可能接近长度的位置，但分配器仍可能通知 `VecDeque` 还有空间容纳更多的元素。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Shrinks the capacity of the `VecDeque` with a lower bound. <br>降低 `VecDeque` 的容量。<br>
    ///
    /// The capacity will remain at least as large as both the length and the supplied value. <br>容量将至少保持与长度和提供的值一样大。<br>
    ///
    ///
    /// If the current capacity is less than the lower limit, this is a no-op. <br>如果当前容量小于下限，则为无操作。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "shrink_to", since = "1.56.0")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // We don't have to worry about an overflow as neither `self.len()` nor `self.capacity()` can ever be `usize::MAX`. <br>我们不必担心溢出，因为 `self.len()` 和 `self.capacity()` 都不可能是 `usize::MAX`。<br>
        // +1 as the ringbuffer always leaves one space empty. <br>+1，因为环形缓冲区始终将一个空间留空。<br>
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // There are three cases of interest: <br>有以下三种有趣的情况：<br>
            //   All elements are out of desired bounds Elements are contiguous, and head is out of desired bounds Elements are discontiguous, and tail is out of desired bounds <br>所有元素都超出期望的范围元素是连续的，并且头超出了期望的范围元素是不连续的，并且尾部超出了期望的范围<br>
            //
            //
            // At all other times, element positions are unaffected. <br>在其他所有时间，元素位置均不受影响。<br>
            //
            // Indicates that elements at the head should be moved. <br>指示应该移动顶部的元素。<br>
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Move elements from out of desired bounds (positions after target_cap) <br>将元素移出所需范围 (位于 target_cap 之后的位置)<br>
            if self.tail >= target_cap && head_outside {
                // T             H
                //   [. . . . . . . . o o o o o o o . ]
                //    T             H
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // T             H
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // H                 T
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Shortens the `VecDeque`, keeping the first `len` elements and dropping the rest. <br>缩短 `VecDeque`，保留第一个 `len` 元素，然后丢弃其余的元素。<br>
    ///
    ///
    /// If `len` is greater than the `VecDeque`'s current length, this has no effect. <br>如果 `len` 大于 `VecDeque' 的当前长度，则无效。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Runs the destructor for all items in the slice when it gets dropped (normally or during unwinding). <br>当切片被丢弃时 (正常情况下或在展开期间)，对切片中的所有项运行析构函数。<br>
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Safe because: <br>安全是因为：<br>
        //
        // * Any slice passed to `drop_in_place` is valid; <br>传递给 `drop_in_place` 的任何切片都是有效的；<br> the second case has `len <= front.len()` and returning on `len > self.len()` ensures `begin <= back.len()` in the first case <br>第二种情况为 `len <= front.len()`，返回 `len > self.len()` 可确保第一种情况为 `begin <= back.len()`<br>
        //
        // * The head of the VecDeque is moved before calling `drop_in_place`, so no value is dropped twice if `drop_in_place` panics <br>VecDeque 的头部在调用 `drop_in_place` 之前已移动，因此如果 `drop_in_place` panics 没有两次删除任何值<br>
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Make sure the second half is dropped even when a destructor in the first one panics. <br>即使第一个中的析构函数发生 panic，也要确保后半部分被丢弃。<br>
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Returns a reference to the underlying allocator. <br>返回底层分配器的引用。<br>
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Returns a front-to-back iterator. <br>返回从前到后的迭代器。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Returns a front-to-back iterator that returns mutable references. <br>返回从前到后的迭代器，该迭代器返回可变引用。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SAFETY: The internal `IterMut` safety invariant is established because the `ring` we create is a dereferenceable slice for lifetime '_. <br>建立内部 `IterMut` 安全不变量是因为我们创建的 `ring` 是生命周期 '_. 的可解引用切片。<br>
        //
        let ring = ptr::slice_from_raw_parts_mut(self.ptr(), self.cap());

        unsafe { IterMut::new(ring, self.tail, self.head, PhantomData) }
    }

    /// Returns a pair of slices which contain, in order, the contents of the `VecDeque`. <br>返回一对切片，这些切片按顺序包含 `VecDeque` 的内容。<br>
    ///
    /// If [`make_contiguous`] was previously called, all elements of the `VecDeque` will be in the first slice and the second slice will be empty. <br>如果先前调用了 [`make_contiguous`]，则 `VecDeque` 的所有元素都将位于第一个切片中，而第二个切片将为空。<br>
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Returns a pair of slices which contain, in order, the contents of the `VecDeque`. <br>返回一对切片，这些切片按顺序包含 `VecDeque` 的内容。<br>
    ///
    /// If [`make_contiguous`] was previously called, all elements of the `VecDeque` will be in the first slice and the second slice will be empty. <br>如果先前调用了 [`make_contiguous`]，则 `VecDeque` 的所有元素都将位于第一个切片中，而第二个切片将为空。<br>
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Returns the number of elements in the `VecDeque`. <br>返回 `VecDeque` 中的元素数。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Returns `true` if the `VecDeque` is empty. <br>如果 `VecDeque` 为空，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Creates an iterator that covers the specified range in the `VecDeque`. <br>创建一个覆盖 `VecDeque` 中指定范围的迭代器。<br>
    ///
    /// # Panics
    ///
    /// Panics if the starting point is greater than the end point or if the end point is greater than the length of the vector. <br>如果起点大于终点或终点大于 vector 的长度，就会出现 panics。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // A full range covers all contents <br>全方位涵盖所有内容<br>
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // The shared reference we have in &self is maintained in the '_ of Iter. <br>&self 中的共享引用保留在 Iter 的 '_中。<br>
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Creates an iterator that covers the specified mutable range in the `VecDeque`. <br>创建一个覆盖 `VecDeque` 中指定的可变范围的迭代器。<br>
    ///
    /// # Panics
    ///
    /// Panics if the starting point is greater than the end point or if the end point is greater than the length of the vector. <br>如果起点大于终点或终点大于 vector 的长度，就会出现 panics。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // A full range covers all contents <br>全方位涵盖所有内容<br>
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SAFETY: The internal `IterMut` safety invariant is established because the `ring` we create is a dereferenceable slice for lifetime '_. <br>建立内部 `IterMut` 安全不变量是因为我们创建的 `ring` 是生命周期 '_. 的可解引用切片。<br>
        //
        let ring = ptr::slice_from_raw_parts_mut(self.ptr(), self.cap());

        unsafe { IterMut::new(ring, tail, head, PhantomData) }
    }

    /// Creates a draining iterator that removes the specified range in the `VecDeque` and yields the removed items. <br>创建一个 draining 迭代器，该迭代器将删除 `VecDeque` 中的指定范围并产生已删除的项。<br>
    ///
    /// Note 1: The element range is removed even if the iterator is not consumed until the end. <br>注意 1: 即使直到最后才消耗迭代器，元素范围也会被删除。<br>
    ///
    /// Note 2: It is unspecified how many elements are removed from the deque, if the `Drain` value is not dropped, but the borrow it holds expires (e.g., due to `mem::forget`). <br>注意 2: 如果 `Drain` 值没有被丢弃，但持有的借用已过期 (例如，由于 `mem::forget`)，则未指定从双端队列中删除了多少个元素。<br>
    ///
    ///
    /// # Panics
    ///
    /// Panics if the starting point is greater than the end point or if the end point is greater than the length of the vector. <br>如果起点大于终点或终点大于 vector 的长度，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // A full range clears all contents <br>全系列清除所有内容<br>
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Memory safety <br>内存安全<br>
        //
        // When the Drain is first created, the source deque is shortened to make sure no uninitialized or moved-from elements are accessible at all if the Drain's destructor never gets to run. <br>首次创建 Drain 时，将缩短源双端队列，以确保在 Drain 的析构函数从不运行的情况下，根本无法访问未初始化或移出的元素。<br>
        //
        //
        // Drain will ptr::read out the values to remove. <br>Drain 将 ptr::read 取出要删除的值。<br>
        // When finished, the remaining data will be copied back to cover the hole, and the head/tail values will be restored correctly. <br>完成后，剩余的数据将被复制回以覆盖 hole，并且 head/tail 值将被正确恢复。<br>
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // The deque's elements are parted into three segments: <br>双端队列的元素分为三个部分：<br>
        // * self.tail  -> drain_tail
        // * drain_tail -> drain_head
        // * drain_head -> self.head
        //
        // T = self.tail;  H = self.head;  t = drain_tail;  h = drain_head
        //
        // We store drain_tail as self.head, and drain_head and self.head as after_tail and after_head respectively on the Drain. <br>我们将 drain_tail 存储为 self.head，并将 drain_head 和 self.head 分别存储为 Drain 上的 after_tail 和 after_head。<br>
        // This also truncates the effective array such that if the Drain is leaked, we have forgotten about the potentially moved values after the start of the drain. <br>这也将截断有效数组，以使如果 Drain 泄漏，我们将在 drain 开始后忘记可能移动的值。<br>
        //
        //
        //        T   t   h   H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" about the values after the start of the drain until after the drain is complete and the Drain destructor is run. <br>"forget" 关于 drain 开始之后的值，直到 drain 完成并且 Drain 析构函数运行之后。<br>
        //
        self.head = drain_tail;

        let deque = NonNull::from(&mut *self);
        let iter = Iter {
            tail: drain_tail,
            head: drain_head,
            // Crucially, we only create shared references from `self` here and read from it. <br>至关重要的是，我们仅在此处从 `self` 创建共享引用并从中读取。<br>
            // We do not write to `self` nor reborrow to a mutable reference. <br>我们既不写 `self`，也不重新借用可变引用。<br>
            // Hence the raw pointer we created above, for `deque`, remains valid. <br>因此，我们上面为 `deque` 创建的裸指针仍然有效。<br>
            ring: unsafe { self.buffer_as_slice() },
        };

        unsafe { Drain::new(drain_head, head, iter, deque) }
    }

    /// Clears the `VecDeque`, removing all values. <br>清除 `VecDeque`，删除所有值。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Returns `true` if the `VecDeque` contains an element equal to the given value. <br>如果 `VecDeque` 包含等于给定值的元素，则返回 `true`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Provides a reference to the front element, or `None` if the `VecDeque` is empty. <br>提供对前元素的引用，如果 `VecDeque` 为空，则为 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Provides a mutable reference to the front element, or `None` if the `VecDeque` is empty. <br>为前元素提供可变引用，如果 `VecDeque` 为空，则为 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Provides a reference to the back element, or `None` if the `VecDeque` is empty. <br>提供对 back 元素的引用，如果 `VecDeque` 为空，则提供 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Provides a mutable reference to the back element, or `None` if the `VecDeque` is empty. <br>提供对 back 元素的可变引用，如果 `VecDeque` 为空，则提供 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Removes the first element and returns it, or `None` if the `VecDeque` is empty. <br>删除第一个元素并返回它，如果 `VecDeque` 为空，则返回 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Removes the last element from the `VecDeque` and returns it, or `None` if it is empty. <br>从 `VecDeque` 中删除最后一个元素并返回它; 如果它为空，则返回 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Prepends an element to the `VecDeque`. <br>将元素添加到 `VecDeque`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Appends an element to the back of the `VecDeque`. <br>将一个元素追加到 `VecDeque` 的后面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Should we consider `head == 0` to mean that `self` is contiguous? <br>我们是否应该认为 `head == 0` 表示 `self` 是连续的？<br>
        //
        self.tail <= self.head
    }

    /// Removes an element from anywhere in the `VecDeque` and returns it, replacing it with the first element. <br>从 `VecDeque` 的任何位置删除一个元素并返回，并用第一个元素替换它。<br>
    ///
    ///
    /// This does not preserve ordering, but is *O*(1). <br>这不会保留顺序，而是 *O*(1)。<br>
    ///
    /// Returns `None` if `index` is out of bounds. <br>如果 `index` 越界，则返回 `None`。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Removes an element from anywhere in the `VecDeque` and returns it, replacing it with the last element. <br>从 `VecDeque` 中的任何位置删除元素，然后将其返回，并用最后一个元素替换。<br>
    ///
    ///
    /// This does not preserve ordering, but is *O*(1). <br>这不会保留顺序，而是 *O*(1)。<br>
    ///
    /// Returns `None` if `index` is out of bounds. <br>如果 `index` 越界，则返回 `None`。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Inserts an element at `index` within the `VecDeque`, shifting all elements with indices greater than or equal to `index` towards the back. <br>在 `VecDeque` 内的 `index` 处插入一个元素，将所有索引大于或等于 `index` 的元素向后移动。<br>
    ///
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Panics
    ///
    /// Panics if `index` is greater than `VecDeque`'s length <br>如果 `index` 大于 `VecDeque` 的长度，就会出现 panics<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Move the least number of elements in the ring buffer and insert the given object <br>在环形缓冲区中移动最少数量的元素并插入给定的对象<br>
        //
        // At most len/2 - 1 elements will be moved. <br>最多移动 `len/2 - 1`个元素。<br> O(min(n, n-i))
        //
        // There are three main cases: <br>主要有以下三种情况：<br>
        //  Elements are contiguous <br>元素是连续的<br>
        //      - special case when tail is 0 Elements are discontiguous and the insert is in the tail section Elements are discontiguous and the insert is in the head section <br>tail 为 0 时的特殊情况元素不连续且插入在尾部元素不连续且插入在头部<br>
        //
        //
        // For each of those there are two more cases: <br>对于每种情况，还有两种情况：<br>
        //  Insert is closer to tail Insert is closer to head <br>插入物更靠近尾部插入物更靠近头<br>
        //
        // Key: H - self.head T - self.tail o - Valid element I - Insertion element A - The element that should be after the insertion point M - Indicates element was moved <br>Key: H - self.head T - self.tail o - 有效元素 I - 插入元素 A - 插入点之后的元素 M - 指示元素已移动<br>
        //
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       T I             H
                //      [A o o o o o o . . . . . . .
                //      .
                //      .]
                //
                //                       H         T
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // contiguous, insert closer to tail: <br>连续的，插入到更靠近尾部的位置：<br>
                    //
                    //             T   I         H
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           T               H
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // contiguous, insert closer to tail and tail is 0: <br>连续，插入时靠近尾部 ，并且尾部为 0：<br>
                    //
                    //
                    //       T   I         H
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       H             T
                    //      [o I A o o o o o . . . . . . . o]
                    //       M                             M

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Already moved the tail, so we only copy `index - 1` elements. <br>已经移动了尾部，因此我们仅复制 `index - 1` 元素。<br>
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // contiguous, insert closer to head: <br>连续的，靠近头部插入：<br>
                    //
                    //             T       I     H
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             T               H
                    //      [. . . o o o o I A o o . . . . .]
                    //                       M M M

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, insert closer to tail, tail section: <br>不连续的，靠近尾部插入，尾部部分：<br>
                    //
                    //                   H         T   I
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   H       T
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, insert closer to head, tail section: <br>不连续的，插入得更靠近头部，尾部部分：<br>
                    //
                    //           H             T         I
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             H           T
                    //      [o o o . . . . . . o o o o o I A]
                    //       M M M                         M

                    // copy elements up to new head <br>复制元素直到新的头部<br>
                    self.copy(1, 0, self.head);

                    // copy last element into empty spot at bottom of buffer <br>将最后一个元素复制到缓冲区底部的空白处<br>
                    self.copy(0, self.cap() - 1, 1);

                    // move elements from idx to end forward not including ^ element <br>将元素从 idx 移动到结束，不包括 ^ 元素<br>
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, insert is closer to tail, head section, and is at index zero in the internal buffer: <br>不连续，insert 更靠近尾部，头部，并且在内部缓冲区中的索引为零：<br>
                    //
                    //
                    //       I                   H     T
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           H   T
                    //      [A o o o o o o o o o . . o o o I]
                    //                               M M M

                    // copy elements up to new tail <br>复制元素直到新尾<br>
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // copy last element into empty spot at bottom of buffer <br>将最后一个元素复制到缓冲区底部的空白处<br>
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, insert closer to tail, head section: <br>不连续的，靠近尾部插入，头部部分：<br>
                    //
                    //             I             H     T
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           H   T
                    //      [o o I A o o o o o o . . o o o o]
                    //       M M                     M M M M

                    // copy elements up to new tail <br>复制元素直到新尾<br>
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // copy last element into empty spot at bottom of buffer <br>将最后一个元素复制到缓冲区底部的空白处<br>
                    self.copy(self.cap() - 1, 0, 1);

                    // move elements from idx-1 to end forward not including ^ element <br>将元素从 idx-1 移至末尾，不包括 ^ 元素<br>
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, insert closer to head, head section: <br>不连续的，靠近头部插入，头部部分：<br>
                    //
                    //               I     H           T
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     H           T
                    //      [o o o o I A o o . . . . . o o o]
                    //                 M M M

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // tail might've been changed so we need to recalculate <br>尾部可能已更改，因此我们需要重新计算<br>
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Removes and returns the element at `index` from the `VecDeque`. <br>从 `VecDeque` 删除 `index` 处的元素，并返回该元素。<br>
    /// Whichever end is closer to the removal point will be moved to make room, and all the affected elements will be moved to new positions. <br>靠近移除点的任意一端将被移动以腾出空间，所有受影响的元素将被移动到新位置。<br>
    ///
    /// Returns `None` if `index` is out of bounds. <br>如果 `index` 越界，则返回 `None`。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // There are three main cases: <br>主要有以下三种情况：<br>
        //  Elements are contiguous Elements are discontiguous and the removal is in the tail section Elements are discontiguous and the removal is in the head section <br>元素是连续的元素是不连续的，并且去除在尾部元素是不连续的，并且去除在头部<br>
        //      - special case when elements are technically contiguous, but self.head = 0 <br>特殊情况下，元素在技术上是连续的，但是 self.head = 0<br>
        //
        // For each of those there are two more cases: <br>对于每种情况，还有两种情况：<br>
        //  Insert is closer to tail Insert is closer to head <br>插入物更靠近尾部插入物更靠近头<br>
        //
        // Key: H - self.head T - self.tail o - Valid element x - Element marked for removal R - Indicates element that is being removed M - Indicates element was moved <br>Key: H-self.head T-self.tail o - 有效元素 x - 标记为要删除的元素 R - 表示要删除的元素 M - 表示元素已移动<br>
        //
        //
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // contiguous, remove closer to tail: <br>连续，移近尾部删除：<br>
                    //
                    //             T   R         H
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               T           H
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // contiguous, remove closer to head: <br>连续，靠近头部删除：<br>
                    //
                    //             T       R     H
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             T           H
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, remove closer to tail, tail section: <br>不连续的，靠近尾部删除，尾部部分：<br>
                    //
                    //                   H         T   R
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   H           T
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, remove closer to head, head section: <br>不连续的，靠近头部删除，头部：<br>
                    //
                    //               R     H           T
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   H             T
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, remove closer to head, tail section: <br>不连续的，删除靠近头部，尾部的部分：<br>
                    //
                    //             H           T         R
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           H             T
                    //      [o o . . . . . . . o o o o o o o]
                    //       M M                         M M
                    //
                    // or quasi-discontiguous, remove next to head, tail section: <br>或类似不连续，删除靠近头部和尾部的部分：<br>
                    //
                    //       H                 T         R
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         T           H
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // draw in elements in the tail section <br>在尾部绘制元素<br>
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Prevents underflow. <br>防止下溢。<br>
                    if self.head != 0 {
                        // copy first element into empty spot <br>将第一个元素复制到空位置<br>
                        self.copy(self.cap() - 1, 0, 1);

                        // move elements in the head section backwards <br>向后移动头部的元素<br>
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, remove closer to tail, head section: <br>不连续的，靠近尾部、头部部分删除：<br>
                    //
                    //           R               H     T
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           H       T
                    //      [o o o o o o o o o o . . . . o o]
                    //       M M M                       M M

                    // draw in elements up to idx <br>绘制多达 idx 的元素<br>
                    self.copy(1, 0, idx);

                    // copy last element into empty spot <br>将最后一个元素复制到空白处<br>
                    self.copy(0, self.cap() - 1, 1);

                    // move elements from tail to end forward, excluding the last one <br>将元素从尾部向前移动到末尾，不包括最后一个<br>
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Splits the `VecDeque` into two at the given index. <br>在给定的索引处将 `VecDeque` 拆分为两个。<br>
    ///
    /// Returns a newly allocated `VecDeque`. <br>返回新分配的 `VecDeque`。<br>
    /// `self` contains elements `[0, at)`, and the returned `VecDeque` contains elements `[at, len)`. <br>`self` 包含元素 `[0, at)`，返回的 `VecDeque` 包含元素 `[at, len)`。<br>
    ///
    /// Note that the capacity of `self` does not change. <br>请注意，`self` 的容量不会改变。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Panics
    ///
    /// Panics if `at > len`. <br>如果为 `at > len`，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity_in(other_len, self.allocator().clone());

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` lies in the first half. <br>`at` 位于前半部分。<br>
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // just take all of the second half. <br>下半部分全部拿下。<br>
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` lies in the second half, need to factor in the elements we skipped in the first half. <br>`at` 位于后半部分，需要考虑我们在前半部分跳过的元素。<br>
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Cleanup where the ends of the buffers are <br>清理缓冲区末端的位置<br>
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Moves all the elements of `other` into `self`, leaving `other` empty. <br>将 `other` 的所有元素移到 `self`，将 `other` 留空。<br>
    ///
    /// # Panics
    ///
    /// Panics if the new number of elements in self overflows a `usize`. <br>如果 self 中的新元素数溢出了一个 `usize`，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        self.reserve(other.len());
        unsafe {
            let (left, right) = other.as_slices();
            self.copy_slice(self.head, left);
            self.copy_slice(self.wrap_add(self.head, left.len()), right);
        }
        // SAFETY: Update pointers after copying to avoid leaving doppelganger in case of panics. <br>复制后更新指针，以避免在 panics 的情况下留下分身。<br>
        //
        self.head = self.wrap_add(self.head, other.len());
        // Silently drop values in `other`. <br>默默地丢弃 `other` 中的值。<br>
        other.tail = other.head;
    }

    /// Retains only the elements specified by the predicate. <br>仅保留谓词指定的元素。<br>
    ///
    /// In other words, remove all elements `e` such that `f(&e)` returns false. <br>换句话说，删除所有元素 `e`，以使 `f(&e)` 返回 false。<br>
    /// This method operates in place, visiting each element exactly once in the original order, and preserves the order of the retained elements. <br>此方法在原位运行，以原始顺序恰好一次访问每个元素，并保留保留元素的顺序。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Because the elements are visited exactly once in the original order, external state may be used to decide which elements to keep. <br>由于按原始顺序仅对元素进行过一次访问，因此可以使用外部状态来确定要保留哪些元素。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// buf.retain(|_| *iter.next().unwrap());
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.retain_mut(|elem| f(elem));
    }

    /// Retains only the elements specified by the predicate. <br>仅保留谓词指定的元素。<br>
    ///
    /// In other words, remove all elements `e` such that `f(&e)` returns false. <br>换句话说，删除所有元素 `e`，以使 `f(&e)` 返回 false。<br>
    /// This method operates in place, visiting each element exactly once in the original order, and preserves the order of the retained elements. <br>此方法在原位运行，以原始顺序恰好一次访问每个元素，并保留保留元素的顺序。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_retain_mut)]
    ///
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain_mut(|x| if *x % 2 == 0 {
    ///     *x += 1;
    ///     true
    /// } else {
    ///     false
    /// });
    /// assert_eq!(buf, [3, 5]);
    /// ```
    #[unstable(feature = "vec_retain_mut", issue = "90829")]
    pub fn retain_mut<F>(&mut self, mut f: F)
    where
        F: FnMut(&mut T) -> bool,
    {
        let len = self.len();
        let mut idx = 0;
        let mut cur = 0;

        // Stage 1: All values are retained. <br>第 1 阶段：保留所有值。<br>
        while cur < len {
            if !f(&mut self[cur]) {
                cur += 1;
                break;
            }
            cur += 1;
            idx += 1;
        }
        // Stage 2: Swap retained value into current idx. <br>第 2 阶段：将保留值交换为当前 idx。<br>
        while cur < len {
            if !f(&mut self[cur]) {
                cur += 1;
                continue;
            }

            self.swap(idx, cur);
            cur += 1;
            idx += 1;
        }
        // Stage 3: Truncate all values after idx. <br>阶段 3: 截断 idx 之后的所有值。<br>
        if cur != idx {
            self.truncate(idx);
        }
    }

    // Double the buffer size. <br>将缓冲区大小增加一倍。<br>
    // This method is inline(never), so we expect it to only be called in cold paths. <br>这个方法是 inline(never)，所以我们希望它只在 cold 路径中被调用。<br>
    // This may panic or abort <br>这可能会导致 panic 或终止<br>
    #[inline(never)]
    fn grow(&mut self) {
        // Extend or possibly remove this assertion when valid use-cases for growing the buffer without it being full emerge <br>当有效的用例出现时，扩展或者可能删除这个断言，从而在缓冲区没有满的情况下增长它<br>
        //
        debug_assert!(self.is_full());
        let old_cap = self.cap();
        self.buf.reserve_exact(old_cap, old_cap);
        assert!(self.cap() == old_cap * 2);
        unsafe {
            self.handle_capacity_increase(old_cap);
        }
        debug_assert!(!self.is_full());
    }

    /// Modifies the `VecDeque` in-place so that `len()` is equal to `new_len`, either by removing excess elements from the back or by appending elements generated by calling `generator` to the back. <br>在原位修改 `VecDeque`，以使 `len()` 等于 `new_len`，可以从后面删除多余的元素，也可以在后面追加通过调用 `generator` 生成的元素。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Rearranges the internal storage of this deque so it is one contiguous slice, which is then returned. <br>重新排列此双端队列的内部存储，使其成为一个连续的切片，然后将其返回。<br>
    ///
    /// This method does not allocate and does not change the order of the inserted elements. <br>此方法不分配也不更改插入元素的顺序。<br> As it returns a mutable slice, this can be used to sort a deque. <br>当它返回可变切片时，可用于对双端队列进行排序。<br>
    ///
    /// Once the internal storage is contiguous, the [`as_slices`] and [`as_mut_slices`] methods will return the entire contents of the `VecDeque` in a single slice. <br>内部存储器连续后，[`as_slices`] 和 [`as_mut_slices`] 方法将在单个切片中返回 `VecDeque` 的全部内容。<br>
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Sorting the content of a deque. <br>对双端队列的内容进行排序。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // sorting the deque <br>排序双端队列<br>
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // sorting it in reverse order <br>反向排序<br>
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Getting immutable access to the contiguous slice. <br>不可变地访问连续的切片。<br>
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // we can now be sure that `slice` contains all elements of the deque, while still having immutable access to `buf`. <br>现在，我们可以确定 `slice` 包含了双端队列的所有元素，同时仍具有对 `buf` 的不可变访问权限。<br>
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // there is enough free space to copy the tail in one go, this means that we first shift the head backwards, and then copy the tail to the correct position. <br>有足够的可用空间来一次性复制尾部，这意味着我们先将头向后移动，然后再将尾部复制到正确的位置。<br>
            //
            //
            // from: DEFGH....ABC to:   ABCDEFGH.... <br>从: DEFGH....ABC 到: ABCDEFGH....<br>
            //
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: We currently do not consider ....ABCDEFGH to be contiguous because `head` would be `0` in this case. <br>我们目前不认为 ....ABCDEFGH 是连续的，因为在这种情况下 `head` 将为 `0`。<br>
            // While we probably want to change this it isn't trivial as a few places expect `is_contiguous` to mean that we can just slice using `buf[tail..head]`. <br>尽管我们可能想更改它，但这并不是一件容易的事，因为有些地方期望 `is_contiguous` 表示我们可以使用 `buf[tail..head]` 进行切片。<br>
            //
            //
            //

            // there is enough free space to copy the head in one go, this means that we first shift the tail forwards, and then copy the head to the correct position. <br>有足够的自由空间可以一次性复制头部，这意味着我们先将尾部向前移动，然后再将头部复制到正确的位置。<br>
            //
            //
            // from: FGH....ABCDE to:   ...ABCDEFGH. <br>从: FGH....ABCDE 到: ...ABCDEFGH。<br>
            //
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // free is smaller than both head and tail, this means we have to slowly "swap" the tail and the head. <br>free 小于头和尾，这意味着我们必须缓慢地 "swap" 尾和头。<br>
            //
            //
            // from: EFGHI...ABCD or HIJK.ABCDEFG to:   ABCDEFGHI... <br>从: EFGHI...ABCD  或 HIJK.ABCDEFG 到: ABCDEFGHI...<br> or ABCDEFGHIJK.
            //
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // The general problem looks like this GHIJKLM...ABCDEF - before any swaps ABCDEFM...GHIJKL - after 1 pass of swaps ABCDEFGHIJM...KL - swap until the left edge reaches the temp store <br>一般问题如下所示: GHIJKLM ... ABCDEF - 进行任何交换之前 ABCDEFM ... GHIJKL - 进行 1 次交换之后 ABCDEFGHIJM ... KL - 交换直到左 edge 到达临时存储<br>
                //                  - then restart the algorithm with a new (smaller) store Sometimes the temp store is reached when the right edge is at the end of the buffer - this means we've hit the right order with fewer swaps! <br>然后使用新的 (smaller) 存储区重新启动算法。有时，当右边缘位于缓冲区的末尾时，便达到了临时存储区 - 这意味着我们以更少的交换找到了正确的顺序！<br>
                //
                // E.g
                // EF..ABCD ABCDEF.. - after four only swaps we've finished <br>- 仅四次交换后，我们就完成了<br>
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Rotates the double-ended queue `mid` places to the left. <br>将双端队列 `mid` 放置到左侧。<br>
    ///
    /// Equivalently,
    /// - Rotates item `mid` into the first position. <br>将项 `mid` 旋转到第一个位置。<br>
    /// - Pops the first `mid` items and pushes them to the end. <br>弹出第一个 `mid` 项并将其推到末尾。<br>
    /// - Rotates `len() - mid` places to the right. <br>向右旋转 `len() - mid` 位置。<br>
    ///
    /// # Panics
    ///
    /// If `mid` is greater than `len()`. <br>如果 `mid` 大于 `len()`。<br>
    /// Note that `mid == len()` does _not_ panic and is a no-op rotation. <br>请注意，`mid == len()` 执行 _not_ panic，并且是无操作旋转。<br>
    ///
    /// # Complexity
    ///
    /// Takes `*O*(min(mid, len() - mid))` time and no extra space. <br>花费 `*O*(min(mid, len() - mid))` 的时间，没有多余的空间。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Rotates the double-ended queue `k` places to the right. <br>向右旋转 `k` 位置的双端队列。<br>
    ///
    /// Equivalently,
    /// - Rotates the first item into position `k`. <br>将第一个项旋转到位置 `k`。<br>
    /// - Pops the last `k` items and pushes them to the front. <br>弹出最后一个 `k` 项并将其推到前面。<br>
    /// - Rotates `len() - k` places to the left. <br>将 `len() - k` 位置向左旋转。<br>
    ///
    /// # Panics
    ///
    /// If `k` is greater than `len()`. <br>如果 `k` 大于 `len()`。<br>
    /// Note that `k == len()` does _not_ panic and is a no-op rotation. <br>请注意，`k == len()` 执行 _not_ panic，并且是无操作旋转。<br>
    ///
    /// # Complexity
    ///
    /// Takes `*O*(min(k, len() - k))` time and no extra space. <br>花费 `*O*(min(k, len() - k))` 的时间，没有多余的空间。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SAFETY: the following two methods require that the rotation amount be less than half the length of the deque. <br>以下两种方法要求旋转量小于双端队列的长度的一半。<br>
    //
    // `wrap_copy` requires that `min(x, cap() - x) + copy_len <= cap()`, but than `min` is never more than half the capacity, regardless of x, so it's sound to call here because we're calling with something less than half the length, which is never above half the capacity. <br>`wrap_copy` 需要 `min(x, cap() - x) + copy_len <= cap()`，但 `min` 永远不会超过容量的一半，无论 x 是多少，所以在这里调用是合理的，因为我们调用的长度小于一半，永远不会超过容量的一半。<br>
    //
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binary searches this sorted `VecDeque` for a given element. <br>Binary 在此排序的 `VecDeque` 上搜索给定的元素。<br>
    ///
    /// If the value is found then [`Result::Ok`] is returned, containing the index of the matching element. <br>如果找到该值，则返回 [`Result::Ok`]，其中包含匹配元素的索引。<br>
    /// If there are multiple matches, then any one of the matches could be returned. <br>如果有多个匹配项，则可以返回任何一个匹配项。<br>
    /// If the value is not found then [`Result::Err`] is returned, containing the index where a matching element could be inserted while maintaining sorted order. <br>如果找不到该值，则返回 [`Result::Err`]，其中包含在保留排序顺序的同时可以在其中插入匹配元素的索引。<br>
    ///
    ///
    /// See also [`binary_search_by`], [`binary_search_by_key`], and [`partition_point`]. <br>另请参见 [`binary_search_by`]，[`binary_search_by_key`] 和 [`partition_point`]。<br>
    ///
    /// [`binary_search_by`]: VecDeque::binary_search_by
    /// [`binary_search_by_key`]: VecDeque::binary_search_by_key
    /// [`partition_point`]: VecDeque::partition_point
    ///
    /// # Examples
    ///
    /// Looks up a series of four elements. <br>查找一系列四个元素。<br>
    /// The first is found, with a uniquely determined position; <br>找到第一个，具有唯一确定的位置；<br> the second and third are not found; <br>没有找到第二个和第三个；<br> the fourth could match any position in `[1, 4]`. <br>第四个可以匹配 `[1, 4]` 中的任何位置。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// If you want to insert an item to a sorted `VecDeque`, while maintaining sort order: <br>如果要在已排序的 `VecDeque` 上插入项目，同时保持排序顺序：<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vecdeque_binary_search", since = "1.54.0")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary searches this sorted `VecDeque` with a comparator function. <br>Binary 使用比较器函数搜索此排序的 `VecDeque`。<br>
    ///
    /// The comparator function should implement an order consistent with the sort order of the underlying `VecDeque`, returning an order code that indicates whether its argument is `Less`, `Equal` or `Greater` than the desired target. <br>比较器函数应该实现一个与底层 `VecDeque` 的排序顺序一致的顺序，返回一个顺序代码，指示其参数是比所需目标是 `Less`、`Equal` 还是 `Greater`。<br>
    ///
    ///
    /// If the value is found then [`Result::Ok`] is returned, containing the index of the matching element. <br>如果找到该值，则返回 [`Result::Ok`]，其中包含匹配元素的索引。<br> If there are multiple matches, then any one of the matches could be returned. <br>如果有多个匹配项，则可以返回任何一个匹配项。<br>
    /// If the value is not found then [`Result::Err`] is returned, containing the index where a matching element could be inserted while maintaining sorted order. <br>如果找不到该值，则返回 [`Result::Err`]，其中包含在保留排序顺序的同时可以在其中插入匹配元素的索引。<br>
    ///
    /// See also [`binary_search`], [`binary_search_by_key`], and [`partition_point`]. <br>另请参见 [`binary_search`]，[`binary_search_by_key`] 和 [`partition_point`]。<br>
    ///
    /// [`binary_search`]: VecDeque::binary_search
    /// [`binary_search_by_key`]: VecDeque::binary_search_by_key
    /// [`partition_point`]: VecDeque::partition_point
    ///
    /// # Examples
    ///
    /// Looks up a series of four elements. <br>查找一系列四个元素。<br> The first is found, with a uniquely determined position; <br>找到第一个，具有唯一确定的位置；<br> the second and third are not found; <br>没有找到第二个和第三个；<br> the fourth could match any position in `[1, 4]`. <br>第四个可以匹配 `[1, 4]` 中的任何位置。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "vecdeque_binary_search", since = "1.54.0")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();
        let cmp_back = back.first().map(|elem| f(elem));

        if let Some(Ordering::Equal) = cmp_back {
            Ok(front.len())
        } else if let Some(Ordering::Less) = cmp_back {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary searches this sorted `VecDeque` with a key extraction function. <br>Binary 使用关键字提取函数搜索此排序的 `VecDeque`。<br>
    ///
    /// Assumes that the `VecDeque` is sorted by the key, for instance with [`make_contiguous().sort_by_key()`] using the same key extraction function. <br>假设 `VecDeque` 是按键排序的，例如 [`make_contiguous().sort_by_key()`] 使用相同的键提取函数。<br>
    ///
    /// If the value is found then [`Result::Ok`] is returned, containing the index of the matching element. <br>如果找到该值，则返回 [`Result::Ok`]，其中包含匹配元素的索引。<br>
    /// If there are multiple matches, then any one of the matches could be returned. <br>如果有多个匹配项，则可以返回任何一个匹配项。<br>
    /// If the value is not found then [`Result::Err`] is returned, containing the index where a matching element could be inserted while maintaining sorted order. <br>如果找不到该值，则返回 [`Result::Err`]，其中包含在保留排序顺序的同时可以在其中插入匹配元素的索引。<br>
    ///
    ///
    /// See also [`binary_search`], [`binary_search_by`], and [`partition_point`]. <br>另请参见 [`binary_search`]，[`binary_search_by`] 和 [`partition_point`]。<br>
    ///
    /// [`make_contiguous().sort_by_key()`]: VecDeque::make_contiguous
    /// [`binary_search`]: VecDeque::binary_search
    /// [`binary_search_by`]: VecDeque::binary_search_by
    /// [`partition_point`]: VecDeque::partition_point
    ///
    /// # Examples
    ///
    /// Looks up a series of four elements in a slice of pairs sorted by their second elements. <br>在成对的切片中按其第二个元素排序的一系列四个元素中查找。<br>
    /// The first is found, with a uniquely determined position; <br>找到第一个，具有唯一确定的位置；<br> the second and third are not found; <br>没有找到第二个和第三个；<br> the fourth could match any position in `[1, 4]`. <br>第四个可以匹配 `[1, 4]` 中的任何位置。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "vecdeque_binary_search", since = "1.54.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Returns the index of the partition point according to the given predicate (the index of the first element of the second partition). <br>根据给定的谓词返回分区点的索引 (第二个分区的第一个元素的索引)。<br>
    ///
    /// The deque is assumed to be partitioned according to the given predicate. <br>假定双端队列根据给定的谓词进行了分区。<br>
    /// This means that all elements for which the predicate returns true are at the start of the deque and all elements for which the predicate returns false are at the end. <br>这意味着谓词返回 true 的所有元素都在双端队列的开头，而谓词返回 false 的所有元素都在末尾。<br>
    ///
    /// For example, [7, 15, 3, 5, 4, 12, 6] is a partitioned under the predicate x % 2 != 0 (all odd numbers are at the start, all even at the end). <br>例如，[7, 15, 3, 5, 4, 12, 6] 在谓词 `x % 2 != 0` 下进行了分区 (所有的奇数都在开头，所有的偶数都在结尾)。<br>
    ///
    /// If this deque is not partitioned, the returned result is unspecified and meaningless, as this method performs a kind of binary search. <br>如果此双端队列未分区，则返回的结果是未指定且无意义的，因为此方法执行一种二分查找。<br>
    ///
    /// See also [`binary_search`], [`binary_search_by`], and [`binary_search_by_key`]. <br>另请参见 [`binary_search`]，[`binary_search_by`] 和 [`binary_search_by_key`]。<br>
    ///
    /// [`binary_search`]: VecDeque::binary_search
    /// [`binary_search_by`]: VecDeque::binary_search_by
    /// [`binary_search_by_key`]: VecDeque::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![1, 2, 3, 3, 5, 6, 7].into();
    /// let i = deque.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(deque.iter().take(i).all(|&x| x < 5));
    /// assert!(deque.iter().skip(i).all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vecdeque_binary_search", since = "1.54.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let (front, back) = self.as_slices();

        if let Some(true) = back.first().map(|v| pred(v)) {
            back.partition_point(pred) + front.len()
        } else {
            front.partition_point(pred)
        }
    }
}

impl<T: Clone, A: Allocator> VecDeque<T, A> {
    /// Modifies the `VecDeque` in-place so that `len()` is equal to new_len, either by removing excess elements from the back or by appending clones of `value` to the back. <br>就地修改 `VecDeque`，使 `len()` 等于 new_len，要么从后面删除多余的元素，要么在后面追加 `value` 的克隆。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Returns the index in the underlying buffer for a given logical element index. <br>返回给定逻辑元素索引的底层缓冲区中的索引。<br>
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // size is always a power of 2 <br>大小始终是 2 的幂<br>
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Calculate the number of elements left to be read in the buffer <br>计算要在缓冲区中读取的剩余元素数<br>
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // size is always a power of 2 <br>大小始终是 2 的幂<br>
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq, A: Allocator> PartialEq for VecDeque<T, A> {
    fn eq(&self, other: &Self) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Always divisible in three sections, for example: <br>始终可分为三部分，例如：<br>
            // self:  [a b c|d e f] other: [0 1 2 3|4 5] front = 3, mid = 1, [a b c] == [0 1 2] && [d] == [3] && [e f] == [4 5]
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for VecDeque<T, A> {}

__impl_slice_eq1! { [] VecDeque<T, A>, Vec<U, A>, }
__impl_slice_eq1! { [] VecDeque<T, A>, &[U], }
__impl_slice_eq1! { [] VecDeque<T, A>, &mut [U], }
__impl_slice_eq1! { [const N: usize] VecDeque<T, A>, [U; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<T, A>, &[U; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<T, A>, &mut [U; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for VecDeque<T, A> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for VecDeque<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for VecDeque<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // It's not possible to use Hash::hash_slice on slices returned by as_slices method as their length can vary in otherwise identical deques. <br>在 as_slices 方法返回的切片上无法使用 Hash::hash_slice，因为它们的长度会因其他双端队列相同而有所不同。<br>
        //
        //
        // Hasher only guarantees equivalence for the exact same set of calls to its methods. <br>Hasher 仅保证对其方法的完全相同的调用集是等效的。<br>
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Index<usize> for VecDeque<T, A> {
    type Output = T;

    #[inline]
    fn index(&self, index: usize) -> &T {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IndexMut<usize> for VecDeque<T, A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut T {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for VecDeque<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> VecDeque<T> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for VecDeque<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Consumes the `VecDeque` into a front-to-back iterator yielding elements by value. <br>将 `VecDeque` 消费为从前到后的迭代器，按值产生元素。<br>
    ///
    fn into_iter(self) -> IntoIter<T, A> {
        IntoIter::new(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a VecDeque<T, A> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut VecDeque<T, A> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for VecDeque<T, A> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        // This function should be the moral equivalent of: <br>这个功能应该是 moral 上的等价物：<br>
        //
        //      for item in iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy, A: Allocator> Extend<&'a T> for VecDeque<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for VecDeque<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T, A: Allocator> From<Vec<T, A>> for VecDeque<T, A> {
    /// Turn a [`Vec<T>`] into a [`VecDeque<T>`]. <br>将 [`Vec<T>`] 变成 [`VecDeque<T>`]。<br>
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// This avoids reallocating where possible, but the conditions for that are strict, and subject to change, and so shouldn't be relied upon unless the `Vec<T>` came from `From<VecDeque<T>>` and hasn't been reallocated. <br>这样可以避免在可能的情况下进行重新分配，但是这样做的条件很严格，并且随时可能更改，因此除非 `Vec<T>` 来自 `From<VecDeque<T>>` 并且尚未重新分配，否则不应依赖它。<br>
    ///
    ///
    fn from(mut other: Vec<T, A>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // There's no actual allocation for ZSTs to worry about capacity, but `VecDeque` can't handle as much length as `Vec`. <br>没有实际分配给 ZST 来担心容量的问题，但是 `VecDeque` 不能处理比 `Vec` 更长的长度。<br>
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // We need to resize if the capacity is not a power of two, too small or doesn't have at least one free space. <br>如果容量不是 2 的幂，太小或没有至少一个可用空间，则需要调整大小。<br>
            // We do this while it's still in the `Vec` so the items will drop on panic. <br>我们在它仍在 `Vec` 中时执行此操作，所以该项会因为 panic 而被丢弃。<br>
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity, alloc) = other.into_raw_parts_with_alloc();
            let buf = RawVec::from_raw_parts_in(other_buf, capacity, alloc);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T, A: Allocator> From<VecDeque<T, A>> for Vec<T, A> {
    /// Turn a [`VecDeque<T>`] into a [`Vec<T>`]. <br>将 [`VecDeque<T>`] 变成 [`Vec<T>`]。<br>
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// This never needs to re-allocate, but does need to do *O*(*n*) data movement if the circular buffer doesn't happen to be at the beginning of the allocation. <br>这永远不需要重新分配，但是如果循环缓冲区恰好不在分配开始时，则确实需要进行 *O*(*n*) 数据移动。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // This one is *O*(1). <br>这是 *O*(1)。<br>
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // This one needs data rearranging. <br>这一项需要重新整理数据。<br>
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T, A>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();
            let alloc = ptr::read(other.allocator());

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts_in(buf, len, cap, alloc)
        }
    }
}

#[stable(feature = "std_collections_from_array", since = "1.56.0")]
impl<T, const N: usize> From<[T; N]> for VecDeque<T> {
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deq1 = VecDeque::from([1, 2, 3, 4]);
    /// let deq2: VecDeque<_> = [1, 2, 3, 4].into();
    /// assert_eq!(deq1, deq2);
    /// ```
    fn from(arr: [T; N]) -> Self {
        let mut deq = VecDeque::with_capacity(N);
        let arr = ManuallyDrop::new(arr);
        if mem::size_of::<T>() != 0 {
            // SAFETY: VecDeque::with_capacity ensures that there is enough capacity. <br>VecDeque::with_capacity 确保有足够的容量。<br>
            unsafe {
                ptr::copy_nonoverlapping(arr.as_ptr(), deq.ptr(), N);
            }
        }
        deq.tail = 0;
        deq.head = N;
        deq
    }
}
