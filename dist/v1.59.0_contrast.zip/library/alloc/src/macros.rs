/// Creates a [`Vec`] containing the arguments. <br>创建一个包含参数的 [`Vec`]。<br>
///
/// `vec!` allows `Vec`s to be defined with the same syntax as array expressions. <br>`vec!` 允许使用与数组表达式相同的语法定义 Vec。<br>
/// There are two forms of this macro: <br>该宏有两种形式：<br>
///
/// - Create a [`Vec`] containing a given list of elements: <br>创建一个包含给定元素列表的 [`Vec`]：<br>
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Create a [`Vec`] from a given element and size: <br>根据给定的元素和大小创建 [`Vec`]：<br>
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Note that unlike array expressions this syntax supports all elements which implement [`Clone`] and the number of elements doesn't have to be a constant. <br>请注意，与数组表达式不同，此语法支持所有实现 [`Clone`] 的元素，并且元素的数量不必是常量。<br>
///
/// This will use `clone` to duplicate an expression, so one should be careful using this with types having a nonstandard `Clone` implementation. <br>这将使用 `clone` 复制表达式，因此在具有非标准 `Clone` 实现的类型上使用此表达式时应格外小心。<br>
/// For example, `vec![Rc::new(1); 5]` will create a vector of five references to the same boxed integer value, not five references pointing to independently boxed integers. <br>例如，`vec![Rc::new(1); 5]` 将对相同的 boxed 整数值创建五个引用的 vector，而不是对 boxed 整数独立引用的五个引用。<br>
///
///
/// Also, note that `vec![expr; 0]` is allowed, and produces an empty vector. <br>另外，请注意，允许使用 `vec![expr; 0]`，并产生一个空的 vector。<br>
/// This will still evaluate `expr`, however, and immediately drop the resulting value, so be mindful of side effects. <br>然而，这仍然会计算 `expr`，并立即丢弃结果值，因此请注意副作用。<br>
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): with cfg(test) the inherent `[T]::into_vec` method, which is required for this macro definition, is not available. <br>对于 cfg(test)，此宏定义所需的固有 `[T]::into_vec` 方法不可用。<br>
// Instead use the `slice::into_vec`  function which is only available with cfg(test) <br>而是使用仅适用于 cfg (test) 的 `slice::into_vec` 函数。<br>
// NB see the slice::hack module in slice.rs for more information <br>有关更多信息，请参见 slice.rs 中的 slice::hack 模块<br>
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Creates a `String` using interpolation of runtime expressions. <br>使用运行时表达式的插值创建 `String`。<br>
///
/// The first argument `format!` receives is a format string. <br>`format!` 收到的第一个参数是格式字符串。<br> This must be a string literal. <br>这必须是字符串字面量。<br> The power of the formatting string is in the `{}`s contained. <br>格式字符串的作用是包含在 {{} 中。<br>
///
/// Additional parameters passed to `format!` replace the `{}`s within the formatting string in the order given unless named or positional parameters are used; <br>除非使用命名或位置参数，否则传递给 `format!` 的其他参数将以给定的顺序替换格式字符串中的 {}。<br> see [`std::fmt`] for more information. <br>有关更多信息，请参见 [`std::fmt`]。<br>
///
///
/// A common use for `format!` is concatenation and interpolation of strings. <br>`format!` 的常见用法是字符串的连接和内插。<br>
/// The same convention is used with [`print!`] and [`write!`] macros, depending on the intended destination of the string. <br>[`print!`] 和 [`write!`] 宏使用相同的约定，具体取决于字符串的预期目标。<br>
///
/// To convert a single value to a string, use the [`to_string`] method. <br>要将单个值转换为字符串，请使用 [`to_string`] 方法。<br> This will use the [`Display`] formatting trait. <br>这将使用 [`Display`] 格式 trait。<br>
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics if a formatting trait implementation returns an error. <br>如果格式化 trait 实现返回了错误，则会出现 `format!` panics。<br>
/// This indicates an incorrect implementation since `fmt::Write for String` never returns an error itself. <br>这表明实现不正确，因为 `fmt::Write for String` 本身从不返回错误。<br>
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Force AST node to an expression to improve diagnostics in pattern position. <br>强制 AST 节点使用表达式以改善模式位置的诊断。<br>
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}
