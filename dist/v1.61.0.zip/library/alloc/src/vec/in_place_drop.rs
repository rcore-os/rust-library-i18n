use core::ptr::{self};
use core::slice::{self};

// 用于就地迭代的辅助结构体，该结构体将迭代的目标切片 (即头部) 丢弃。
// 源切片 (尾部) 由 IntoIter 丢弃。
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}
