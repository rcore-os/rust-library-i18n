use super::mystd::borrow::ToOwned;
use super::mystd::ffi::{CStr, OsStr};
use super::mystd::os::unix::prelude::*;
use super::{Library, LibrarySegment, Vec};
use core::mem;
use object::NativeEndian;

#[cfg(target_pointer_width = "64")]
use object::elf::{FileHeader64 as FileHeader, ProgramHeader64 as ProgramHeader};

type EHdr = FileHeader<NativeEndian>;
type PHdr = ProgramHeader<NativeEndian>;

#[repr(C)]
struct LinkMap {
    l_addr: libc::c_ulong,
    l_name: *const libc::c_char,
    l_ld: *const libc::c_void,
    l_next: *const LinkMap,
    l_prev: *const LinkMap,
    l_refname: *const libc::c_char,
}

const RTLD_SELF: *const libc::c_void = -3isize as *const libc::c_void;
const RTLD_DI_LINKMAP: libc::c_int = 2;

extern "C" {
    fn dlinfo(
        handle: *const libc::c_void,
        request: libc::c_int,
        p: *mut libc::c_void,
    ) -> libc::c_int;
}

pub(super) fn native_libraries() -> Vec<Library> {
    let mut libs = Vec::new();

    // 从运行时链接器请求当前链接 map：
    let map = unsafe {
        let mut map: *const LinkMap = mem::zeroed();
        if dlinfo(
            RTLD_SELF,
            RTLD_DI_LINKMAP,
            (&mut map) as *mut *const LinkMap as *mut libc::c_void,
        ) != 0
        {
            return libs;
        }
        map
    };

    // 链接 map 中的每个条目代表一个加载的对象：
    let mut l = map;
    while !l.is_null() {
        // 获取加载的对象的完全限定路径：
        let bytes = unsafe { CStr::from_ptr((*l).l_name) }.to_bytes();
        let name = OsStr::from_bytes(bytes).to_owned();

        // 加载到内存中的对象的基地址：
        let addr = unsafe { (*l).l_addr };

        // 使用此 object 的 ELF 标头来定位程序标头：
        //
        let e: *const EHdr = unsafe { (*l).l_addr as *const EHdr };
        let phoff = unsafe { (*e).e_phoff }.get(NativeEndian);
        let phnum = unsafe { (*e).e_phnum }.get(NativeEndian);
        let etype = unsafe { (*e).e_type }.get(NativeEndian);

        let phdr: *const PHdr = (addr + phoff) as *const PHdr;
        let phdr = unsafe { core::slice::from_raw_parts(phdr, phnum as usize) };

        libs.push(Library {
            name,
            segments: phdr
                .iter()
                .map(|p| {
                    let memsz = p.p_memsz.get(NativeEndian);
                    let vaddr = p.p_vaddr.get(NativeEndian);
                    LibrarySegment {
                        len: memsz as usize,
                        stated_virtual_memory_address: vaddr as usize,
                    }
                })
                .collect(),
            bias: if etype == object::elf::ET_EXEC {
                // 基本可执行文件的程序头地址已经是绝对的。
                //
                0
            } else {
                // 其他地址是相对于对象库的。
                addr as usize
            },
        });

        l = unsafe { (*l).l_next };
    }

    libs
}
