等效于 C 的 `float` 类型。

此类型几乎总是 [`f32`]，并保证它是 Rust 中的 [IEEE-754 单精度浮点数][IEEE-754 single-precision float]。就是说，该标准从技术上仅保证它是浮点数，并且它的精度可能低于 `f32` 或完全不遵循 IEEE-754 标准。

[IEEE-754 single-precision float]: https://en.wikipedia.org/wiki/IEEE_754
