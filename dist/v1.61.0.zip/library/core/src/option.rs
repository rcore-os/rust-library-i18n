//! 可选值。
//!
//! 类型 [`Option`] 表示一个可选值：每个 [`Option`] 均为 [`Some`] 并包含一个值，或者为 [`None`]，但不包含。
//! [`Option`] 类型在 Rust 代码中非常常见，因为它们有多种用途：
//!
//! * 初始值
//! * 未在整个输入范围内定义的函数的返回值 (部分函数)
//! * 返回值，用于报告否则将报告简单错误的错误，其中错误返回 [`None`]
//! * 可选的结构体字段
//! * 可借用或 "taken" 的结构体字段
//! * 可选的函数参数
//! * 可空指针
//! * 从困难的情况中交换东西
//!
//! 通常将 [`Option`] 与模式匹配配对，以查询值的存在并采取措施，始终考虑 [`None`] 的情况。
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // 函数的返回值是一个选项
//! let result = divide(2.0, 3.0);
//!
//! // 模式匹配以获取值
//! match result {
//!     // 该划分有效
//!     Some(x) => println!("Result: {x}"),
//!     // 划分无效
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
//
// FIXME: 通过多种方法展示 `Option` 在实践中的使用方式
//
//! # 选项和指针 ("nullable" 指针)
//!
//! Rust 的指针类型必须始终指向有效位置。没有 "null" 引用。相反，Rust 有 *optional* 指针，就像可选的拥有所有权的 box，<code>[Option]<[Box\<T>]></code>。
//!
//! [Box\<T>]: ../../std/boxed/struct.Box.html
//!
//! 以下示例使用 [`Option`] 创建 [`i32`] 的可选 box。
//! 注意，为了使用内部的 [`i32`] 值，`check_optional` 函数首先需要使用模式匹配来确定 box 是否有值 (即它是 [`Some(...)`][`Some`]) 或没有 ([`None`])。
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {p}"),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust 保证优化以下 `T` 类型，以使 [`Option<T>`] 具有与 `T` 相同的大小：
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`[^extern_fn]
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` 结构体围绕此列表中的一种类型。
//!
//! [^extern_fn]: 这对于任何其他 ABI 仍然适用: `extern "abi" fn` (例如，`extern "system" fn`)
//!
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//! 这称为 "空指针优化" 或 NPO。
//!
//! 对于上述情况，可以进一步保证，可以从 `T` 到 `Option<T>` 的所有有效值以及从 `Some::<T>(_)` 到 `T` 的所有有效值 [`mem::transmute`] (但是将 `None::<T>` 转换为 `T` 是未定义的行为)。
//!
//! # 方法概述
//!
//! 除了使用模式匹配，[`Option`] 还提供了多种不同的方法。
//!
//! ## 查询变体
//!
//! 如果 [`Option`] 分别为 [`Some`] 或 [`None`]，则 [`is_some`] 和 [`is_none`] 方法返回 [`true`]。
//!
//! [`is_none`]: Option::is_none
//! [`is_some`]: Option::is_some
//!
//! ## 用于处理引用的适配器
//!
//! * [`as_ref`] 从 <code>[&][][Option]\<T></code> 转换为 <code>[Option]<[&]T></code>
//! * [`as_mut`] 从 <code>[&mut] [Option]\<T></code> 转换为 <code>[Option]<[&mut] T></code>
//! * [`as_deref`] 从 <code>[&][][Option]\<T></code> 转换为
//!   <code>[Option]<[&]T::[Target]></code>
//! * [`as_deref_mut`] 从 <code>[&mut] [Option]\<T></code> 转换为
//!   <code>[Option]<[&mut] T::[Target]></code>
//! * [`as_pin_ref`] 从 <code>[Pin]<[&][][Option]\<T>></code> 转换为
//!   <code>[Option]<[Pin]<[&]T>></code>
//! * [`as_pin_mut`] 从 <code>[Pin]<[&mut] [Option]\<T>></code> 转换为
//!   <code>[Option]<[Pin]<[&mut] T>></code>
//!
//! [&]: reference "shared reference"
//! [&mut]: reference "mutable reference"
//! [Target]: Deref::Target "ops::Deref::Target"
//! [`as_deref`]: Option::as_deref
//! [`as_deref_mut`]: Option::as_deref_mut
//! [`as_mut`]: Option::as_mut
//! [`as_pin_mut`]: Option::as_pin_mut
//! [`as_pin_ref`]: Option::as_pin_ref
//! [`as_ref`]: Option::as_ref
//!
//! ## 提取包含的值
//!
//! 当它是 [`Some`] 变体时，这些方法提取 [`Option<T>`] 中包含的值。如果 [`Option`] 为 [`None`]：
//!
//! * [`expect`] panics 带有提供的自定义消息
//! * [`unwrap`] panics 带有泛型信息
//! * [`unwrap_or`] 返回提供的默认值
//! * [`unwrap_or_default`] 返回类型 `T` 的默认值 (必须实现 [`Default`] trait)
//! * [`unwrap_or_else`] 返回对提供的函数求值的结果
//!
//! [`expect`]: Option::expect
//! [`unwrap`]: Option::unwrap
//! [`unwrap_or`]: Option::unwrap_or
//! [`unwrap_or_default`]: Option::unwrap_or_default
//! [`unwrap_or_else`]: Option::unwrap_or_else
//!
//! ## 转换包含的值
//!
//! 这些方法将 [`Option`] 转换为 [`Result`]：
//!
//! * [`ok_or`] 使用提供的默认 `err` 值将 [`Some(v)`] 转换为 [`Ok(v)`]，将 [`None`] 转换为 [`Err(err)`]
//! * [`ok_or_else`] 使用提供的函数将 [`Some(v)`] 转换为 [`Ok(v)`]，并将 [`None`] 转换为 [`Err`] 的值
//! * [`transpose`] transposes an [`Option`] of a [`Result`] into a [`Result`] of an [`Option`]
//!
//! [`Err(err)`]: Err
//! [`Ok(v)`]: Ok
//! [`Some(v)`]: Some
//! [`ok_or`]: Option::ok_or
//! [`ok_or_else`]: Option::ok_or_else
//! [`transpose`]: Option::transpose
//!
//! 这些方法转换了 [`Some`] 变体：
//!
//! * [`filter`] calls the provided predicate function on the contained value `t` if the [`Option`] is [`Some(t)`], and returns [`Some(t)`] if the function returns `true`; otherwise, returns [`None`]
//! * [`flatten`] 从一个对象中删除一层嵌套
//!   [`Option<Option<T>>`]
//! * [`map`] 通过将提供的函数应用于 [`Some`] 的包含值并保持 [`None`] 值不变，将 [`Option<T>`] 转换为 [`Option<U>`]
//!
//! [`Some(t)`]: Some
//! [`filter`]: Option::filter
//! [`flatten`]: Option::flatten
//! [`map`]: Option::map
//!
//! 这些方法将 [`Option<T>`] 转换为可能不同类型 `U` 的值：
//!
//! * [`map_or`] 将提供的函数应用于 [`Some`] 的包含值，或者如果 [`Option`] 是返回提供的默认值
//!   [`None`]
//! * [`map_or_else`] applies the provided function to the contained value of [`Some`], or returns the result of evaluating the provided fallback function if the [`Option`] is [`None`]
//!
//! [`map_or`]: Option::map_or
//! [`map_or_else`]: Option::map_or_else
//!
//! 这些方法结合了两个 [`Option`] 值的 [`Some`] 变体：
//!
//! * [`zip`] returns [`Some((s, o))`] if `self` is [`Some(s)`] and the provided [`Option`] value is [`Some(o)`]; otherwise, returns [`None`]
//! * [`zip_with`] calls the provided function `f` and returns [`Some(f(s, o))`] if `self` is [`Some(s)`] and the provided [`Option`] value is [`Some(o)`]; otherwise, returns [`None`]
//!
//! [`Some(f(s, o))`]: Some
//! [`Some(o)`]: Some
//! [`Some(s)`]: Some
//! [`Some((s, o))`]: Some
//! [`zip`]: Option::zip
//! [`zip_with`]: Option::zip_with
//!
//! ## 布尔运算符
//!
//! 这些方法将 [`Option`] 视为布尔值，其中 [`Some`] 的作用类似于 [`true`]，而 [`None`] 的作用类似于 [`false`]。这些方法有两类：一类以 [`Option`] 作为输入，一类以函数作为输入 (延迟评估)。
//!
//! [`and`]、[`or`] 和 [`xor`] 方法将另一个 [`Option`] 作为输入，并生成一个 [`Option`] 作为输出。只有 [`and`] 方法可以生成具有与 [`Option<T>`] 不同的内部类型 `U` 的 [`Option<U>`] 值。
//!
//! | method  | self      | input     | output    |
//! |---------|-----------|-----------|-----------|
//! | [`and`] | `None`    | (ignored) | `None`    |
//! | [`and`] | `Some(x)` | `None`    | `None`    |
//! | [`and`] | `Some(x)` | `Some(y)` | `Some(y)` |
//! | [`or`]  | `None`    | `None`    | `None`    |
//! | [`or`]  | `None`    | `Some(y)` | `Some(y)` |
//! | [`or`]  | `Some(x)` | (ignored) | `Some(x)` |
//! | [`xor`] | `None`    | `None`    | `None`    |
//! | [`xor`] | `None`    | `Some(y)` | `Some(y)` |
//! | [`xor`] | `Some(x)` | `None`    | `Some(x)` |
//! | [`xor`] | `Some(x)` | `Some(y)` | `None`    |
//!
//! [`and`]: Option::and
//! [`or`]: Option::or
//! [`xor`]: Option::xor
//!
//! [`and_then`] 和 [`or_else`] 方法将函数作为输入，并且仅在需要产生新值时才评估函数。只有 [`and_then`] 方法可以生成具有与 [`Option<T>`] 不同的内部类型 `U` 的 [`Option<U>`] 值。
//!
//! | method       | self      | function input | function result | output    |
//! |--------------|-----------|----------------|-----------------|-----------|
//! | [`and_then`] | `None`    | (not provided) | (not evaluated) | `None`    |
//! | [`and_then`] | `Some(x)` | `x`            | `None`          | `None`    |
//! | [`and_then`] | `Some(x)` | `x`            | `Some(y)`       | `Some(y)` |
//! | [`or_else`]  | `None`    | (not provided) | `None`          | `None`    |
//! | [`or_else`]  | `None`    | (not provided) | `Some(y)`       | `Some(y)` |
//! | [`or_else`]  | `Some(x)` | (not provided) | (not evaluated) | `Some(x)` |
//!
//! [`and_then`]: Option::and_then
//! [`or_else`]: Option::or_else
//!
//! 这是在方法调用管道中使用 [`and_then`] 和 [`or`] 等方法的示例。管道的早期阶段通过不变的失败值 ([`None`])，并继续处理成功值 ([`Some`])。
//! 最后，如果 [`or`] 收到 [`None`]，它会替换一条错误消息。
//!
//! ```
//! # use std::collections::BTreeMap;
//! let mut bt = BTreeMap::new();
//! bt.insert(20u8, "foo");
//! bt.insert(42u8, "bar");
//! let res = [0u8, 1, 11, 200, 22]
//!     .into_iter()
//!     .map(|x| {
//!         // `checked_sub()` 出错时返回 `None`
//!         x.checked_sub(1)
//!             // 与 `checked_mul()` 相同
//!             .and_then(|x| x.checked_mul(2))
//!             // `BTreeMap::get` 出错时返回 `None`
//!             .and_then(|x| bt.get(&x))
//!             // 如果到目前为止我们有 `None`，则替换一条错误消息
//!             .or(Some(&"error!"))
//!             .copied()
//!             // 不会 panic 因为我们无条件使用了上面的 `Some`
//!             .unwrap()
//!     })
//!     .collect::<Vec<_>>();
//! assert_eq!(res, ["error!", "error!", "foo", "error!", "bar"]);
//! ```
//!
//! ## 比较运算符
//!
//! 如果 `T` 实现 [`PartialOrd`]，那么 [`Option<T>`] 将派生其 [`PartialOrd`] 实现。使用此顺序，[`None`] 的比较比任何 [`Some`] 都小，两个 [`Some`] 的比较方式与其在 `T` 中包含的值相同。
//! 如果 `T` 也实现了 [`Ord`]，那么 [`Option<T>`] 也是如此。
//!
//! ```
//! assert!(None < Some(0));
//! assert!(Some(0) < Some(1));
//! ```
//!
//! ## 迭代结束 `Option`
//!
//! 可以对 [`Option`] 进行迭代。如果您需要一个条件为空的迭代器，这会很有帮助。迭代器将产生单个值 (当 [`Option`] 为 [`Some`] 时)，或不产生任何值 (当 [`Option`] 为 [`None`] 时)。
//! 例如，如果 [`Option`] 是 [`Some(v)`]，则 [`into_iter`] 的作用类似于 [`once(v)`]; 如果 [`Option`] 是 [`None`]，则它的作用类似于 [`empty()`]。
//!
//! [`Some(v)`]: Some
//! [`empty()`]: crate::iter::empty
//! [`once(v)`]: crate::iter::once
//!
//! [`Option<T>`] 上的迭代器分为三种类型：
//!
//! * [`into_iter`] 消耗 [`Option`] 并产生包含的值
//! * [`iter`] 对包含的值产生类型为 `&T` 的不可变引用
//! * [`iter_mut`] 产生一个 `&mut T` 类型的可变引用到包含的值
//!
//! [`into_iter`]: Option::into_iter
//! [`iter`]: Option::iter
//! [`iter_mut`]: Option::iter_mut
//!
//! [`Option`] 上的迭代器在链接迭代器时很有用，例如，有条件地插入项。
//! (并不总是需要显式调用迭代器构造函数：许多接受其他迭代器的 [`Iterator`] 方法也将接受实现 [`IntoIterator`] 的可迭代类型，其中包括 [`Option`]。)
//!
//! ```
//! let yep = Some(42);
//! let nope = None;
//! // chain() 已经调用 into_iter()，所以我们不必这样做
//! let nums: Vec<i32> = (0..4).chain(yep).chain(4..8).collect();
//! assert_eq!(nums, [0, 1, 2, 3, 42, 4, 5, 6, 7]);
//! let nums: Vec<i32> = (0..4).chain(nope).chain(4..8).collect();
//! assert_eq!(nums, [0, 1, 2, 3, 4, 5, 6, 7]);
//! ```
//!
//! 以这种方式链接迭代器的一个原因是，返回 `impl Iterator` 的函数必须使所有可能的返回值都具有相同的具体类型。链接一个迭代的 [`Option`] 可以帮助解决这个问题。
//!
//! ```
//! fn make_iter(do_insert: bool) -> impl Iterator<Item = i32> {
//!     // 显式返回来说明返回类型匹配
//!     match do_insert {
//!         true => return (0..4).chain(Some(42)).chain(4..8),
//!         false => return (0..4).chain(None).chain(4..8),
//!     }
//! }
//! println!("{:?}", make_iter(true).collect::<Vec<_>>());
//! println!("{:?}", make_iter(false).collect::<Vec<_>>());
//! ```
//!
//! 如果我们尝试做同样的事情，但是使用 [`once()`] 和 [`empty()`]，我们就不能再返回 `impl Iterator`，因为返回值的具体类型不同。
//!
//! [`empty()`]: crate::iter::empty
//! [`once()`]: crate::iter::once
//!
//! ```compile_fail,E0308
//! # use std::iter::{empty, once};
//! // 这不会编译，因为函数的所有可能返回必须具有相同的具体类型。
//! //
//! fn make_iter(do_insert: bool) -> impl Iterator<Item = i32> {
//!     // 显式返回以说明返回类型不匹配
//!     match do_insert {
//!         true => return (0..4).chain(once(42)).chain(4..8),
//!         false => return (0..4).chain(empty()).chain(4..8),
//!     }
//! }
//! ```
//!
//! ## 收集到 `Option`
//!
//! [`Option`] 实现了 [`FromIterator`][impl-FromIterator] trait，它允许将 [`Option`] 值上的迭代器收集到原始 [`Option`] 值的每个包含值的集合的 [`Option`] 中，或者如果任何元素是 [`None`]，则为 [`None`]。
//!
//!
//! [impl-FromIterator]: Option#impl-FromIterator%3COption%3CA%3E%3E
//!
//! ```
//! let v = [Some(2), Some(4), None, Some(8)];
//! let res: Option<Vec<_>> = v.into_iter().collect();
//! assert_eq!(res, None);
//! let v = [Some(2), Some(4), Some(8)];
//! let res: Option<Vec<_>> = v.into_iter().collect();
//! assert_eq!(res, Some(vec![2, 4, 8]));
//! ```
//!
//! [`Option`] 还实现了 [`Product`][impl-Product] 和 [`Sum`][impl-Sum] traits，允许对 [`Option`] 值的迭代器提供 [`product`][Iterator::product] 和 [`sum`][Iterator::sum] 方法。
//!
//! [impl-Product]: Option#impl-Product%3COption%3CU%3E%3E
//! [impl-Sum]: Option#impl-Sum%3COption%3CU%3E%3E
//!
//! ```
//! let v = [None, Some(1), Some(2), Some(3)];
//! let res: Option<i32> = v.into_iter().sum();
//! assert_eq!(res, None);
//! let v = [Some(1), Some(2), Some(21)];
//! let res: Option<i32> = v.into_iter().product();
//! assert_eq!(res, Some(42));
//! ```
//!
//! ## 就地修改 [`Option`]
//!
//! 这些方法返回对包含的值的可变引用
//! [`Option<T>`]:
//!
//! * [`insert`] 插入一个值，丢弃任何旧内容
//! * [`get_or_insert`] gets the current value, inserting a provided default value if it is [`None`]
//! * [`get_or_insert_default`] 获取当前值，如果是，则插入类型 `T` (必须实现 [`Default`]) 的默认值
//!   [`None`]
//! * [`get_or_insert_with`] gets the current value, inserting a default computed by the provided function if it is [`None`]
//!
//! [`get_or_insert`]: Option::get_or_insert
//! [`get_or_insert_default`]: Option::get_or_insert_default
//! [`get_or_insert_with`]: Option::get_or_insert_with
//! [`insert`]: Option::insert
//!
//! 这些方法转移包含的值的所有权
//! [`Option`]:
//!
//! * [`take`] takes ownership of the contained value of an [`Option`], if any, replacing the [`Option`] with [`None`]
//! * [`replace`] 获得 [`Option`] 包含的值的所有权 (如果有)，用包含提供的值的 [`Some`] 替换 [`Option`]
//!
//! [`replace`]: Option::replace
//! [`take`]: Option::take
//!
//! # Examples
//!
//! [`Option`] 上的基本模式匹配：
//!
//! ```
//! let msg = Some("howdy");
//!
//! // 获取对所包含字符串的引用
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // 删除包含的字符串，销毁 Option
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! 循环前将结果初始化为 [`None`]：
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // 要搜索的数据列表。
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // 我们将搜索最大的动物的名称，但首先要获取 `None`。
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // 现在我们找到了一些大动物的名字
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {name}"),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::marker::Destruct;
use crate::panicking::{panic, panic_str};
use crate::pin::Pin;
use crate::{
    convert, hint, mem,
    ops::{self, ControlFlow, Deref, DerefMut},
};

/// `Option` 类型。有关更多信息，请参见 [模块级文档](self)。
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "Option"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// 没有值。
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// `T` 类型的某些值。
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// 类型实现
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // 查询包含的值
    /////////////////////////////////////////////////////////////////////////

    /// 如果选项是 [`Some`] 值，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_option_basics", since = "1.48.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// 如果选项是 [`Some`] 并且其中的值与谓词匹配，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_some_with)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some_and(|&x| x > 1), true);
    ///
    /// let x: Option<u32> = Some(0);
    /// assert_eq!(x.is_some_and(|&x| x > 1), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some_and(|&x| x > 1), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "is_some_with", issue = "93050")]
    pub fn is_some_and(&self, f: impl FnOnce(&T) -> bool) -> bool {
        matches!(self, Some(x) if f(x))
    }

    /// 如果选项是 [`None`] 值，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|_| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_option_basics", since = "1.48.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /////////////////////////////////////////////////////////////////////////
    // 用于引用的适配器
    /////////////////////////////////////////////////////////////////////////

    /// 从 `&Option<T>` 转换为 `Option<&T>`。
    ///
    /// # Examples
    ///
    /// 将 <code>Option<[String]></code> 转换为 <code>Option<[usize]></code>，保留原始值。
    /// [`map`] 方法按值使用 `self` 参数，从而消耗了原始文件，因此该技术使用 `as_ref` 首先将 `Option` 引用给原始文件中的值。
    ///
    ///
    /// [`map`]: Option::map
    /// [String]: ../../std/string/struct.String.html "String"
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // 首先，使用 `as_ref` 将 `Option<String>` 转换为 `Option<&String>`，然后在 `map` 上消费它，在栈上留下 `text`。
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {text:?}");
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option_basics", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// 从 `&mut Option<T>` 转换为 `Option<&mut T>`。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// 从 <code>[Pin]<[&]Option\<T>></code> 到 <code>Option<[Pin]<[&]T>></code>。
    ///
    /// [&]: reference "shared reference"
    #[inline]
    #[must_use]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    pub const fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        match Pin::get_ref(self).as_ref() {
            // SAFETY: `x` 被固定，因为它来自被固定的 `self`。
            //
            Some(x) => unsafe { Some(Pin::new_unchecked(x)) },
            None => None,
        }
    }

    /// 转换自 <code>[Pin]<[&mut] Option\<T>></code> 到 <code>Option<[Pin]<[&mut] T>></code>。
    ///
    /// [&mut]: reference "mutable reference"
    #[inline]
    #[must_use]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    pub const fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // SAFETY: `get_unchecked_mut` 从未用于在 `self` 内部移动 `Option`。
        // `x` 被固定，因为它来自被固定的 `self`。
        unsafe {
            match Pin::get_unchecked_mut(self).as_mut() {
                Some(x) => Some(Pin::new_unchecked(x)),
                None => None,
            }
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 获取包含的值
    /////////////////////////////////////////////////////////////////////////

    /// 返回包含 `self` 值的包含的 [`Some`] 值。
    ///
    /// # Panics
    ///
    /// 如果值为 [`None`] 并带有由 `msg` 提供的自定义 panic 消息，就会出现 panics。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // `fruits are healthy` 的 panics
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// 返回包含 `self` 值的包含的 [`Some`] 值。
    ///
    /// 由于此函数可能为 panic，因此通常不建议使用该函数。
    /// 相反，更喜欢使用模式匹配并显式处理 [`None`] 大小写，或者调用 [`unwrap_or`]，[`unwrap_or_else`] 或 [`unwrap_or_default`]。
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// 如果 self 的值等于 [`None`]，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// 返回包含的 [`Some`] 值或提供的默认值。
    ///
    /// 急切地评估传递给 `unwrap_or` 的参数； 如果要传递函数调用的结果，建议使用 [`unwrap_or_else`]，它是惰性求值的。
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn unwrap_or(self, default: T) -> T
    where
        T: ~const Drop + ~const Destruct,
    {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// 返回包含的 [`Some`] 值或从闭包中计算得出。
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn unwrap_or_else<F>(self, f: F) -> T
    where
        F: ~const FnOnce() -> T,
        F: ~const Drop + ~const Destruct,
    {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// 返回包含的 [`Some`] 值或默认值。
    ///
    /// 消费 `self` 参数，如果 [`Some`]，则返回所包含的值，否则，如果 [`None`]，则返回该类型的 [默认值][default value]。
    ///
    ///
    /// # Examples
    ///
    /// 将字符串转换为整数，将格式不正确的字符串转换为 0 (整数的默认值)。
    /// [`parse`] 将字符串转换为实现 [`FromStr`] 的任何其他类型，并在出错时返回 [`None`]。
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    pub const fn unwrap_or_default(self) -> T
    where
        T: ~const Default,
    {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }

    /// 返回包含 `self` 值的包含的 [`Some`] 值，而不检查该值是否不是 [`None`]。
    ///
    ///
    /// # Safety
    ///
    /// 在 [`None`] 上调用此方法是 *[undefined behavior]*。
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // 未定义的行为！
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "option_result_unwrap_unchecked", since = "1.58.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    pub const unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // SAFETY: 调用者必须坚持安全保证。
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 转换包含的值
    /////////////////////////////////////////////////////////////////////////

    /// 通过将函数应用于包含的值，Maps 将 `Option<T>` 转换为 `Option<U>`。
    ///
    /// # Examples
    ///
    /// 将 <code>Option<[String]></code> 转换为 <code>Option<[usize]></code>，使用原始值：
    ///
    ///
    /// [String]: ../../std/string/struct.String.html "String"
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` 按值获取 self，消耗 `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn map<U, F>(self, f: F) -> Option<U>
    where
        F: ~const FnOnce(T) -> U,
        F: ~const Drop + ~const Destruct,
    {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// 使用对包含值的引用调用提供的闭包 (如果 [`Some`])。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_option_inspect)]
    ///
    /// let v = vec![1, 2, 3, 4, 5];
    ///
    /// // 打印 "got: 4"
    /// let x: Option<&usize> = v.get(3).inspect(|x| println!("got: {x}"));
    ///
    /// // 什么都不打印
    /// let x: Option<&usize> = v.get(5).inspect(|x| println!("got: {x}"));
    /// ```
    #[inline]
    #[unstable(feature = "result_option_inspect", issue = "91345")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn inspect<F>(self, f: F) -> Self
    where
        F: ~const FnOnce(&T),
        F: ~const Drop + ~const Destruct,
    {
        if let Some(ref x) = self {
            f(x);
        }

        self
    }

    /// 返回提供的默认结果 (如果没有)，或将函数应用于包含的值 (如果有)。
    ///
    /// 传递给 `map_or` 的参数会被急切地评估； 如果要传递函数调用的结果，建议使用 [`map_or_else`]，它是延迟计算的。
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn map_or<U, F>(self, default: U, f: F) -> U
    where
        F: ~const FnOnce(T) -> U,
        F: ~const Drop + ~const Destruct,
        U: ~const Drop + ~const Destruct,
    {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// 计算 default 函数的结果 (如果没有)，或将不同的函数应用于包含的值 (如果有)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn map_or_else<U, D, F>(self, default: D, f: F) -> U
    where
        D: ~const FnOnce() -> U,
        D: ~const Drop + ~const Destruct,
        F: ~const FnOnce(T) -> U,
        F: ~const Drop + ~const Destruct,
    {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// 将 `Option<T>` 转换为 [`Result<T, E>`]，将 [`Some(v)`] 映射到 [`Ok(v)`]，将 [`None`] 映射到 [`Err(err)`]。
    ///
    /// 急切地评估传递给 `ok_or` 的参数； 如果要传递函数调用的结果，建议使用 [`ok_or_else`]，它是延迟计算的。
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn ok_or<E>(self, err: E) -> Result<T, E>
    where
        E: ~const Drop + ~const Destruct,
    {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// 将 `Option<T>` 转换为 [`Result<T, E>`]，将 [`Some(v)`] 映射到 [`Ok(v)`]，将 [`None`] 映射到 [`Err(err())`]。
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn ok_or_else<E, F>(self, err: F) -> Result<T, E>
    where
        F: ~const FnOnce() -> E,
        F: ~const Drop + ~const Destruct,
    {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// 从 `Option<T>` (或 `&Option<T>`) 转换为 `Option<&T::Target>`。
    ///
    /// 将原始 Option 保留在原位，创建一个带有对原始 Option 的引用的新 Option，并通过 [`Deref`] 强制执行其内容。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    pub const fn as_deref(&self) -> Option<&T::Target>
    where
        T: ~const Deref,
    {
        match self.as_ref() {
            Some(t) => Some(t.deref()),
            None => None,
        }
    }

    /// 从 `Option<T>` (或 `&mut Option<T>`) 转换为 `Option<&mut T::Target>`。
    ///
    /// 在这里保留原始的 `Option`，创建一个包含对内部类型的 [`Deref::Target`] 类型的可变引用的新的 `Option`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    pub const fn as_deref_mut(&mut self) -> Option<&mut T::Target>
    where
        T: ~const DerefMut,
    {
        match self.as_mut() {
            Some(t) => Some(t.deref_mut()),
            None => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 迭代器构造函数
    /////////////////////////////////////////////////////////////////////////

    /// 返回可能包含的值的迭代器。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// 返回可能包含的值的可变迭代器。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // 对值的布尔运算，渴望和懒惰
    /////////////////////////////////////////////////////////////////////////

    /// 如果选项为 [`None`]，则返回 [`None`]; 否则，返回 `optb`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn and<U>(self, optb: Option<U>) -> Option<U>
    where
        T: ~const Drop + ~const Destruct,
        U: ~const Drop + ~const Destruct,
    {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// 如果选项为 [`None`]，则返回 [`None`]; 否则，使用包装的值调用 `f`，并返回结果。
    ///
    ///
    /// 一些语言调用此操作平面图。
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq_then_to_string(x: u32) -> Option<String> {
    ///     x.checked_mul(x).map(|sq| sq.to_string())
    /// }
    ///
    /// assert_eq!(Some(2).and_then(sq_then_to_string), Some(4.to_string()));
    /// assert_eq!(Some(1_000_000).and_then(sq_then_to_string), None); // overflowed!
    /// assert_eq!(None.and_then(sq_then_to_string), None);
    /// ```
    ///
    /// 通常用于链接可能返回 [`None`] 的错误操作。
    ///
    /// ```
    /// let arr_2d = [["A0", "A1"], ["B0", "B1"]];
    ///
    /// let item_0_1 = arr_2d.get(0).and_then(|row| row.get(1));
    /// assert_eq!(item_0_1, Some(&"A1"));
    ///
    /// let item_2_0 = arr_2d.get(2).and_then(|row| row.get(0));
    /// assert_eq!(item_2_0, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn and_then<U, F>(self, f: F) -> Option<U>
    where
        F: ~const FnOnce(T) -> Option<U>,
        F: ~const Drop + ~const Destruct,
    {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// 如果选项为 [`None`]，则返回 [`None`]; 否则，使用包装的值调用 `predicate` 并返回：
    ///
    ///
    /// - [`Some(t)`] 如果 `predicate` 返回 `true` (其中 `t` 是包装值)，并且
    /// - [`None`] 如果 `predicate` 返回 `false`。
    ///
    /// 该函数的工作方式类似于 [`Iterator::filter()`]。
    /// 您可以想象 `Option<T>` 是一个或零个元素上的迭代器。
    /// `filter()` 让您决定保留哪些元素。
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn filter<P>(self, predicate: P) -> Self
    where
        T: ~const Drop + ~const Destruct,
        P: ~const FnOnce(&T) -> bool,
        P: ~const Drop + ~const Destruct,
    {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// 如果包含值，则返回选项，否则返回 `optb`。
    ///
    /// 传递给 `or` 的参数会被急切地评估； 如果要传递函数调用的结果，建议使用 [`or_else`]，它是延迟计算的。
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn or(self, optb: Option<T>) -> Option<T>
    where
        T: ~const Drop + ~const Destruct,
    {
        match self {
            Some(x) => Some(x),
            None => optb,
        }
    }

    /// 如果选项包含值，则返回该选项，否则调用 `f` 并返回结果。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn or_else<F>(self, f: F) -> Option<T>
    where
        F: ~const FnOnce() -> Option<T>,
        F: ~const Drop + ~const Destruct,
    {
        match self {
            Some(x) => Some(x),
            None => f(),
        }
    }

    /// 如果 `self`，`optb` 之一恰好是 [`Some`]，则返回 [`Some`]，否则返回 [`None`]。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn xor(self, optb: Option<T>) -> Option<T>
    where
        T: ~const Drop + ~const Destruct,
    {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 类似条目的操作，插入一个值并返回一个引用
    /////////////////////////////////////////////////////////////////////////

    /// 将 `value` 插入到选项，然后返回对它的可变引用。
    ///
    /// 如果该选项已包含值，则将丢弃旧值。
    ///
    /// 另请参见 [`Option::get_or_insert`]，如果选项已包含 [`Some`]，则不会更新值。
    ///
    ///
    /// # Example
    ///
    /// ```
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[must_use = "if you intended to set a value, consider assignment instead"]
    #[inline]
    #[stable(feature = "option_insert", since = "1.53.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn insert(&mut self, value: T) -> &mut T
    where
        T: ~const Drop + ~const Destruct,
    {
        *self = Some(value);

        // SAFETY: 上面的代码刚刚填满了该选项
        unsafe { self.as_mut().unwrap_unchecked() }
    }

    /// 如果为 [`None`]，则将 `value` 插入到选项中，然后返回所包含的值的变量引用。
    ///
    ///
    /// 另请参见 [`Option::insert`]，即使选项已包含 [`Some`]，它也会更新值。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn get_or_insert(&mut self, value: T) -> &mut T
    where
        T: ~const Drop + ~const Destruct,
    {
        if let None = *self {
            *self = Some(value);
        }

        // SAFETY: 在上面的代码中，用于 `self` 的 `None` 变体将被替换为 `Some` 变体。
        //
        unsafe { self.as_mut().unwrap_unchecked() }
    }

    /// 如果默认值为 [`None`]，则将其插入选项中，然后将所包含的值返回变量引用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    pub const fn get_or_insert_default(&mut self) -> &mut T
    where
        T: ~const Default,
    {
        #[rustc_allow_const_fn_unstable(const_fn_trait_bound)]
        const fn default<T: ~const Default>() -> T {
            T::default()
        }

        self.get_or_insert_with(default)
    }

    /// 如果从 `f` 计算得出的值是 [`None`]，则将其插入选项中，然后将所包含的值返回可变引用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn get_or_insert_with<F>(&mut self, f: F) -> &mut T
    where
        F: ~const FnOnce() -> T,
        F: ~const Drop + ~const Destruct,
    {
        if let None = *self {
            // 编译器不够聪明，不知道我们不会在这里丢弃 `T`，而是希望我们确保 `T` 可以在编译时被丢弃。
            //
            mem::forget(mem::replace(self, Some(f())))
        }

        // SAFETY: 在上面的代码中，用于 `self` 的 `None` 变体将被替换为 `Some` 变体。
        //
        unsafe { self.as_mut().unwrap_unchecked() }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// 从选项中取出值，将 [`None`] 留在其位置。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn take(&mut self) -> Option<T> {
        // FIXME 当后者准备好时，用 `mem::take` 替换 `mem::replace`
        mem::replace(self, None)
    }

    /// 用参数中给定的值替换选项中的实际值，如果存在则返回旧值，将 [`Some`] 保留在其位置，而不用对其中一个进行初始化。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub const fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// 如果选项是包含给定值的 [`Some`] 值，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    pub const fn contains<U>(&self, x: &U) -> bool
    where
        U: ~const PartialEq<T>,
    {
        match self {
            Some(y) => x.eq(y),
            None => false,
        }
    }

    /// 用另一个 `Option` 压缩 `self`。
    ///
    /// 如果 `self` 是 `Some(s)`，而 `other` 是 `Some(o)`，则此方法返回 `Some((s, o))`。
    /// 否则，返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn zip<U>(self, other: Option<U>) -> Option<(T, U)>
    where
        T: ~const Drop + ~const Destruct,
        U: ~const Drop + ~const Destruct,
    {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// 使用函数 `f` 压缩 `self` 和另一个 `Option`。
    ///
    /// 如果 `self` 是 `Some(s)`，而 `other` 是 `Some(o)`，则此方法返回 `Some(f(s, o))`。
    /// 否则，返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
    pub const fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: ~const FnOnce(T, U) -> R,
        F: ~const Drop + ~const Destruct,
        T: ~const Drop + ~const Destruct,
        U: ~const Drop + ~const Destruct,
    {
        match (self, other) {
            (Some(a), Some(b)) => Some(f(a, b)),
            _ => None,
        }
    }
}

impl<T, U> Option<(T, U)> {
    /// 解压缩包含两个选项的元组的选项。
    ///
    /// 如果 `self` 是 `Some((a, b))`，则此方法返回 `(Some(a), Some(b))`。
    /// 否则，返回 `(None, None)`。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(unzip_option)]
    ///
    /// let x = Some((1, "hi"));
    /// let y = None::<(u8, u32)>;
    ///
    /// assert_eq!(x.unzip(), (Some(1), Some("hi")));
    /// assert_eq!(y.unzip(), (None, None));
    /// ```
    #[inline]
    #[unstable(feature = "unzip_option", issue = "87800", reason = "recently added")]
    pub const fn unzip(self) -> (Option<T>, Option<U>) {
        match self {
            Some((a, b)) => (Some(a), Some(b)),
            None => (None, None),
        }
    }
}

impl<T> Option<&T> {
    /// 通过复制选项的内容将 `Option<&T>` 的 Maps 转换为 `Option<T>`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "copied", since = "1.35.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn copied(self) -> Option<T>
    where
        T: Copy,
    {
        // FIXME: 此实现避开使用 `Option::map`，因为它尚未准备好常量，应尽可能还原以避免代码重复
        //
        match self {
            Some(&v) => Some(v),
            None => None,
        }
    }

    /// 通过克隆选项的内容将 `Option<&T>` Maps 转换为 `Option<T>`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option_cloned", issue = "91582")]
    pub const fn cloned(self) -> Option<T>
    where
        T: ~const Clone,
    {
        match self {
            Some(t) => Some(t.clone()),
            None => None,
        }
    }
}

impl<T> Option<&mut T> {
    /// 通过复制选项的内容将 `Option<&mut T>` 的 Maps 转换为 `Option<T>`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "copied", since = "1.35.0")]
    #[rustc_const_unstable(feature = "const_option_ext", issue = "91930")]
    pub const fn copied(self) -> Option<T>
    where
        T: Copy,
    {
        match self {
            Some(&mut t) => Some(t),
            None => None,
        }
    }

    /// 通过克隆选项的内容将 `Option<&mut T>` Maps 转换为 `Option<T>`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    #[rustc_const_unstable(feature = "const_option_cloned", issue = "91582")]
    pub const fn cloned(self) -> Option<T>
    where
        T: ~const Clone,
    {
        match self {
            Some(t) => Some(t.clone()),
            None => None,
        }
    }
}

impl<T, E> Option<Result<T, E>> {
    /// 将 [`Result`] 的 `Option` 转换为 `Option` 的 [`Result`]。
    ///
    /// [`None`] 将映射到 <code>[Ok]\([None])</code>。
    /// <code>[Some]\([Ok]\(\_))</code> 和 <code>[Some]\([Err]\(\_))</code> 将映射到 <code>[Ok]\([Some]\(\_))</code> 和 <code>[Err]\(\_)</code>。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// 这是一个单独的函数，可以减少 .expect() 本身的代码大小。
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[cold]
#[track_caller]
#[rustc_const_unstable(feature = "const_option", issue = "67441")]
const fn expect_failed(msg: &str) -> ! {
    panic_str(msg)
}

/////////////////////////////////////////////////////////////////////////////
// trait 实现
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_clone", issue = "91805")]
#[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME 当碰撞时移除 `~const Drop` 和这个属性
impl<T> const Clone for Option<T>
where
    T: ~const Clone + ~const Drop + ~const Destruct,
{
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_default_impls", issue = "87864")]
impl<T> const Default for Option<T> {
    /// 返回 [`None`][Option::None]。
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// 返回可能包含的值上的消耗迭代器。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T> const From<T> for Option<T> {
    /// 将 `val` 移动到新的 [`Some`] 中。
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<'a, T> const From<&'a Option<T>> for Option<&'a T> {
    /// 从 `&Option<T>` 转换为 `Option<&T>`。
    ///
    /// # Examples
    ///
    /// 将 <code>[Option]<[String]></code> 转换为 <code>[Option]<[usize]></code>，保留原始值。
    /// [`map`] 方法按值取 `self` 参数，消耗原始值，因此该技术使用 `from` 首先将 [`Option`] 用于对原始值内部值的引用。
    ///
    ///
    /// [`map`]: Option::map
    /// [String]: ../../std/string/struct.String.html "String"
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {s:?}");
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<'a, T> const From<&'a mut Option<T>> for Option<&'a mut T> {
    /// 从 `&mut Option<T>` 转换为 `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Option 迭代器
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// 对 [`Option`] 的 [`Some`] 变体的引用的迭代器。
///
/// 如果 [`Option`] 为 [`Some`]，则迭代器产生一个值，否则为 0。
///
/// 该 `struct` 由 [`Option::iter`] 函数创建。
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// 对 [`Option`] 的 [`Some`] 变体的可变引用的迭代器。
///
/// 如果 [`Option`] 为 [`Some`]，则迭代器产生一个值，否则为 0。
///
/// 该 `struct` 由 [`Option::iter_mut`] 函数创建。
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// 对 [`Option`] 的 [`Some`] 变体中的值的迭代器。
///
/// 如果 [`Option`] 为 [`Some`]，则迭代器产生一个值，否则为 0。
///
/// 该 `struct` 由 [`Option::into_iter`] 函数创建。
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// 接受 [`Iterator`] 中的每个元素：如果为 [`None`][Option::None]，则不再获取其他元素，并返回 [`None`][Option::None]。
    /// 如果没有出现 [`None`][Option::None]，则返回一个 `V` 类型的容器，其中包含每个 [`Option`] 的值。
    ///
    /// # Examples
    ///
    /// 这是一个使 vector 中的每个整数递增的示例。
    /// 当计算将导致溢出时，我们使用 `add` 的检查变体返回 `None`。
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// 如您所见，这将返回预期的有效项。
    ///
    /// 这是另一个示例，尝试从另一个整数列表中减去一个，这次检查下溢：
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// 由于最后一个元素为零，因此会下溢。因此，结果值为 `None`。
    ///
    /// 这是前一个示例的变体，显示在第一个 `None` 之后不再从 `iter` 提取其他元素。
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// 由于第三个元素引起下溢，因此不再使用其他元素，因此 `shared` 的最终值为 6 (= `3 + 2 + 1`)，而不是 16。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): 当此性能错误关闭时，这可以替换为 Iterator::scan。
        //

        iter::try_process(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait_v2", issue = "84277")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T> const ops::Try for Option<T> {
    type Output = T;
    type Residual = Option<convert::Infallible>;

    #[inline]
    fn from_output(output: Self::Output) -> Self {
        Some(output)
    }

    #[inline]
    fn branch(self) -> ControlFlow<Self::Residual, Self::Output> {
        match self {
            Some(v) => ControlFlow::Continue(v),
            None => ControlFlow::Break(None),
        }
    }
}

#[unstable(feature = "try_trait_v2", issue = "84277")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T> const ops::FromResidual for Option<T> {
    #[inline]
    fn from_residual(residual: Option<convert::Infallible>) -> Self {
        match residual {
            None => None,
        }
    }
}

#[unstable(feature = "try_trait_v2_residual", issue = "91285")]
impl<T> ops::Residual<T> for Option<convert::Infallible> {
    type TryType = Option<T>;
}

impl<T> Option<Option<T>> {
    /// 从 `Option<Option<T>>` 转换为 `Option<T>`。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// 展平一次只能删除一层嵌套：
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}
