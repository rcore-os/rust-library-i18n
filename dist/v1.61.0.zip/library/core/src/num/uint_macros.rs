macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ident, $SignedT:ident, $NonZeroT:ident,
        $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// 此整数类型可以表示的最小值。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// 此整数类型可以表示的最大值，
        #[doc = concat!("2<sup>", $BITS, "</sup> &minus; 1.")]
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// 此整数类型的大小 (以位为单位)。
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "int_bits_const", since = "1.53.0")]
        pub const BITS: u32 = $BITS;

        /// 将给定基数的字符串切片转换为整数。
        ///
        /// 该字符串应为可选的 `+` 符号，后跟数字。
        ///
        /// 前导和尾随空格表示错误。
        /// 根据 `radix`，数字是这些字符的子集：
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// 如果 `radix` 不在 2 到 36 之间，则此函数 panics。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// 返回 `self` 二进制表示形式中的位数。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        ///
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// 返回 `self` 二进制表示形式中的零数。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// 返回 `self` 二进制表示形式中前导零的数目。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        ///
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// 返回 `self` 二进制表示形式中的尾随零数。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        ///
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// 返回 `self` 二进制表示形式中前导数字。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        ///
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// 返回 `self` 二进制表示形式中的尾随数字。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        ///
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// 将位左移指定的量 `n`，将截断的位包装到结果整数的末尾。
        ///
        ///
        /// 请注意，此操作与 `<<` 移位运算符不同！
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]
        ///
        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// 将位右移指定的量 `n`，将截断的位包装到结果整数的开头。
        ///
        ///
        /// 请注意，此操作与 `>>` 移位运算符不同！
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]
        ///
        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// 反转整数的字节顺序。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// let m = n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// 反转整数中的位顺序。
        /// 最低有效位变为最高有效位，第二最低有效位变为第二最高有效位，依此类推。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// let m = n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "reverse_bits", since = "1.37.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// 将整数从大端字节序转换为目标的字节序。
        ///
        /// 在大端节序序上，这是个禁忌。
        /// 在小端字节序上，字节被交换。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        ///
        /// if cfg!(target_endian = "big") {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use]
        #[inline(always)]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// 将整数从小端字节序转换为目标的字节序。
        ///
        /// 在小端字节序上，这是个禁忌。
        /// 在大字节序中，字节被交换。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        ///
        /// if cfg!(target_endian = "little") {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use]
        #[inline(always)]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// 将 `self` 从目标的字节序转换为大字节序。
        ///
        /// 在大端节序序上，这是个禁忌。
        /// 在小端字节序上，字节被交换。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        ///
        /// if cfg!(target_endian = "big") {
        ///     assert_eq!(n.to_be(), n)
        /// } else {
        ///     assert_eq!(n.to_be(), n.swap_bytes())
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn to_be(self) -> Self { // 还是不是？
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// 将 `self` 从目标的字节序转换为 Little Endian。
        ///
        /// 在小端字节序上，这是个禁忌。
        /// 在大字节序中，字节被交换。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        ///
        /// if cfg!(target_endian = "little") {
        ///     assert_eq!(n.to_le(), n)
        /// } else {
        ///     assert_eq!(n.to_le(), n.swap_bytes())
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// 检查整数加法。
        /// 计算 `self + rhs`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未经检查的整数加法。
        /// 假设不会发生溢出，则计算 `self + rhs`。
        ///
        /// # Safety
        ///
        /// 当以下情况时，这导致未定义的行为
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`,")]
        /// 即当 [`checked_add`] 将返回 `None` 时。
        ///
        #[doc = concat!("[`checked_add`]: ", stringify!($SelfT), "::checked_add")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "85122",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_unstable(feature = "const_inherent_unchecked_arith", issue = "85122")]
        #[inline(always)]
        pub const unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SAFETY: 调用者必须遵守 `unchecked_add` 的安全保证。
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// 用有符号整数检查加法。
        /// 计算 `self + rhs`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// # #![feature(mixed_integer_ops)]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_add_signed(2), Some(3));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_add_signed(-2), None);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add_signed(3), None);")]
        /// ```
        #[unstable(feature = "mixed_integer_ops", issue = "87840")]
        #[rustc_const_unstable(feature = "mixed_integer_ops", issue = "87840")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add_signed(self, rhs: $SignedT) -> Option<Self> {
            let (a, b) = self.overflowing_add_signed(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 检查整数减法。
        /// 计算 `self - rhs`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未经检查的整数减法。
        /// 假设不会发生溢出，则计算 `self - rhs`。
        ///
        /// # Safety
        ///
        /// 当以下情况时，这导致未定义的行为
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`,")]
        /// 即当 [`checked_sub`] 将返回 `None` 时。
        ///
        #[doc = concat!("[`checked_sub`]: ", stringify!($SelfT), "::checked_sub")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "85122",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_unstable(feature = "const_inherent_unchecked_arith", issue = "85122")]
        #[inline(always)]
        pub const unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SAFETY: 调用者必须遵守 `unchecked_sub` 的安全保证。
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// 检查整数乘法。
        /// 计算 `self * rhs`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未经检查的整数乘法。
        /// 假设不会发生溢出，则计算 `self * rhs`。
        ///
        /// # Safety
        ///
        /// 当以下情况时，这导致未定义的行为
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`,")]
        /// 即当 [`checked_mul`] 将返回 `None` 时。
        ///
        #[doc = concat!("[`checked_mul`]: ", stringify!($SelfT), "::checked_mul")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "85122",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_unstable(feature = "const_inherent_unchecked_arith", issue = "85122")]
        #[inline(always)]
        pub const unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SAFETY: 调用者必须遵守 `unchecked_mul` 的安全保证。
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// 检查整数除法。
        /// 计算 `self / rhs`，如果为 `rhs == 0`，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_div", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: 上面已经检查了 div 除以零的情况，并且无符号类型没有其他可用于除法的故障模式
                //
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// 检查欧几里得除法。
        /// 计算 `self.div_euclid(rhs)`，如果为 `rhs == 0`，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// 检查整数余数。
        /// 计算 `self % rhs`，如果为 `rhs == 0`，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_div", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: 上面已经检查了 div 除以零的情况，并且无符号类型没有其他可用于除法的故障模式
                //
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// 检查欧几里德模数。
        /// 计算 `self.rem_euclid(rhs)`，如果为 `rhs == 0`，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// 返回数字相对于任意底数的对数，向下取整。
        ///
        /// 由于实现细节，此方法可能未优化；
        /// `log2` 可以更有效地生成基数 2 的结果，而 `log10` 可以更有效地生成基数 10 的结果。
        ///
        ///
        /// # Panics
        ///
        /// 当数字为负数时，为零，或者基数不至少为 2；
        /// 它在调试模式下为 panics，在生产模式下返回值为 0。
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_log)]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".log(5), 1);")]
        /// ```
        ///
        #[unstable(feature = "int_log", issue = "70887")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[track_caller]
        #[rustc_inherit_overflow_checks]
        #[allow(arithmetic_overflow)]
        pub const fn log(self, base: Self) -> u32 {
            match self.checked_log(base) {
                Some(n) => n,
                None => {
                    // 在调试版本中，在 None 上触发 panic。
                    // 这应该在发行版本中完全优化。
                    let _ = Self::MAX + 1;

                    0
                },
            }
        }

        /// 返回数字的以 2 为底的对数，向下取整。
        ///
        /// # Panics
        ///
        /// 当数字为负数或零时，它在调试模式下为 panics，在生产模式下的返回值为 0。
        ///
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_log)]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".log2(), 1);")]
        /// ```
        #[unstable(feature = "int_log", issue = "70887")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[track_caller]
        #[rustc_inherit_overflow_checks]
        #[allow(arithmetic_overflow)]
        pub const fn log2(self) -> u32 {
            match self.checked_log2() {
                Some(n) => n,
                None => {
                    // 在调试版本中，在 None 上触发 panic。
                    // 这应该在发行版本中完全优化。
                    let _ = Self::MAX + 1;

                    0
                },
            }
        }

        /// 返回数字的以 10 为底的对数，向下取整。
        ///
        /// # Panics
        ///
        /// 当数字为负数或零时，它在调试模式下为 panics，在生产模式下的返回值为 0。
        ///
        ///
        /// # Example
        ///
        /// ```
        /// #![feature(int_log)]
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".log10(), 1);")]
        /// ```
        #[unstable(feature = "int_log", issue = "70887")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[track_caller]
        #[rustc_inherit_overflow_checks]
        #[allow(arithmetic_overflow)]
        pub const fn log10(self) -> u32 {
            match self.checked_log10() {
                Some(n) => n,
                None => {
                    // 在调试版本中，在 None 上触发 panic。
                    // 这应该在发行版本中完全优化。
                    let _ = Self::MAX + 1;

                    0
                },
            }
        }

        /// 返回数字相对于任意底数的对数，向下取整。
        ///
        /// 如果数字为零，或者基数不至少为 2，则返回 `None`。
        ///
        /// 由于实现细节，此方法可能未优化；
        /// `checked_log2` 可以更有效地生成基数 2 的结果，而 `checked_log10` 可以更有效地生成基数 10 的结果。
        ///
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_log)]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_log(5), Some(1));")]
        /// ```
        ///
        #[unstable(feature = "int_log", issue = "70887")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_log(self, base: Self) -> Option<u32> {
            if self <= 0 || base <= 1 {
                None
            } else {
                let mut n = 0;
                let mut r = self;

                // 128 位宽整数的优化。
                if Self::BITS == 128 {
                    let b = Self::log2(self) / (Self::log2(base) + 1);
                    n += b;
                    r /= base.pow(b as u32);
                }

                while r >= base {
                    r /= base;
                    n += 1;
                }
                Some(n)
            }
        }

        /// 返回数字的以 2 为底的对数，向下取整。
        ///
        /// 如果数字为零，则返回 `None`。
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_log)]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_log2(), Some(1));")]
        /// ```
        #[unstable(feature = "int_log", issue = "70887")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_log2(self) -> Option<u32> {
            if let Some(x) = <$NonZeroT>::new(self) {
                Some(x.log2())
            } else {
                None
            }
        }

        /// 返回数字的以 10 为底的对数，向下取整。
        ///
        /// 如果数字为零，则返回 `None`。
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_log)]
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".checked_log10(), Some(1));")]
        /// ```
        #[unstable(feature = "int_log", issue = "70887")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_log10(self) -> Option<u32> {
            if let Some(x) = <$NonZeroT>::new(self) {
                Some(x.log10())
            } else {
                None
            }
        }

        /// 检查否定。
        /// 计算 `-self`，除非 `self == 0`，否则返回 `None`。
        ///
        /// 请注意，取反任何正整数将溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 检查左移。
        /// 计算 `self << rhs`，如果 `rhs` 大于或等于 `self` 中的位数，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未检查的左移。
        /// 计算 `self << rhs`，假设 `rhs` 小于 `self` 中的位数。
        ///
        /// # Safety
        ///
        /// 如果 `rhs` 大于或等于 `self` 中的位数，则会导致未定义的行为，即
        ///
        /// 当 [`checked_shl`] 返回 `None` 时。
        ///
        #[doc = concat!("[`checked_shl`]: ", stringify!($SelfT), "::checked_shl")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "85122",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_unstable(feature = "const_inherent_unchecked_arith", issue = "85122")]
        #[inline(always)]
        pub const unsafe fn unchecked_shl(self, rhs: Self) -> Self {
            // SAFETY: 调用者必须遵守 `unchecked_shl` 的安全保证。
            //
            unsafe { intrinsics::unchecked_shl(self, rhs) }
        }

        /// 检查右移。
        /// 计算 `self >> rhs`，如果 `rhs` 大于或等于 `self` 中的位数，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未检查右移。
        /// 计算 `self >> rhs`，假设 `rhs` 小于 `self` 中的位数。
        ///
        /// # Safety
        ///
        /// 如果 `rhs` 大于或等于 `self` 中的位数，则会导致未定义的行为，即
        ///
        /// 当 [`checked_shr`] 返回 `None` 时。
        ///
        #[doc = concat!("[`checked_shr`]: ", stringify!($SelfT), "::checked_shr")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "85122",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_unstable(feature = "const_inherent_unchecked_arith", issue = "85122")]
        #[inline(always)]
        pub const unsafe fn unchecked_shr(self, rhs: Self) -> Self {
            // SAFETY: 调用者必须遵守 `unchecked_shr` 的安全保证。
            //
            unsafe { intrinsics::unchecked_shr(self, rhs) }
        }

        /// 检查取幂。
        /// 计算 `self.pow(exp)`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // 由于 `exp != 0`，最终 exp 必须为 1。
            // 分开处理指数的最后一位，因为在此之后对底数进行平方是不必要的，并且可能导致不必要的溢出。
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// 饱和整数加法。
        /// 计算 `self + rhs`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline(always)]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// 带符号整数的饱和加法。
        /// 计算 `self + rhs`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// # #![feature(mixed_integer_ops)]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".saturating_add_signed(2), 3);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".saturating_add_signed(-2), 0);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).saturating_add_signed(4), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[unstable(feature = "mixed_integer_ops", issue = "87840")]
        #[rustc_const_unstable(feature = "mixed_integer_ops", issue = "87840")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add_signed(self, rhs: $SignedT) -> Self {
            let (res, overflow) = self.overflowing_add(rhs as Self);
            if overflow == (rhs < 0) {
                res
            } else if overflow {
                Self::MAX
            } else {
                0
            }
        }

        /// 饱和整数减法。
        /// 计算 `self - rhs`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline(always)]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// 饱和整数乘法。
        /// 计算 `self * rhs`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// 饱和整数除法。
        /// 计算 `self / rhs`，在数值边界处饱和而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".saturating_div(2), 2);")]
        ///
        /// ```
        ///
        /// ```should_panic
        #[doc = concat!("let _ = 1", stringify!($SelfT), ".saturating_div(0);")]
        ///
        /// ```
        #[stable(feature = "saturating_div", since = "1.58.0")]
        #[rustc_const_stable(feature = "saturating_div", since = "1.58.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_div(self, rhs: Self) -> Self {
            // 在无符号类型上，整数除法没有溢出
            self.wrapping_div(rhs)
        }

        /// 饱和整数幂。
        /// 计算 `self.pow(exp)`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// 包装 (modular) 添加。
        /// 计算 `self + rhs`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// 用有符号整数包装 (modular) 加法。
        /// 计算 `self + rhs`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// # #![feature(mixed_integer_ops)]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_add_signed(2), 3);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_add_signed(-2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).wrapping_add_signed(4), 1);")]
        /// ```
        #[unstable(feature = "mixed_integer_ops", issue = "87840")]
        #[rustc_const_unstable(feature = "mixed_integer_ops", issue = "87840")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add_signed(self, rhs: $SignedT) -> Self {
            self.wrapping_add(rhs as Self)
        }

        /// 包装 (modular) 减法。
        /// 计算 `self - rhs`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// 包装 (modular) 乘法。
        /// 计算 `self * rhs`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// 请注意，此示例在整数类型之间共享。
        /// 这就解释了为什么在这里使用 `u8`。
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// 包装 (modular) 分区。计算 `self / rhs`。
        /// 无符号类型的包装除法只是普通除法。
        /// 包装是不可能发生的。
        /// 该函数存在，因此所有操作都在包装操作中考虑。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// 包装欧几里得除法。计算 `self.div_euclid(rhs)`。
        /// 无符号类型的包装除法只是普通除法。
        /// 包装是不可能发生的。
        /// 该函数存在，因此所有操作都在包装操作中考虑。
        /// 因为对于正整数，所有除法的通用定义都是相等的，所以它恰好等于 `self.wrapping_div(rhs)`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// 包装 (modular) 余数。计算 `self % rhs`。
        /// 无符号类型的包装余数计算只是常规余数计算。
        ///
        /// 包装是不可能发生的。
        /// 该函数存在，因此所有操作都在包装操作中考虑。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// 包装欧几里德模。计算 `self.rem_euclid(rhs)`。
        /// 无符号类型的包装模运算只是常规的余数计算。
        /// 包装是不可能发生的。
        /// 该函数存在，因此所有操作都在包装操作中考虑。
        /// 因为对于正整数，所有除法的通用定义都是相等的，所以它恰好等于 `self.wrapping_rem(rhs)`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        ///
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// 包装 (modular) 取反。
        /// 计算 `-self`，在类型的边界处回绕。
        ///
        /// 由于无符号类型没有负的等效项，因此该函数的所有应用程序都将自动换行 (`-0` 除外)。
        /// 对于小于相应有符号类型的最大值的值，结果与强制转换相应有符号值的结果相同。
        ///
        /// 任何较大的值都等于 `MAX + 1 - (val - MAX - 1)`，其中 `MAX` 是对应的有符号类型的最大值。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// 请注意，此示例在整数类型之间共享。
        /// 这就解释了为什么在这里使用 `i8`。
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_neg(self) -> Self {
            (0 as $SelfT).wrapping_sub(self)
        }

        /// 无 Panic - 按位左移；
        /// 产生 `self << mask(rhs)`，其中 `mask` 删除 `rhs` 的所有高位，这些高位将导致移位超过该类型的位宽。
        ///
        /// 注意，这与左旋不同； 环绕左移的 RHS 限于该类型的范围，而不是从 LHS 移出的位返回到另一端。
        /// 所有原始整数类型都实现了 [`rotate_left`](Self::rotate_left) 函数，而您可能想要的是 [`rotate_left`](Self::rotate_left) 函数。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SAFETY: 通过类型的位大小进行掩蔽可确保我们不会越界
            //
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// 无 Panic - 按位右移；
        /// 产生 `self >> mask(rhs)`，其中 `mask` 删除 `rhs` 的所有高位，这些高位将导致移位超过该类型的位宽。
        ///
        /// 注意，这与右旋转不同。换行右移的 RHS 限于类型的范围，而不是从 LHS 移出的位返回到另一端。
        /// 所有原始整数类型都实现了 [`rotate_right`](Self::rotate_right) 函数，而您可能想要的是 [`rotate_right`](Self::rotate_right) 函数。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SAFETY: 通过类型的位大小进行掩蔽可确保我们不会越界
            //
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// 包装 (modular) 指数。
        /// 计算 `self.pow(exp)`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // 由于 `exp != 0`，最终 exp 必须为 1。
            // 分开处理指数的最后一位，因为在此之后对底数进行平方是不必要的，并且可能导致不必要的溢出。
            //
            //
            acc.wrapping_mul(base)
        }

        /// 计算 `self` + `rhs`
        ///
        /// 返回一个加法元组以及一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回包装的值。
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// 计算 `self + rhs + carry` 没有溢出的能力。
        ///
        /// 执行 "三元加法"，它需要添加一个额外的位，并可能返回一个额外的溢出位。
        /// 这允许将多个添加链接在一起以创建代表更大值的 "大整数"。
        ///
        ///
        #[doc = concat!("This can be thought of as a ", stringify!($BITS), "-bit \"full adder\", in the electronics sense.")]
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        /// #![feature(bigint_helper_methods)]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".carrying_add(2, false), (7, false));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".carrying_add(2, true), (8, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.carrying_add(1, false), (0, true));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.carrying_add(0, true), (0, true));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.carrying_add(1, true), (1, true));")]
        #[doc = concat!("assert_eq!(",
            stringify!($SelfT), "::MAX.carrying_add(", stringify!($SelfT), "::MAX, true), ",
            "(", stringify!($SelfT), "::MAX, true));"
        )]
        /// ```
        ///
        /// If `carry` is false, this method is equivalent to [`overflowing_add`](Self::overflowing_add):
        ///
        /// ```
        /// #![feature(bigint_helper_methods)]
        #[doc = concat!("assert_eq!(5_", stringify!($SelfT), ".carrying_add(2, false), 5_", stringify!($SelfT), ".overflowing_add(2));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.carrying_add(1, false), ", stringify!($SelfT), "::MAX.overflowing_add(1));")]
        /// ```
        #[unstable(feature = "bigint_helper_methods", issue = "85532")]
        #[rustc_const_unstable(feature = "const_bigint_helper_methods", issue = "85532")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn carrying_add(self, rhs: Self, carry: bool) -> (Self, bool) {
            // note: 从长远来看，这应该通过内部函数来完成，但目前已经证明这可以生成最佳代码，并且 LLVM 没有等效的内部函数
            //
            let (a, b) = self.overflowing_add(rhs);
            let (c, d) = a.overflowing_add(carry as $SelfT);
            (c, b || d)
        }

        /// 使用带符号的 `rhs` 计算 `self` + `rhs`
        ///
        /// 返回一个加法元组以及一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回包装的值。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// # #![feature(mixed_integer_ops)]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".overflowing_add_signed(2), (3, false));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".overflowing_add_signed(-2), (", stringify!($SelfT), "::MAX, true));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).overflowing_add_signed(4), (1, true));")]
        /// ```
        ///
        #[unstable(feature = "mixed_integer_ops", issue = "87840")]
        #[rustc_const_unstable(feature = "mixed_integer_ops", issue = "87840")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add_signed(self, rhs: $SignedT) -> (Self, bool) {
            let (res, overflowed) = self.overflowing_add(rhs as Self);
            (res, overflowed ^ (rhs < 0))
        }

        /// 计算 `self`-`rhs`
        ///
        /// 返回一个减法的元组以及一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回包装的值。
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// 计算 `self - rhs - borrow` 没有溢出的能力。
        ///
        /// 执行 "三元减法"，它接受一个额外的位来减去，并且可能返回一个额外的溢出位。
        /// 这允许将多个减法链接在一起以创建代表更大值的 "大整数"。
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        /// #![feature(bigint_helper_methods)]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".borrowing_sub(2, false), (3, false));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".borrowing_sub(2, true), (2, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".borrowing_sub(1, false), (", stringify!($SelfT), "::MAX, true));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".borrowing_sub(1, true), (", stringify!($SelfT), "::MAX - 1, true));")]
        /// ```
        ///
        #[unstable(feature = "bigint_helper_methods", issue = "85532")]
        #[rustc_const_unstable(feature = "const_bigint_helper_methods", issue = "85532")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn borrowing_sub(self, rhs: Self, borrow: bool) -> (Self, bool) {
            // note: 从长远来看，这应该通过内部函数来完成，但目前已经证明这可以生成最佳代码，并且 LLVM 没有等效的内部函数
            //
            let (a, b) = self.overflowing_sub(rhs);
            let (c, d) = a.overflowing_sub(borrow as $SelfT);
            (c, b || d)
        }

        /// 计算 `self` 和 `other` 之间的绝对差。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".abs_diff(80), 20", stringify!($SelfT), ");")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".abs_diff(110), 10", stringify!($SelfT), ");")]
        /// ```
        #[stable(feature = "int_abs_diff", since = "1.60.0")]
        #[rustc_const_stable(feature = "int_abs_diff", since = "1.60.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn abs_diff(self, other: Self) -> Self {
            if mem::size_of::<Self>() == 1 {
                // 当 SSE2 可用时，诱使 LLVM 生成 psadbw 指令，并且此函数为 u8 自动向量化。
                //
                (self as i32).wrapping_sub(other as i32).abs() as Self
            } else {
                if self < other {
                    other - self
                } else {
                    self - other
                }
            }
        }

        /// 计算 `self` 和 `rhs` 的乘法。
        ///
        /// 返回乘法的元组以及一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回包装的值。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// 请注意，此示例在整数类型之间共享。
        /// 这就解释了为什么在这里使用 `u32`。
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline(always)]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` 除以 `rhs` 时计算除数。
        ///
        /// 返回除数的元组以及指示是否将发生算术溢出的布尔值。
        /// 请注意，对于无符号整数，永远不会发生溢出，因此第二个值始终为 `false`。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        ///
        ///
        #[inline(always)]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// 计算欧几里得除法 `self.div_euclid(rhs)` 的商。
        ///
        /// 返回除数的元组以及指示是否将发生算术溢出的布尔值。
        /// 请注意，对于无符号整数，永远不会发生溢出，因此第二个值始终为 `false`。
        /// 因为对于正整数，所有除法的通用定义都是相等的，所以它恰好等于 `self.overflowing_div(rhs)`。
        ///
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        ///
        ///
        ///
        #[inline(always)]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// `self` 除以 `rhs` 时计算余数。
        ///
        /// 返回除法运算后的余数元组和一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 请注意，对于无符号整数，永远不会发生溢出，因此第二个值始终为 `false`。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        ///
        ///
        #[inline(always)]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// 以欧几里得除法计算余数 `self.rem_euclid(rhs)`。
        ///
        /// 返回除以布尔后的模元，并返回一个布尔值，指示是否会发生算术溢出。
        /// 请注意，对于无符号整数，永远不会发生溢出，因此第二个值始终为 `false`。
        /// 由于对于正整数，所有除法的通用定义均相等，因此该运算恰好等于 `self.overflowing_rem(rhs)`。
        ///
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        ///
        ///
        ///
        #[inline(always)]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// 以一种泛滥的方式否定自我。
        ///
        /// 使用包装操作返回 `!self + 1`，以返回表示该无符号值的取反的值。
        /// 请注意，对于正的无符号值，总是会发生溢出，但取反 0 不会溢出。
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        ///
        ///
        #[inline(always)]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// 将 self 左移 `rhs` 位。
        ///
        /// 返回 self 的移位版本的元组以及一个布尔值，该布尔值指示 shift 值是否大于或等于位数。
        /// 如果移位值太大，则将值屏蔽 (N-1)，其中 N 是位数，然后使用该值执行移位。
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        ///
        ///
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// 将 self 右移 `rhs` 位。
        ///
        /// 返回 self 的移位版本的元组以及一个布尔值，该布尔值指示 shift 值是否大于或等于位数。
        /// 如果移位值太大，则将值屏蔽 (N-1)，其中 N 是位数，然后使用该值执行移位。
        ///
        /// # Examples
        ///
        /// 基本用法
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        ///
        ///
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// 通过平方运算，将自己提升到 `exp` 的功效。
        ///
        /// 返回一个指数的元组以及一个 bool，指示是否发生了溢出。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, true));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // 暂存空间，用于存储 overflowing_mul 的结果。
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // 由于 `exp != 0`，最终 exp 必须为 1。
            // 分开处理指数的最后一位，因为在此之后对底数进行平方是不必要的，并且可能导致不必要的溢出。
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// 通过平方运算，将自己提升到 `exp` 的功效。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // 由于 `exp != 0`，最终 exp 必须为 1。
            // 分开处理指数的最后一位，因为在此之后对底数进行平方是不必要的，并且可能导致不必要的溢出。
            //
            //
            acc * base
        }

        /// 执行欧几里得除法。
        ///
        /// 因为对于正整数，所有除法的通用定义都是相等的，所以它恰好等于 `self / rhs`。
        ///
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// 计算 `self (mod rhs)` 的最小余数。
        ///
        /// 因为对于正整数，所有除法的通用定义都是相等的，所以它恰好等于 `self % rhs`。
        ///
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// 计算 `self` 和 `rhs` 的商，将结果四舍五入到负无穷大。
        ///
        /// 这与对所有无符号整数执行 `self / rhs` 相同。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(int_roundings)]
        #[doc = concat!("assert_eq!(7_", stringify!($SelfT), ".div_floor(4), 1);")]
        /// ```
        #[unstable(feature = "int_roundings", issue = "88581")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        #[rustc_inherit_overflow_checks]
        pub const fn div_floor(self, rhs: Self) -> Self {
            self / rhs
        }

        /// 计算 `self` 和 `rhs` 的商，将结果四舍五入到正无穷大。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(int_roundings)]
        #[doc = concat!("assert_eq!(7_", stringify!($SelfT), ".div_ceil(4), 2);")]
        /// ```
        #[unstable(feature = "int_roundings", issue = "88581")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_ceil(self, rhs: Self) -> Self {
            let d = self / rhs;
            let r = self % rhs;
            if r > 0 && rhs > 0 {
                d + 1
            } else {
                d
            }
        }

        /// 计算大于或等于 `rhs` 倍数的 `self` 的最小值。
        ///
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0 或操作导致溢出，则此函数将 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(int_roundings)]
        #[doc = concat!("assert_eq!(16_", stringify!($SelfT), ".next_multiple_of(8), 16);")]
        #[doc = concat!("assert_eq!(23_", stringify!($SelfT), ".next_multiple_of(8), 24);")]
        /// ```
        #[unstable(feature = "int_roundings", issue = "88581")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_multiple_of(self, rhs: Self) -> Self {
            match self % rhs {
                0 => self,
                r => self + (rhs - r)
            }
        }

        /// 计算大于或等于 `rhs` 倍数的 `self` 的最小值。
        /// 如果 `rhs` 为零，则返回 `None`，否则操作将导致溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(int_roundings)]
        #[doc = concat!("assert_eq!(16_", stringify!($SelfT), ".checked_next_multiple_of(8), Some(16));")]
        #[doc = concat!("assert_eq!(23_", stringify!($SelfT), ".checked_next_multiple_of(8), Some(24));")]
        #[doc = concat!("assert_eq!(1_", stringify!($SelfT), ".checked_next_multiple_of(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_multiple_of(2), None);")]
        /// ```
        ///
        #[unstable(feature = "int_roundings", issue = "88581")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn checked_next_multiple_of(self, rhs: Self) -> Option<Self> {
            match try_opt!(self.checked_rem(rhs)) {
                0 => Some(self),
                // rhs - r 不能溢出，因为 r 小于 rhs
                r => self.checked_add(rhs - r)
            }
        }

        /// 当且仅当某些 `k` 的 `self == 2^k` 时，才返回 `true`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[must_use]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline(always)]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // 返回比下一个 2 的幂小 1 的值。
        // (对于 8u8，下一个 2 的幂为 8u8，对于 6u8 为 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() == 7
        // 6u8.one_less_than_next_power_of_two() == 7
        //
        // 此方法不能溢出，因为在 `next_power_of_two` 溢出情况下，它最终返回该类型的最大值，并且可以为 0 返回 0。
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SAFETY: 由于 `p > 0`，它不能完全由前导零组成。
            // 这意味着移位始终是边界内的，并且当参数为非零值时，某些处理器 (例如 intel pre-haswell) 具有更高效的 ctlz 内部函数。
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// 返回大于或等于 `self` 的 2 的最小幂。
        ///
        /// 当返回值溢出 (即 `uN` 类型为 `self > (1 << (N-1))`) 时，它在调试模式下为 panics，在生产模式下返回值被包装为 0 (方法可以返回 0 的唯一情况)。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// 返回大于或等于 `n` 的 2 的最小幂。
        /// 如果下一个 2 的幂大于该类型的最大值，则返回 `None`，否则将 2 的幂包装在 `Some` 中。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// 返回大于或等于 `n` 的 2 的最小幂。
        /// 如果下一个 2 的幂大于该类型的最大值，则返回值将包装为 `0`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[inline]
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_unstable(feature = "wrapping_next_power_of_two", issue = "32463")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// 以大端 (网络) 字节顺序将这个整数的内存表示形式作为字节数组返回。
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// 以小端字节顺序将这个整数的内存表示形式返回为字节数组。
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// 将此整数的内存表示作为本机字节顺序的字节数组返回。
        ///
        /// 由于使用了目标平台的原生字节序，因此，可移植代码应酌情使用 [`to_be_bytes`] 或 [`to_le_bytes`]。
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        ///
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes,
        ///     if cfg!(target_endian = "big") {
        #[doc = concat!("        ", $be_bytes)]
        ///     } else {
        #[doc = concat!("        ", $le_bytes)]
        ///     }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        // SAFETY: const 之所以听起来不错，是因为整数是普通的旧数据类型，因此我们始终可以将它们转换为字节数组
        //
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SAFETY: 整数是普通的旧数据类型，因此我们始终可以将它们转换为字节数组
            //
            unsafe { mem::transmute(self) }
        }

        /// 根据其表示形式 (大字节序中的字节数组) 创建一个本地字节序整数值。
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// 从切片而不是数组开始时，可以使用容易出错的转换 API：
        ///
        /// ```
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        ///     *input = rest;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// 从它的表示形式以 little endian 的字节数组创建一个本地 endian 整数值。
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// 从切片而不是数组开始时，可以使用容易出错的转换 API：
        ///
        /// ```
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        ///     *input = rest;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// 从其内存表示形式以原生字节序形式创建一个原生字节序整数值。
        ///
        /// 由于使用了目标平台的原生字节序，因此可移植代码可能希望酌情使用 [`from_be_bytes`] 或 [`from_le_bytes`]。
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } else {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// 从切片而不是数组开始时，可以使用容易出错的转换 API：
        ///
        /// ```
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        ///     *input = rest;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use]
        // SAFETY: const 之所以听起来不错，是因为整数是普通的旧数据类型，因此我们可以随时将其转换为整数
        //
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SAFETY: 整数是普通的旧数据类型，因此我们可以随时将其转换为整数
            unsafe { mem::transmute(bytes) }
        }

        /// 新代码应优先使用
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        ///
        /// 返回此整数类型可以表示的最小值。
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// 新代码应优先使用
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        ///
        /// 返回此整数类型可以表示的最大值。
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}
