//! 32 位带符号整数类型的常量。
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! 新代码应直接在原始类型上使用关联的常量。

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }
