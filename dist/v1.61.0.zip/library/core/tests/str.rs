// 所有 `str` 测试都在 liballoc/tests 中进行
