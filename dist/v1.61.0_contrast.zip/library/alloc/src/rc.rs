//! Single-threaded reference-counting pointers. <br>单线程引用计数指针。<br> 'Rc' stands for 'Reference Counted'. <br>`Rc` 代表引用计数。<br>
//!
//! The type [`Rc<T>`][`Rc`] provides shared ownership of a value of type `T`, allocated in the heap. <br>[`Rc<T>`][`Rc`] 类型提供了在堆中分配的 `T` 类型值的共享所有权。<br>
//! Invoking [`clone`][clone] on [`Rc`] produces a new pointer to the same allocation in the heap. <br>在 [`Rc`] 上调用 [`clone`][clone] 会产生一个指向堆中相同分配的新指针。<br>
//! When the last [`Rc`] pointer to a given allocation is destroyed, the value stored in that allocation (often referred to as "inner value") is also dropped. <br>当指向给定分配的最后一个 [`Rc`] 指针被销毁时，存储在该分配中的值 (通常称为 "内部值") 也将被丢弃。<br>
//!
//! Shared references in Rust disallow mutation by default, and [`Rc`] is no exception: you cannot generally obtain a mutable reference to something inside an [`Rc`]. <br>默认情况下，Rust 中的共享引用不允许可变，[`Rc`] 也不例外：您通常无法获得 [`Rc`] 内部内容的可变引用。<br>
//! If you need mutability, put a [`Cell`] or [`RefCell`] inside the [`Rc`]; <br>如果需要可变性，则将 [`Cell`] 或 [`RefCell`] 放在 [`Rc`] 内；<br> see [an example of mutability inside an `Rc`][mutability]. <br>请参见 [`Rc` 中的可变性示例][mutability]。<br>
//!
//! [`Rc`] uses non-atomic reference counting. <br>[`Rc`] 使用非原子引用计数。<br>
//! This means that overhead is very low, but an [`Rc`] cannot be sent between threads, and consequently [`Rc`] does not implement [`Send`][send]. <br>这意味着开销非常低，但是 [`Rc`] 无法在线程之间发送，因此 [`Rc`] 无法实现 [`Send`][send]。<br>
//! As a result, the Rust compiler will check *at compile time* that you are not sending [`Rc`]s between threads. <br>结果，Rust 编译器将检查 *at compile time* 您是否不在线程之间发送 [`Rc`]。<br>
//! If you need multi-threaded, atomic reference counting, use [`sync::Arc`][arc]. <br>如果需要多线程的原子引用计数，请使用 [`sync::Arc`][arc]。<br>
//!
//! The [`downgrade`][downgrade] method can be used to create a non-owning [`Weak`] pointer. <br>[`downgrade`][downgrade] 方法可用于创建非所有者 [`Weak`] 指针。<br>
//! A [`Weak`] pointer can be [`upgrade`][upgrade]d to an [`Rc`], but this will return [`None`] if the value stored in the allocation has already been dropped. <br>[`Weak`] 指针可以被 [`upgrade`][upgrade] 到 [`Rc`]，但是如果已经丢弃了分配中存储的值，则它将返回 [`None`]。<br>
//! In other words, `Weak` pointers do not keep the value inside the allocation alive; <br>换句话说，`Weak` 指针不会使分配内部的值保持活动状态。<br> however, they *do* keep the allocation (the backing store for the inner value) alive. <br>但是，它们确实使分配 (内部值的后备存储) 保持活动状态。<br>
//!
//! A cycle between [`Rc`] pointers will never be deallocated. <br>[`Rc`] 指针之间的循环将永远不会被释放。<br>
//! For this reason, [`Weak`] is used to break cycles. <br>因此，[`Weak`] 用于中断循环。<br>
//! For example, a tree could have strong [`Rc`] pointers from parent nodes to children, and [`Weak`] pointers from children back to their parents. <br>例如，一棵树可以具有从父节点到子节点的强 [`Rc`] 指针，以及从子节点到其父节点的 [`Weak`] 指针。<br>
//!
//! `Rc<T>` automatically dereferences to `T` (via the [`Deref`] trait), so you can call `T`'s methods on a value of type [`Rc<T>`][`Rc`]. <br>`Rc<T>` 自动取消对 `T` 的引用 (通过 [`Deref`] trait)，因此您可以在类型为 [`Rc<T>`][`Rc`] 的值上调用 `T` 的方法。<br>
//! To avoid name clashes with `T`'s methods, the methods of [`Rc<T>`][`Rc`] itself are associated functions, called using [fully qualified syntax]: <br>为了避免与 T 方法的名称冲突，[`Rc<T>`][`Rc`] 本身的方法是关联函数，使用 [完全限定语法][fully qualified syntax] 进行调用：<br>
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! let my_weak = Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>`'s implementations of traits like `Clone` may also be called using fully qualified syntax. <br>`RC<T> 也可以使用完全限定语法来调用 traits 的 `Clone` 等实现。<br>
//! Some people prefer to use fully qualified syntax, while others prefer using method-call syntax. <br>有些人喜欢使用完全限定的语法，而另一些人则喜欢使用方法调用语法。<br>
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Method-call syntax <br>方法调用语法<br>
//! let rc2 = rc.clone();
//! // Fully qualified syntax <br>完全限定的语法<br>
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] does not auto-dereference to `T`, because the inner value may have already been dropped. <br>[`Weak<T>`][`Weak`] 不会自动解引用到 `T`，因为内部值可能已经被丢弃了。<br>
//!
//! # Cloning references <br>克隆引用<br>
//!
//! Creating a new reference to the same allocation as an existing reference counted pointer is done using the `Clone` trait implemented for [`Rc<T>`][`Rc`] and [`Weak<T>`][`Weak`]. <br>使用为 [`Rc<T>`][`Rc`] 和 [`Weak<T>`][`Weak`] 实现的 `Clone` trait，可以创建与现有引用计数指针相同分配的新引用。<br>
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // The two syntaxes below are equivalent. <br>以下两种语法是等效的。<br>
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a and b both point to the same memory location as foo. <br>a 和 b 都指向与 foo 相同的内存位置。<br>
//! ```
//!
//! The `Rc::clone(&from)` syntax is the most idiomatic because it conveys more explicitly the meaning of the code. <br>`Rc::clone(&from)` 语法是最常见的语法，因为它更明确地传达了代码的含义。<br>
//! In the example above, this syntax makes it easier to see that this code is creating a new reference rather than copying the whole content of foo. <br>在上面的示例中，使用此语法可以更轻松地看到此代码正在创建新的引用，而不是复制 foo 的全部内容。<br>
//!
//! # Examples
//!
//! Consider a scenario where a set of `Gadget`s are owned by a given `Owner`. <br>考虑一个场景，其中给定的 `Owner` 拥有一组 `Gadget`。<br>
//! We want to have our `Gadget`s point to their `Owner`. <br>我们想让我们的 `Gadget` 指向他们的 `Owner`。<br> We can't do this with unique ownership, because more than one gadget may belong to the same `Owner`. <br>我们不能用唯一的所有权来做到这一点，因为一个以上的 gadget 可能属于同一个 `Owner`。<br>
//! [`Rc`] allows us to share an `Owner` between multiple `Gadget`s, and have the `Owner` remain allocated as long as any `Gadget` points at it. <br>[`Rc`] 允许我们在多个 `Gadget` 之间共享一个 `Owner`，并且只要有任何 `Gadget` 指向它，`Owner` 就会保持分配状态。<br>
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ...other fields <br>... 其他字段<br>
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ...other fields <br>... 其他字段<br>
//! }
//!
//! fn main() {
//!     // Create a reference-counted `Owner`. <br>创建一个引用计数的 `Owner`。<br>
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Create `Gadget`s belonging to `gadget_owner`. <br>创建属于 `gadget_owner` 的 `Gadget`。<br>
//!     // Cloning the `Rc<Owner>` gives us a new pointer to the same `Owner` allocation, incrementing the reference count in the process. <br>克隆 `Rc<Owner>` 为我们提供了指向同一个 `Owner` 分配的新指针，从而增加了该进程中的引用计数。<br>
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Dispose of our local variable `gadget_owner`. <br>处理我们的局部变量 `gadget_owner`。<br>
//!     drop(gadget_owner);
//!
//!     // Despite dropping `gadget_owner`, we're still able to print out the name of the `Owner` of the `Gadget`s. <br>尽管丢弃了 `gadget_owner`，我们仍然可以打印出 `Gadget` 的 `Owner` 的名称。<br>
//!     // This is because we've only dropped a single `Rc<Owner>`, not the `Owner` it points to. <br>这是因为我们只删除了一个 `Rc<Owner>`，而不是它指向的 `Owner`。<br>
//!     // As long as there are other `Rc<Owner>` pointing at the same `Owner` allocation, it will remain live. <br>只要还有其他 `Rc<Owner>` 指向相同的 `Owner` 分配，它将保持活动状态。<br>
//!     // The field projection `gadget1.owner.name` works because `Rc<Owner>` automatically dereferences to `Owner`. <br>字段投影 `gadget1.owner.name` 之所以起作用，是因为 `Rc<Owner>` 自动取消了对 `Owner` 的引用。<br>
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // At the end of the function, `gadget1` and `gadget2` are destroyed, and with them the last counted references to our `Owner`. <br>在该函数的末尾，`gadget1` 和 `gadget2` 被销毁，并且它们与我们的 `Owner` 一起被算作最后引用。<br>
//!     // Gadget Man now gets destroyed as well. <br>`Gadget` 现在也被摧毁。<br>
//!     //
//! }
//! ```
//!
//! If our requirements change, and we also need to be able to traverse from `Owner` to `Gadget`, we will run into problems. <br>如果我们的要求发生变化，并且还需要能够从 `Owner` 遍历到 `Gadget`，我们将遇到问题。<br>
//! An [`Rc`] pointer from `Owner` to `Gadget` introduces a cycle. <br>从 `Owner` 到 `Gadget` 的 [`Rc`] 指针引入了一个循环。<br>
//! This means that their reference counts can never reach 0, and the allocation will never be destroyed: <br>这意味着它们的引用计数永远不会达到 0，并且分配也永远不会被销毁：<br>
//! a memory leak. <br>内存泄漏。<br> In order to get around this, we can use [`Weak`] pointers. <br>为了解决这个问题，我们可以使用 [`Weak`] 指针。<br>
//!
//! Rust actually makes it somewhat difficult to produce this loop in the first place. <br>实际上，Rust 使得在某种程度上很难产生此循环。<br> In order to end up with two values that point at each other, one of them needs to be mutable. <br>为了最终得到两个指向彼此的值，其中之一必须是可变的。<br>
//! This is difficult because [`Rc`] enforces memory safety by only giving out shared references to the value it wraps, and these don't allow direct mutation. <br>这很困难，因为 [`Rc`] 仅通过对其包装的值给出共享的引用来强制执行内存安全性，而这些不允许直接更改。<br>
//! We need to wrap the part of the value we wish to mutate in a [`RefCell`], which provides *interior mutability*: a method to achieve mutability through a shared reference. <br>我们需要将希望可变的的部分值包装在 [`RefCell`] 中，该值提供 *interior 可变性*: 一种通过共享引用实现可变性的方法。<br>
//! [`RefCell`] enforces Rust's borrowing rules at runtime. <br>[`RefCell`] 在运行时强制执行 Rust 的借用规则。<br>
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ...other fields <br>... 其他字段<br>
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ...other fields <br>... 其他字段<br>
//! }
//!
//! fn main() {
//!     // Create a reference-counted `Owner`. <br>创建一个引用计数的 `Owner`。<br>
//!     // Note that we've put the `Owner`'s vector of `Gadget`s inside a `RefCell` so that we can mutate it through a shared reference. <br>请注意，我们已将 `Gadget` 的所有者的 vector 放在 `RefCell` 内，以便我们可以通过共享的引用对其进行可变。<br>
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Create `Gadget`s belonging to `gadget_owner`, as before. <br>如前所述，创建属于 `gadget_owner` 的 `Gadget`。<br>
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Add the `Gadget`s to their `Owner`. <br>将 `Gadget` 添加到其 `Owner` 中。<br>
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dynamic borrow ends here. <br>`RefCell` 动态借用到此结束。<br>
//!     }
//!
//!     // Iterate over our `Gadget`s, printing their details out. <br>遍历我们的 `Gadget`，将其详细信息打印出来。<br>
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` is a `Weak<Gadget>`. <br>`gadget_weak` 是一个 `Weak<Gadget>`。<br>
//!         // Since `Weak` pointers can't guarantee the allocation still exists, we need to call `upgrade`, which returns an `Option<Rc<Gadget>>`. <br>由于 `Weak` 指针不能保证分配仍然存在，因此我们需要调用 `upgrade`，它返回 `Option<Rc<Gadget>>`。<br>
//!         //
//!         //
//!         // In this case we know the allocation still exists, so we simply `unwrap` the `Option`. <br>在这种情况下，我们知道分配仍然存在，因此我们只用 `unwrap` 和 `Option`。<br>
//!         // In a more complicated program, you might need graceful error handling for a `None` result. <br>在更复杂的程序中，可能需要适当的错误处理才能获得 `None` 结果。<br>
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // At the end of the function, `gadget_owner`, `gadget1`, and `gadget2` are destroyed. <br>在该函数的末尾，`gadget_owner`，`gadget1` 和 `gadget2` 被销毁。<br>
//!     // There are now no strong (`Rc`) pointers to the gadgets, so they are destroyed. <br>现在没有指向该 `Gadget` 的强大 (`Rc`) 指针，因此它们已被销毁。<br>
//!     // This zeroes the reference count on Gadget Man, so he gets destroyed as well. <br>这会使 Gadget Man 的引用计数为零，因此他也被销毁了。<br>
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
#[cfg(not(no_global_oom_handling))]
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
#[cfg(not(no_global_oom_handling))]
use core::mem::size_of_val;
use core::mem::{self, align_of_val_raw, forget};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::panic::{RefUnwindSafe, UnwindSafe};
#[cfg(not(no_global_oom_handling))]
use core::pin::Pin;
use core::ptr::{self, NonNull};
#[cfg(not(no_global_oom_handling))]
use core::slice::from_raw_parts_mut;

#[cfg(not(no_global_oom_handling))]
use crate::alloc::handle_alloc_error;
#[cfg(not(no_global_oom_handling))]
use crate::alloc::{box_free, WriteCloneIntoRaw};
use crate::alloc::{AllocError, Allocator, Global, Layout};
use crate::borrow::{Cow, ToOwned};
#[cfg(not(no_global_oom_handling))]
use crate::string::String;
#[cfg(not(no_global_oom_handling))]
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// This is repr(C) to future-proof against possible field-reordering, which would interfere with otherwise safe [into|from]_raw() of transmutable inner types. <br>这是 repr(C) 为了防止未来可能的字段重新排序，否则可能会干扰可安全转换的内部类型的 _raw () 的安全性。<br>
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// A single-threaded reference-counting pointer. <br>单线程引用计数指针。<br> 'Rc' stands for 'Reference Counted'. <br>`Rc` 代表引用计数。<br>
///
/// See the [module-level documentation](./index.html) for more details. <br>有关更多详细信息，请参见 [模块级文档](./index.html)。<br>
///
/// The inherent methods of `Rc` are all associated functions, which means that you have to call them as e.g., [`Rc::get_mut(&mut value)`][get_mut] instead of `value.get_mut()`. <br>`Rc` 的固有方法都是关联函数，这意味着您必须以例如 [`Rc::get_mut(&mut value)`][get_mut] 而不是 `value.get_mut()` 的方式调用它们。<br>
/// This avoids conflicts with methods of the inner type `T`. <br>这样可以避免与内部类型 `T` 的方法发生冲突。<br>
///
/// [get_mut]: Rc::get_mut
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_insignificant_dtor]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}

// Note that this negative impl isn't strictly necessary for correctness, as `Rc` transitively contains a `Cell`, which is itself `!Sync`. <br>请注意，这个 negative impl 对于正确性来说并不是严格必要的，因为 `Rc` 传递地包含一个 `Cell`，它本身就是 `!Sync`。<br>
// However, given how important `Rc`'s `!Sync`-ness is, having an explicit negative impl is nice for documentation purposes and results in nicer error messages. <br>然而，考虑到 `Rc` 的 `!Sync` 特性的重要性，有一个显式的 negative impl 对于文档来说是很好的，并且会产生更好的错误消息。<br>
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[stable(feature = "catch_unwind", since = "1.9.0")]
impl<T: RefUnwindSafe + ?Sized> UnwindSafe for Rc<T> {}
#[stable(feature = "rc_ref_unwind_safe", since = "1.58.0")]
impl<T: RefUnwindSafe + ?Sized> RefUnwindSafe for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // This unsafety is ok because while this Rc is alive we're guaranteed that the inner pointer is valid. <br>这种不安全性是可以的，因为在此 Rc 处于活动状态时，我们保证内部指针有效。<br>
        //
        unsafe { self.ptr.as_ref() }
    }

    unsafe fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

impl<T> Rc<T> {
    /// Constructs a new `Rc<T>`. <br>创建一个新的 `Rc<T>`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // There is an implicit weak pointer owned by all the strong pointers, which ensures that the weak destructor never frees the allocation while the strong destructor is running, even if the weak pointer is stored inside the strong one. <br>所有强指针都拥有一个隐式的弱指针，以确保即使强指针中存储了弱指针，弱析构函数也不会在强析构函数运行时释放分配。<br>
        //
        //
        //
        unsafe {
            Self::from_inner(
                Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
            )
        }
    }

    /// Constructs a new `Rc<T>` using a closure `data_fn` that has access to a weak reference to the constructing `Rc<T>`. <br>使用闭包 `data_fn` 创建一个新的 `Rc<T>`，该闭包可以访问构造 `Rc<T>` 的弱引用。<br>
    ///
    /// Generally, a structure circularly referencing itself, either directly or indirectly, should not hold a strong reference to prevent a memory leak. <br>通常，直接或间接循环引用自身的结构不应持有强引用，以防止内存泄漏。<br>
    /// In `data_fn`, initialization of `T` can make use of the weak reference by cloning and storing it inside `T` for use at a later time. <br>在 `data_fn` 中，`T` 的初始化可以通过克隆和存储在 `T` 中来使用弱引用，以备以后使用。<br>
    ///
    /// Since the new `Rc<T>` is not fully-constructed until `Rc<T>::new_cyclic` returns, calling [`upgrade`] on the weak reference inside `data_fn` will fail and result in a `None` value. <br>由于新的 `Rc<T>` 在 `Rc<T>::new_cyclic` 返回之前尚未完全构造，因此在 `data_fn` 内部的弱引用上调用 [`upgrade`] 将失败，并导致一个 `None` 值。<br>
    ///
    ///
    /// # Panics
    /// If `data_fn` panics, the panic is propagated to the caller, and the temporary [`Weak<T>`] is dropped normally. <br>如果 `data_fn` 发生 panic，panic 会传播给调用者，而临时的 [`Weak<T>`] 会被正常丢弃。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     me: Weak<Gadget>,
    /// }
    ///
    /// impl Gadget {
    ///     /// Construct a reference counted Gadget. <br>创建一个引用计数的 Gadget。<br>
    ///     fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|me| Gadget { me: me.clone() })
    ///     }
    ///
    ///     /// Return a reference counted pointer to Self. <br>返回一个指向 Self 的引用计数指针。<br>
    ///     fn me(&self) -> Rc<Self> {
    ///         self.me.upgrade().unwrap()
    ///     }
    /// }
    /// ```
    /// [`upgrade`]: Weak::upgrade
    ///
    ///
    ///
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "arc_new_cyclic", since = "1.60.0")]
    pub fn new_cyclic<F>(data_fn: F) -> Rc<T>
    where
        F: FnOnce(&Weak<T>) -> T,
    {
        // Construct the inner in the "uninitialized" state with a single weak reference. <br>在未初始化状态下用一个弱引用建造内部。<br>
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // It's important we don't give up ownership of the weak pointer, or else the memory might be freed by the time `data_fn` returns. <br>重要的是我们不要放弃弱指针的所有权，否则在 `data_fn` 返回时可能会释放内存。<br>
        // If we really wanted to pass ownership, we could create an additional weak pointer for ourselves, but this would result in additional updates to the weak reference count which might not be necessary otherwise. <br>如果我们真的想传递所有权，则可以为我们自己创建一个额外的弱指针，但这将导致对弱引用计数的其他更新，否则可能没有必要。<br>
        //
        //
        //
        //
        let data = data_fn(&weak);

        let strong = unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);

            Rc::from_inner(init_ptr)
        };

        // Strong references should collectively own a shared weak reference, so don't run the destructor for our old weak reference. <br>强引用应该共同拥有一个共享的弱引用，所以不要为我们的旧弱引用运行析构函数。<br>
        //
        mem::forget(weak);
        strong
    }

    /// Constructs a new `Rc` with uninitialized contents. <br>创建一个具有未初始化内容的新 `Rc`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// // Deferred initialization: <br>延迟初始化：<br>
    /// Rc::get_mut(&mut five).unwrap().write(5);
    ///
    /// let five = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[must_use]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constructs a new `Rc` with uninitialized contents, with the memory being filled with `0` bytes. <br>创建一个具有未初始化内容的新 `Rc`，并用 `0` 字节填充内存。<br>
    ///
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage of this method. <br>有关正确和不正确使用此方法的示例，请参见 [`MaybeUninit::zeroed`][zeroed]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[must_use]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constructs a new `Rc<T>`, returning an error if the allocation fails <br>创建一个新的 `Rc<T>`，如果分配失败，则返回错误<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // There is an implicit weak pointer owned by all the strong pointers, which ensures that the weak destructor never frees the allocation while the strong destructor is running, even if the weak pointer is stored inside the strong one. <br>所有强指针都拥有一个隐式的弱指针，以确保即使强指针中存储了弱指针，弱析构函数也不会在强析构函数运行时释放分配。<br>
        //
        //
        //
        unsafe {
            Ok(Self::from_inner(
                Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                    .into(),
            ))
        }
    }

    /// Constructs a new `Rc` with uninitialized contents, returning an error if the allocation fails <br>用未初始化的内容构造一个新的 `Rc`，如果分配失败，则返回错误<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// // Deferred initialization: <br>延迟初始化：<br>
    /// Rc::get_mut(&mut five).unwrap().write(5);
    ///
    /// let five = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Constructs a new `Rc` with uninitialized contents, with the memory being filled with `0` bytes, returning an error if the allocation fails <br>创建一个具有未初始化内容的新 `Rc`，并用 `0` 字节填充内存，如果分配失败，则返回错误<br>
    ///
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage of this method. <br>有关正确和不正确使用此方法的示例，请参见 [`MaybeUninit::zeroed`][zeroed]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Constructs a new `Pin<Rc<T>>`. <br>创建一个新的 `Pin<Rc<T>>`。<br>
    /// If `T` does not implement `Unpin`, then `value` will be pinned in memory and unable to be moved. <br>如果 `T` 未实现 `Unpin`，则 `value` 将被固定在内存中并且无法移动。<br>
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "pin", since = "1.33.0")]
    #[must_use]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Returns the inner value, if the `Rc` has exactly one strong reference. <br>如果 `Rc` 正好有一个强引用，则返回内部值。<br>
    ///
    /// Otherwise, an [`Err`] is returned with the same `Rc` that was passed in. <br>否则，返回的 [`Err`] 将与传入的 `Rc` 相同。<br>
    ///
    ///
    /// This will succeed even if there are outstanding weak references. <br>即使存在突出的弱引用，此操作也将成功。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // copy the contained object <br>复制包含的对象<br>

                // Indicate to Weaks that they can't be promoted by decrementing the strong count, and then remove the implicit "strong weak" pointer while also handling drop logic by just crafting a fake Weak. <br>向 Weaks 表明，不能通过减少强引用计数来提升它们，然后丢弃隐式 "strong weak" 指针，同时还通过伪造 Weak 来处理放置逻辑。<br>
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Constructs a new reference-counted slice with uninitialized contents. <br>创建一个新的带有未初始化内容的引用计数的切片。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// // Deferred initialization: <br>延迟初始化：<br>
    /// let data = Rc::get_mut(&mut values).unwrap();
    /// data[0].write(1);
    /// data[1].write(2);
    /// data[2].write(3);
    ///
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[must_use]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Constructs a new reference-counted slice with uninitialized contents, with the memory being filled with `0` bytes. <br>用未初始化的内容创建一个新的带有引用计数的切片，内存中填充 `0` 字节。<br>
    ///
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage of this method. <br>有关正确和不正确使用此方法的示例，请参见 [`MaybeUninit::zeroed`][zeroed]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[must_use]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Converts to `Rc<T>`. <br>转换为 `Rc<T>`。<br>
    ///
    /// # Safety
    ///
    /// As with [`MaybeUninit::assume_init`], it is up to the caller to guarantee that the inner value really is in an initialized state. <br>与 [`MaybeUninit::assume_init`] 一样，由调用者负责确保内部值确实处于初始化状态。<br>
    ///
    /// Calling this when the content is not yet fully initialized causes immediate undefined behavior. <br>在内容尚未完全初始化时调用此方法会立即导致未定义的行为。<br>
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// // Deferred initialization: <br>延迟初始化：<br>
    /// Rc::get_mut(&mut five).unwrap().write(5);
    ///
    /// let five = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        unsafe { Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast()) }
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Converts to `Rc<[T]>`. <br>转换为 `Rc<[T]>`。<br>
    ///
    /// # Safety
    ///
    /// As with [`MaybeUninit::assume_init`], it is up to the caller to guarantee that the inner value really is in an initialized state. <br>与 [`MaybeUninit::assume_init`] 一样，由调用者负责确保内部值确实处于初始化状态。<br>
    ///
    /// Calling this when the content is not yet fully initialized causes immediate undefined behavior. <br>在内容尚未完全初始化时调用此方法会立即导致未定义的行为。<br>
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// // Deferred initialization: <br>延迟初始化：<br>
    /// let data = Rc::get_mut(&mut values).unwrap();
    /// data[0].write(1);
    /// data[1].write(2);
    /// data[2].write(3);
    ///
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Consumes the `Rc`, returning the wrapped pointer. <br>消耗 `Rc`，返回包装的指针。<br>
    ///
    /// To avoid a memory leak the pointer must be converted back to an `Rc` using [`Rc::from_raw`]. <br>为避免内存泄漏，必须使用 [`Rc::from_raw`] 将指针转换回 `Rc`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Provides a raw pointer to the data. <br>为数据提供裸指针。<br>
    ///
    /// The counts are not affected in any way and the `Rc` is not consumed. <br>计数不会受到任何影响，并且不会消耗 `Rc`。<br>
    /// The pointer is valid for as long there are strong counts in the `Rc`. <br>只要 `Rc` 中存在大量计数，指针就有效。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: This cannot go through Deref::deref or Rc::inner because this is required to retain raw/mut provenance such that e.g. <br>这不能通过 Deref::deref 或 Rc::inner，因为这是保留 raw/mut 出处所必需的，例如<br>
        // `get_mut` can write through the pointer after the Rc is recovered through `from_raw`. <br>通过 `from_raw` 恢复 Rc 后，`get_mut` 可以通过指针写入。<br>
        //
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Constructs an `Rc<T>` from a raw pointer. <br>从裸指针构造 `Rc<T>`。<br>
    ///
    /// The raw pointer must have been previously returned by a call to [`Rc<U>::into_raw`][into_raw] where `U` must have the same size and alignment as `T`. <br>裸指针必须事先由调用返回到 [`Rc<U>::into_raw`][into_raw]，其中 `U` 的大小和对齐方式必须与 `T` 相同。<br>
    /// This is trivially true if `U` is `T`. <br>如果 `U` 是 `T`，这是很简单的。<br>
    /// Note that if `U` is not `T` but has the same size and alignment, this is basically like transmuting references of different types. <br>请注意，如果 `U` 不是 `T`，但是具有相同的大小和对齐方式，则基本上就像对不同类型的引用进行转换一样。<br>
    /// See [`mem::transmute`] for more information on what restrictions apply in this case. <br>有关在这种情况下适用哪些限制的更多信息，请参见 [`mem::transmute`]。<br>
    ///
    /// The user of `from_raw` has to make sure a specific value of `T` is only dropped once. <br>`from_raw` 的用户必须确保 `T` 的特定值仅被丢弃一次。<br>
    ///
    /// This function is unsafe because improper use may lead to memory unsafety, even if the returned `Rc<T>` is never accessed. <br>此函数不安全，因为使用不当可能会导致内存不安全，即使从未访问返回的 `Rc<T>` 也是如此。<br>
    ///
    /// [into_raw]: Rc::into_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Convert back to an `Rc` to prevent leak. <br>转换回 `Rc` 以防止泄漏。<br>
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Further calls to `Rc::from_raw(x_ptr)` would be memory-unsafe. <br>进一步调用 `Rc::from_raw(x_ptr)` 将导致内存不安全。<br>
    /// }
    ///
    /// // The memory was freed when `x` went out of scope above, so `x_ptr` is now dangling! <br>当 `x` 超出上面的作用域时，其内存将被释放，所以 `x_ptr` 现在悬垂了！<br>
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Reverse the offset to find the original RcBox. <br>反转偏移量以找到原始的 RcBox。<br>
        let rc_ptr =
            unsafe { (ptr as *mut u8).offset(-offset).with_metadata_of(ptr as *mut RcBox<T>) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Creates a new [`Weak`] pointer to this allocation. <br>创建一个指向该分配的新 [`Weak`] 指针。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[must_use = "this returns a new `Weak` pointer, \
                  without modifying the original `Rc`"]
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Make sure we do not create a dangling Weak <br>确保我们不会创建悬垂的 Weak<br>
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Gets the number of [`Weak`] pointers to this allocation. <br>获取指向该分配的 [`Weak`] 指针的数量。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Gets the number of strong (`Rc`) pointers to this allocation. <br>获取指向此分配的强 (`Rc`) 指针的数量。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Increments the strong reference count on the `Rc<T>` associated with the provided pointer by one. <br>将与提供的指针关联的 `Rc<T>` 上的强引用计数增加 1。<br>
    ///
    /// # Safety
    ///
    /// The pointer must have been obtained through `Rc::into_raw`, and the associated `Rc` instance must be valid (i.e. <br>指针必须是通过 `Rc::into_raw` 获得的，并且关联的 `Rc` 实例必须是有效的 (即<br>
    /// the strong count must be at least 1) for the duration of this method. <br>在此方法的持续时间内，强引用计数必须至少为 1)。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Rc::into_raw(five);
    ///     Rc::increment_strong_count(ptr);
    ///
    ///     let five = Rc::from_raw(ptr);
    ///     assert_eq!(2, Rc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_mutate_strong_count", since = "1.53.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Retain Rc, but don't touch refcount by wrapping in ManuallyDrop <br>保留 Rc，但不要通过包装在手动丢弃中来触及引用计数<br>
        let rc = unsafe { mem::ManuallyDrop::new(Rc::<T>::from_raw(ptr)) };
        // Now increase refcount, but don't drop new refcount either <br>现在增加引用计数，但也不要丢弃新的引用计数<br>
        let _rc_clone: mem::ManuallyDrop<_> = rc.clone();
    }

    /// Decrements the strong reference count on the `Rc<T>` associated with the provided pointer by one. <br>将与提供的指针关联的 `Rc<T>` 上的强引用计数减一。<br>
    ///
    /// # Safety
    ///
    /// The pointer must have been obtained through `Rc::into_raw`, and the associated `Rc` instance must be valid (i.e. <br>指针必须是通过 `Rc::into_raw` 获得的，并且关联的 `Rc` 实例必须是有效的 (即<br>
    /// the strong count must be at least 1) when invoking this method. <br>调用此方法时，强引用计数必须至少为 1)。<br>
    /// This method can be used to release the final `Rc` and backing storage, but **should not** be called after the final `Rc` has been released. <br>此方法可用于释放最终的 `Rc` 和后备存储，但**不应**在最终的 `Rc` 释放后调用。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Rc::into_raw(five);
    ///     Rc::increment_strong_count(ptr);
    ///
    ///     let five = Rc::from_raw(ptr);
    ///     assert_eq!(2, Rc::strong_count(&five));
    ///     Rc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Rc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_mutate_strong_count", since = "1.53.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Rc::from_raw(ptr)) };
    }

    /// Returns `true` if there are no other `Rc` or [`Weak`] pointers to this allocation. <br>如果没有其他指向该分配的 `Rc` 或 [`Weak`] 指针，则返回 `true`。<br>
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Returns a mutable reference into the given `Rc`, if there are no other `Rc` or [`Weak`] pointers to the same allocation. <br>如果没有其他 `Rc` 或 [`Weak`] 指向相同分配的指针，则返回给定 `Rc` 的可变引用。<br>
    ///
    ///
    /// Returns [`None`] otherwise, because it is not safe to mutate a shared value. <br>否则返回 [`None`]，因为更改共享值并不安全。<br>
    ///
    /// See also [`make_mut`][make_mut], which will [`clone`][clone] the inner value when there are other `Rc` pointers. <br>另请参见 [`make_mut`][make_mut]，当有其他 `Rc` 指针时，它将 [`clone`][clone] 内部值。<br>
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Returns a mutable reference into the given `Rc`, without any check. <br>将变量引用返回给定的 `Rc`，而不进行任何检查。<br>
    ///
    /// See also [`get_mut`], which is safe and does appropriate checks. <br>另请参见 [`get_mut`]，它是安全的并且进行适当的检查。<br>
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Any other `Rc` or [`Weak`] pointers to the same allocation must not be dereferenced for the duration of the returned borrow. <br>在返回的借用期间，不得解引用其他指向相同分配的 `Rc` 或 [`Weak`] 指针。<br>
    ///
    /// This is trivially the case if no such pointers exist, for example immediately after `Rc::new`. <br>如果不存在这样的指针 (例如紧接在 `Rc::new` 之后)，则情况很简单。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // We are careful to *not* create a reference covering the "count" fields, as this would conflict with accesses to the reference counts (e.g. <br>我们小心 *不要* 创建覆盖 "count" 字段的引用，因为这会与对引用计数的访问产生冲突 (例如<br>
        // by `Weak`). <br>由 `Weak`)。<br>
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Returns `true` if the two `Rc`s point to the same allocation (in a vein similar to [`ptr::eq`]). <br>如果两个 Rc 指向相同的分配 (类似于 [`ptr::eq`])，则返回 `true`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Makes a mutable reference into the given `Rc`. <br>对给定的 `Rc` 进行可变引用。<br>
    ///
    /// If there are other `Rc` pointers to the same allocation, then `make_mut` will [`clone`] the inner value to a new allocation to ensure unique ownership. <br>如果还有其他指向同一分配的 `Rc` 指针，则 `make_mut` 会将 [`clone`] 的内部值分配给新分配，以确保唯一的所有权。<br>
    /// This is also referred to as clone-on-write. <br>这也称为写时克隆。<br>
    ///
    /// However, if there are no other `Rc` pointers to this allocation, but some [`Weak`] pointers, then the [`Weak`] pointers will be disassociated and the inner value will not be cloned. <br>但是，如果没有其他指向此分配的 `Rc` 指针，而是一些 [`Weak`] 指针，则 [`Weak`] 指针将被解除关联，并且不会克隆内部值。<br>
    ///
    ///
    /// See also [`get_mut`], which will fail rather than cloning the inner value or diassociating [`Weak`] pointers. <br>另请参见 [`get_mut`]，它会失败而不是克隆内部值或取消关联 [`Weak`] 指针。<br>
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;         // Won't clone anything <br>不会克隆任何东西<br>
    /// let mut other_data = Rc::clone(&data); // Won't clone inner data <br>不会克隆内部数据<br>
    /// *Rc::make_mut(&mut data) += 1;         // Clones inner data <br>克隆内部数据<br>
    /// *Rc::make_mut(&mut data) += 1;         // Won't clone anything <br>不会克隆任何东西<br>
    /// *Rc::make_mut(&mut other_data) *= 2;   // Won't clone anything <br>不会克隆任何东西<br>
    ///
    /// // Now `data` and `other_data` point to different allocations. <br>现在，`data` 和 `other_data` 指向不同的分配。<br>
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] pointers will be disassociated: <br>[`Weak`] 指针将被解除关联：<br>
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Gotta clone the data, there are other Rcs. <br>要克隆数据，还有其他 Rcs。<br>
            // Pre-allocate memory to allow writing the cloned value directly. <br>预分配内存以允许直接写入克隆的值。<br>
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Can just steal the data, all that's left is Weaks <br>只能窃取数据，剩下的就是 Weaks<br>
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Remove implicit strong-weak ref (no need to craft a fake Weak here -- we know other Weaks can clean up for us) <br>删除隐式的强弱引用 (无需在此处制作假的弱项 - 我们知道其他弱项也可以为我们清除)<br>
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // This unsafety is ok because we're guaranteed that the pointer returned is the *only* pointer that will ever be returned to T. <br>这种不安全性是可以的，因为我们保证返回的指针是将永远返回到 T 的 *only* 指针。<br>
        // Our reference count is guaranteed to be 1 at this point, and we required the `Rc<T>` itself to be `mut`, so we're returning the only possible reference to the allocation. <br>此时我们的引用计数保证为 1，并且我们要求 `Rc<T>` 本身为 `mut`，因此我们将唯一可能的引用返回给分配。<br>
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }

    /// If we have the only reference to `T` then unwrap it. <br>如果我们有 `T` 的唯一引用，那就打开它。<br> Otherwise, clone `T` and return the clone. <br>否则，克隆 `T` 并返回克隆。<br>
    ///
    /// Assuming `rc_t` is of type `Rc<T>`, this function is functionally equivalent to `(*rc_t).clone()`, but will avoid cloning the inner value where possible. <br>假设 `rc_t` 是 `Rc<T>` 类型，这个函数在功能上等同于 `(*rc_t).clone()`，但会尽可能避免克隆内部值。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_unwrap_or_clone)]
    /// # use std::{ptr, rc::Rc};
    /// let inner = String::from("test");
    /// let ptr = inner.as_ptr();
    ///
    /// let rc = Rc::new(inner);
    /// let inner = Rc::unwrap_or_clone(rc);
    /// // The inner value was not cloned <br>内部值没有被克隆<br>
    /// assert!(ptr::eq(ptr, inner.as_ptr()));
    ///
    /// let rc = Rc::new(inner);
    /// let rc2 = rc.clone();
    /// let inner = Rc::unwrap_or_clone(rc);
    /// // Because there were 2 references, we had to clone the inner value. <br>因为有两个引用，我们不得不克隆内部值。<br>
    /// assert!(!ptr::eq(ptr, inner.as_ptr()));
    /// // `rc2` is the last reference, so when we unwrap it we get back the original `String`. <br>`rc2` 是最后一个引用，所以当我们打开它时，我们会得到原来的 `String`。<br>
    /////
    /// let inner = Rc::unwrap_or_clone(rc2);
    /// assert!(ptr::eq(ptr, inner.as_ptr()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "arc_unwrap_or_clone", issue = "93610")]
    pub fn unwrap_or_clone(this: Self) -> T {
        Rc::try_unwrap(this).unwrap_or_else(|rc| (*rc).clone())
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Attempt to downcast the `Rc<dyn Any>` to a concrete type. <br>尝试将 `Rc<dyn Any>` 转换为具体类型。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            unsafe {
                let ptr = self.ptr.cast::<RcBox<T>>();
                forget(self);
                Ok(Rc::from_inner(ptr))
            }
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Allocates an `RcBox<T>` with sufficient space for a possibly-unsized inner value where the value has the layout provided. <br>为 `RcBox<T>` 分配足够的空间，以容纳可能未定义大小的内部值，其中该值具有提供的布局。<br>
    ///
    /// The function `mem_to_rcbox` is called with the data pointer and must return back a (potentially fat)-pointer for the `RcBox<T>`. <br>函数 `mem_to_rcbox` 用数据指针调用，并且必须返回 `RcBox<T>` 的 (可能是胖的) 指针。<br>
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Calculate layout using the given value layout. <br>使用给定的值布局计算布局。<br>
        // Previously, layout was calculated on the expression `&*(ptr as *const RcBox<T>)`, but this created a misaligned reference (see #54908). <br>以前，在表达式 `&*(ptr as *const RcBox<T>)` 上计算布局，但是这会产生未对齐的引用 (请参见 #54908)。<br>
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Allocates an `RcBox<T>` with sufficient space for a possibly-unsized inner value where the value has the layout provided, returning an error if allocation fails. <br>为 `RcBox<T>` 分配足够的空间，以容纳可能未定义大小的内部值 (该值具有提供的布局)，如果分配失败，则返回错误。<br>
    ///
    ///
    /// The function `mem_to_rcbox` is called with the data pointer and must return back a (potentially fat)-pointer for the `RcBox<T>`. <br>函数 `mem_to_rcbox` 用数据指针调用，并且必须返回 `RcBox<T>` 的 (可能是胖的) 指针。<br>
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Calculate layout using the given value layout. <br>使用给定的值布局计算布局。<br>
        // Previously, layout was calculated on the expression `&*(ptr as *const RcBox<T>)`, but this created a misaligned reference (see #54908). <br>以前，在表达式 `&*(ptr as *const RcBox<T>)` 上计算布局，但是这会产生未对齐的引用 (请参见 #54908)。<br>
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Allocate for the layout. <br>为布局分配。<br>
        let ptr = allocate(layout)?;

        // Initialize the RcBox <br>初始化 RcBox<br>
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Allocates an `RcBox<T>` with sufficient space for an unsized inner value <br>为 `RcBox` 分配足够的空间，以容纳未定义大小的内部值<br>
    #[cfg(not(no_global_oom_handling))]
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Allocate for the `RcBox<T>` using the given value. <br>使用给定的值分配 `RcBox<T>`。<br>
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| mem.with_metadata_of(ptr as *mut RcBox<T>),
            )
        }
    }

    #[cfg(not(no_global_oom_handling))]
    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copy value as bytes <br>将值复制为字节<br>
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Free the allocation without dropping its contents <br>释放分配而不丢弃其内容<br>
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Allocates an `RcBox<[T]>` with the given length. <br>用给定的长度分配 `RcBox<[T]>`。<br>
    #[cfg(not(no_global_oom_handling))]
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Copy elements from slice into newly allocated Rc<\[T\]> <br>将切片中的元素复制到新分配的 Rc<\[T\]> 中<br>
    ///
    /// Unsafe because the caller must either take ownership or bind `T: Copy` <br>不安全，因为调用者必须拥有所有权或绑定 `T: Copy`<br>
    #[cfg(not(no_global_oom_handling))]
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Constructs an `Rc<[T]>` from an iterator known to be of a certain size. <br>从已知为一定大小的迭代器构造 `Rc<[T]>`。<br>
    ///
    /// Behavior is undefined should the size be wrong. <br>如果大小错误，则行为是未定义的。<br>
    #[cfg(not(no_global_oom_handling))]
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic guard while cloning T elements. <br>在克隆 T 元素时 panic 守卫。<br>
        // In the event of a panic, elements that have been written into the new RcBox will be dropped, then the memory freed. <br>如果出现 panic，将丢弃已写入新 RcBox 的元素，然后释放内存。<br>
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer to first element <br>指向第一个元素的指针<br>
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // All clear. <br>全部清空。<br> Forget the guard so it doesn't free the new RcBox. <br>忘记守卫，这样它就不会释放新的 RcBox。<br>
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait used for `From<&[T]>`. <br>用于 `From<&[T]>` 使用的专业化 trait。<br>
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

#[cfg(not(no_global_oom_handling))]
impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

#[cfg(not(no_global_oom_handling))]
impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Drops the `Rc`. <br>丢弃 `Rc`。<br>
    ///
    /// This will decrement the strong reference count. <br>这将减少强引用计数。<br>
    /// If the strong reference count reaches zero then the only other references (if any) are [`Weak`], so we `drop` the inner value. <br>如果强引用计数达到零，那么唯一的其他引用 (如果有) 是 [`Weak`]，因此我们将 `drop` 作为内部值。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Doesn't print anything <br>不打印任何东西<br>
    /// drop(foo2);   // Prints "dropped!" <br>打印 "dropped!"<br>
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // destroy the contained object <br>销毁所包含的对象<br>
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // remove the implicit "strong weak" pointer now that we've destroyed the contents. <br>现在我们已经销毁了内容，请删除隐式 "strong weak" 指针。<br>
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Makes a clone of the `Rc` pointer. <br>克隆 `Rc` 指针。<br>
    ///
    /// This creates another pointer to the same allocation, increasing the strong reference count. <br>这将创建另一个指向相同分配的指针，从而增加了强引用计数。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        unsafe {
            self.inner().inc_strong();
            Self::from_inner(self.ptr)
        }
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Creates a new `Rc<T>`, with the `Default` value for `T`. <br>用 `T` 的 `Default` 值创建一个新的 `Rc<T>`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack to allow specializing on `Eq` even though `Eq` has a method. <br>即使 `Eq` 有一种方法，也可以允许专门研究 `Eq`。<br>
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// We're doing this specialization here, and not as a more general optimization on `&T`, because it would otherwise add a cost to all equality checks on refs. <br>我们在这里进行这种专门化，而不是对 `&T` 进行更一般的优化，因为否则会增加对引用的所有相等性检查的成本。<br>
/// We assume that `Rc`s are used to store large values, that are slow to clone, but also heavy to check for equality, causing this cost to pay off more easily. <br>我们假设 `Rc`s 用于存储较大的值，这些值克隆起来较慢，但在检查相等性时又很繁琐，从而使此成本更容易得到回报。<br>
///
/// It's also more likely to have two `Rc` clones, that point to the same value, than two `&T`s. <br>与两个 `&T` 相比，它更有可能具有两个指向相同值的 `Rc` 克隆。<br>
///
/// We can only do this when `T: Eq` as a `PartialEq` might be deliberately irreflexive. <br>仅当 `T: Eq` 作为 `PartialEq` 可能是故意的非反射时，我们才能这样做。<br>
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Equality for two `Rc`s. <br>两个 Rc 相等。<br>
    ///
    /// Two `Rc`s are equal if their inner values are equal, even if they are stored in different allocation. <br>即使两个 `Rc` 的内部值相等，即使它们存储在不同的分配中，它们也相等。<br>
    ///
    /// If `T` also implements `Eq` (implying reflexivity of equality), two `Rc`s that point to the same allocation are always equal. <br>如果 `T` 还实现了 `Eq` (暗示相等的反射性)，则指向同一分配的两个 `Rc' 始终相等。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Inequality for two `Rc`s. <br>两个 `Rc` 的不等式。<br>
    ///
    /// Two `Rc`s are unequal if their inner values are unequal. <br>如果两个 `Rc` 的内部值不相等，则它们是不相等的。<br>
    ///
    /// If `T` also implements `Eq` (implying reflexivity of equality), two `Rc`s that point to the same allocation are never unequal. <br>如果 `T` 还实现了 `Eq` (暗示相等性的反射性)，则指向同一分配的两个 Rc 永远不会相等。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Partial comparison for two `Rc`s. <br>两个 `Rc` 的部分比较。<br>
    ///
    /// The two are compared by calling `partial_cmp()` on their inner values. <br>通过调用 `partial_cmp()` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Less-than comparison for two `Rc`s. <br>小于两个 Rc 的比较。<br>
    ///
    /// The two are compared by calling `<` on their inner values. <br>通过调用 `<` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Less than or equal to' comparison for two `Rc`s. <br>两个 `Rc` 的小于或等于比较。<br>
    ///
    /// The two are compared by calling `<=` on their inner values. <br>通过调用 `<=` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Greater-than comparison for two `Rc`s. <br>大于两个 Rc 的比较。<br>
    ///
    /// The two are compared by calling `>` on their inner values. <br>通过调用 `>` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Greater than or equal to' comparison for two `Rc`s. <br>两个 `Rc` 的大于或等于比较。<br>
    ///
    /// The two are compared by calling `>=` on their inner values. <br>通过调用 `>=` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Comparison for two `Rc`s. <br>两个 `Rc` 的比较。<br>
    ///
    /// The two are compared by calling `cmp()` on their inner values. <br>通过调用 `cmp()` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    /// Converts a generic type `T` into an `Rc<T>` <br>泛型 `T` 改装成 `Rc<T>`<br>
    ///
    /// The conversion allocates on the heap and moves `t` from the stack into it. <br>转换在堆上分配，并将 `t` 从栈移到堆中。<br>
    ///
    /// # Example
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let x = 5;
    /// let rc = Rc::new(5);
    ///
    /// assert_eq!(Rc::from(x), rc);
    /// ```
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Allocate a reference-counted slice and fill it by cloning `v`'s items. <br>分配一个引用计数的切片，并通过克隆 `v` 的项来填充它。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Allocate a reference-counted string slice and copy `v` into it. <br>分配一个引用计数的字符串切片并将 `v` 复制到其中。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Allocate a reference-counted string slice and copy `v` into it. <br>分配一个引用计数的字符串切片并将 `v` 复制到其中。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Move a boxed object to a new, reference counted, allocation. <br>将 boxed 对象移动到引用计数的新分配。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Allocate a reference-counted slice and move `v`'s items into it. <br>分配一个引用计数的切片，并将 `v` 的项移入其中。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Allow the Vec to free its memory, but not destroy its contents <br>允许 Vec 释放其内存，但不销毁其内容<br>
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    /// Create a reference-counted pointer from a clone-on-write pointer by copying its content. <br>通过复制其内容，从写时克隆指针创建一个引用计数指针。<br>
    ///
    ///
    /// # Example
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// # use std::borrow::Cow;
    /// let cow: Cow<str> = Cow::Borrowed("eggplant");
    /// let shared: Rc<str> = Rc::from(cow);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Takes each element in the `Iterator` and collects it into an `Rc<[T]>`. <br>获取 `Iterator` 中的每个元素，并将其收集到 `Rc<[T]>` 中。<br>
    ///
    /// # Performance characteristics <br>性能特点<br>
    ///
    /// ## The general case <br>一般情况<br>
    ///
    /// In the general case, collecting into `Rc<[T]>` is done by first collecting into a `Vec<T>`. <br>在一般情况下，首先要收集到 `Vec<T>` 中来收集到 `Rc<[T]>` 中。<br> That is, when writing the following: <br>也就是说，编写以下内容时：<br>
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// this behaves as if we wrote: <br>这就像我们写的那样：<br>
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // The first set of allocations happens here. <br>第一组分配在此处发生。<br>
    ///     .into(); // A second allocation for `Rc<[T]>` happens here. <br>`Rc<[T]>` 的第二个分配在此处进行。<br>
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// This will allocate as many times as needed for constructing the `Vec<T>` and then it will allocate once for turning the `Vec<T>` into the `Rc<[T]>`. <br>这将分配构造 `Vec<T>` 所需的次数，然后分配一次，以将 `Vec<T>` 转换为 `Rc<[T]>`。<br>
    ///
    ///
    /// ## Iterators of known length <br>已知长度的迭代器<br>
    ///
    /// When your `Iterator` implements `TrustedLen` and is of an exact size, a single allocation will be made for the `Rc<[T]>`. <br>当您的 `Iterator` 实现 `TrustedLen` 且大小正确时，将为 `Rc<[T]>` 进行一次分配。<br> For example: <br>例如：<br>
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Just a single allocation happens here. <br>这里只进行一次分配。<br>
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specialization trait used for collecting into `Rc<[T]>`. <br>专门的 trait 用于收集到 `Rc<[T]>` 中。<br>
#[cfg(not(no_global_oom_handling))]
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

#[cfg(not(no_global_oom_handling))]
impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

#[cfg(not(no_global_oom_handling))]
impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // This is the case for a `TrustedLen` iterator. <br>`TrustedLen` 迭代器就是这种情况。<br>
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: We need to ensure that the iterator has an exact length and we have. <br>我们需要确保迭代器有一个精确的长度，并且我们有。<br>
                Rc::from_iter_exact(self, low)
            }
        } else {
            // TrustedLen contract guarantees that `upper_bound == `None` implies an iterator length exceeding `usize::MAX`. <br>TrustedLen 契约保证 `upper_bound == `None` 意味着迭代器长度超过 `usize::MAX`。<br>
            //
            // The default implementation would collect into a vec which would panic. <br>默认实现将收集到一个 vec 中，这将是 panic。<br>
            // Thus we panic here immediately without invoking `Vec` code. <br>因此，我们立即在此处 panic 而不调用 `Vec` 代码。<br>
            panic!("capacity overflow");
        }
    }
}

/// `Weak` is a version of [`Rc`] that holds a non-owning reference to the managed allocation. <br>`Weak` 是 [`Rc`] 的一个版本，它持有对托管分配的非所有权引用。<br>
/// The allocation is accessed by calling [`upgrade`] on the `Weak` pointer, which returns an <code>[Option]<[Rc]\<T>></code>. <br>通过在 `Weak` 指针上调用 [`upgrade`] 来访问分配，它返回一个 <code>[Option]<[Rc]\<T>></code>。<br>
///
/// Since a `Weak` reference does not count towards ownership, it will not prevent the value stored in the allocation from being dropped, and `Weak` itself makes no guarantees about the value still being present. <br>由于 `Weak` 引用不计入所有权，因此它不会防止存储在分配中的值被丢弃，并且 `Weak` 本身不保证该值仍然存在。<br>
///
/// Thus it may return [`None`] when [`upgrade`]d. <br>因此，当 [`upgrade`] 时，它可能返回 [`None`]。<br>
/// Note however that a `Weak` reference *does* prevent the allocation itself (the backing store) from being deallocated. <br>但是请注意，`Weak` 引用 *确实* 会阻止分配本身 (后备存储) 被释放。<br>
///
/// A `Weak` pointer is useful for keeping a temporary reference to the allocation managed by [`Rc`] without preventing its inner value from being dropped. <br>`Weak` 指针可用于保持对 [`Rc`] 管理的分配的临时引用，而又不会阻止其内部值被丢弃。<br>
/// It is also used to prevent circular references between [`Rc`] pointers, since mutual owning references would never allow either [`Rc`] to be dropped. <br>它也用于防止 [`Rc`] 指针之间的循环引用，因为相互拥有引用将永远不允许丢弃 [`Rc`]。<br>
/// For example, a tree could have strong [`Rc`] pointers from parent nodes to children, and `Weak` pointers from children back to their parents. <br>例如，一棵树可以具有从父节点到子节点的强 [`Rc`] 指针，以及从子节点到其父节点的 `Weak` 指针。<br>
///
/// The typical way to obtain a `Weak` pointer is to call [`Rc::downgrade`]. <br>获取 `Weak` 指针的典型方法是调用 [`Rc::downgrade`]。<br>
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // This is a `NonNull` to allow optimizing the size of this type in enums, but it is not necessarily a valid pointer. <br>这是一个 `NonNull`，允许在枚举中优化此类型的大小，但它不一定是有效的指针。<br>
    //
    // `Weak::new` sets this to `usize::MAX` so that it doesn’t need to allocate space on the heap. <br>`Weak::new` 将它设置为 `usize::MAX`，这样它就不需要在堆上分配空间。<br>
    // That's not a value a real pointer will ever have because RcBox has alignment at least 2. <br>这不是真正的指针所具有的值，因为 RcBox 的对齐方式至少为 2。<br>
    // This is only possible when `T: Sized`; <br>仅当 `T: Sized` 时才有可能。<br> unsized `T` never dangle. <br>未定义大小的 `T` 永远不会悬垂。<br>
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Constructs a new `Weak<T>`, without allocating any memory. <br>创建一个新的 `Weak<T>`，而不分配任何内存。<br>
    /// Calling [`upgrade`] on the return value always gives [`None`]. <br>在返回值上调用 [`upgrade`] 总是得到 [`None`]。<br>
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    #[rustc_const_unstable(feature = "const_weak_new", issue = "95091", reason = "recently added")]
    #[must_use]
    pub const fn new() -> Weak<T> {
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr::invalid_mut::<RcBox<T>>(usize::MAX)) } }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    (ptr as *mut ()).addr() == usize::MAX
}

/// Helper type to allow accessing the reference counts without making any assertions about the data field. <br>帮助程序类型，允许访问引用计数而无需对数据字段进行任何声明。<br>
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Returns a raw pointer to the object `T` pointed to by this `Weak<T>`. <br>返回对此 `Weak<T>` 指向的对象 `T` 的裸指针。<br>
    ///
    /// The pointer is valid only if there are some strong references. <br>该指针仅在有一些强引用时才有效。<br>
    /// The pointer may be dangling, unaligned or even [`null`] otherwise. <br>指针可能是悬垂的，未对齐的，甚至是 [`null`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Both point to the same object <br>两者都指向同一个对象<br>
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // The strong here keeps it alive, so we can still access the object. <br>这里的强项使它保持活动状态，因此我们仍然可以访问该对象。<br>
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // But not any more. <br>但是没有更多了。<br>
    /// // We can do weak.as_ptr(), but accessing the pointer would lead to undefined behaviour. <br>我们可以执行 weak.as_ptr()，但是访问指针将导致未定义的行为。<br>
    /// // assert_eq!("hello", unsafe { &*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: ptr::null
    #[must_use]
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // If the pointer is dangling, we return the sentinel directly. <br>如果指针悬垂，我们将直接返回哨兵。<br>
            // This cannot be a valid payload address, as the payload is at least as aligned as RcBox (usize). <br>这不能是有效的有效载荷地址，因为有效载荷至少与 RcBox (usize) 对齐。<br>
            ptr as *const T
        } else {
            // SAFETY: if is_dangling returns false, then the pointer is dereferenceable. <br>如果 is_dangling 返回 false，则该指针是可解引用的。<br>
            // The payload may be dropped at this point, and we have to maintain provenance, so use raw pointer manipulation. <br>有效载荷可能会在此时被丢弃，所以我们必须维护出处，因此请使用裸指针操作。<br>
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Consumes the `Weak<T>` and turns it into a raw pointer. <br>消耗 `Weak<T>` 并将其转换为裸指针。<br>
    ///
    /// This converts the weak pointer into a raw pointer, while still preserving the ownership of one weak reference (the weak count is not modified by this operation). <br>这会将弱指针转换为裸指针，同时仍保留一个弱引用的所有权 (此操作不会修改弱引用计数)。<br>
    /// It can be turned back into the `Weak<T>` with [`from_raw`]. <br>可以将其转换回带有 [`from_raw`] 的 `Weak<T>`。<br>
    ///
    /// The same restrictions of accessing the target of the pointer as with [`as_ptr`] apply. <br>与 [`as_ptr`] 一样，访问指针目标的限制也适用。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converts a raw pointer previously created by [`into_raw`] back into `Weak<T>`. <br>将先前由 [`into_raw`] 创建的裸指针转换回 `Weak<T>`。<br>
    ///
    /// This can be used to safely get a strong reference (by calling [`upgrade`] later) or to deallocate the weak count by dropping the `Weak<T>`. <br>这可以用于安全地获得强引用 (稍后调用 [`upgrade`]) 或通过丢弃 `Weak<T>` 来分配弱引用计数。<br>
    ///
    /// It takes ownership of one weak reference (with the exception of pointers created by [`new`], as these don't own anything; the method still works on them). <br>它拥有一个弱引用的所有权 (由 [`new`] 创建的指针除外，因为它们不拥有任何东西; 该方法仍适用于它们)。<br>
    ///
    /// # Safety
    ///
    /// The pointer must have originated from the [`into_raw`] and must still own its potential weak reference. <br>指针必须起源于 [`into_raw`]，并且仍然必须拥有其潜在的弱引用。<br>
    ///
    /// It is allowed for the strong count to be 0 at the time of calling this. <br>调用时允许强引用计数为 0。<br>
    /// Nevertheless, this takes ownership of one weak reference currently represented as a raw pointer (the weak count is not modified by this operation) and therefore it must be paired with a previous call to [`into_raw`]. <br>不过，这需要当前表示为裸指针的弱引用的所有权 (该操作不会修改弱引用计数)，因此必须与 [`into_raw`] 的先前调用配对。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Decrement the last weak count. <br>减少最后一个弱引用计数。<br>
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // See Weak::as_ptr for context on how the input pointer is derived. <br>有关如何派生输入指针的上下文，请参见 Weak::as_ptr。<br>

        let ptr = if is_dangling(ptr as *mut T) {
            // This is a dangling Weak. <br>这是悬垂的 Weak。<br>
            ptr as *mut RcBox<T>
        } else {
            // Otherwise, we're guaranteed the pointer came from a nondangling Weak. <br>否则，我们保证指针来自无悬挂的弱。<br>
            // SAFETY: data_offset is safe to call, as ptr references a real (potentially dropped) T. <br>data_offset 可以安全调用，因为 ptr 引用了一个真实的 (可能已丢弃) 的 T。<br>
            let offset = unsafe { data_offset(ptr) };
            // Thus, we reverse the offset to get the whole RcBox. <br>因此，我们反转偏移量以获得整个 RcBox。<br>
            // SAFETY: the pointer originated from a Weak, so this offset is safe. <br>指针源自 Weak，因此此偏移量是安全的。<br>
            unsafe { (ptr as *mut u8).offset(-offset).with_metadata_of(ptr as *mut RcBox<T>) }
        };

        // SAFETY: we now have recovered the original Weak pointer, so can create the Weak. <br>我们现在已经恢复了原始的弱指针，因此可以创建弱指针。<br>
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Attempts to upgrade the `Weak` pointer to an [`Rc`], delaying dropping of the inner value if successful. <br>尝试将 `Weak` 指针升级到 [`Rc`]，如果成功，则延迟丢弃内部值。<br>
    ///
    ///
    /// Returns [`None`] if the inner value has since been dropped. <br>如果内部值已经被丢弃，则返回 [`None`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Destroy all strong pointers. <br>销毁所有强指针。<br>
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[must_use = "this returns a new `Rc`, \
                  without modifying the original weak pointer"]
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;

        if inner.strong() == 0 {
            None
        } else {
            unsafe {
                inner.inc_strong();
                Some(Rc::from_inner(self.ptr))
            }
        }
    }

    /// Gets the number of strong (`Rc`) pointers pointing to this allocation. <br>获取指向该分配的强 (`Rc`) 指针的数量。<br>
    ///
    /// If `self` was created using [`Weak::new`], this will return 0. <br>如果 `self` 是使用 [`Weak::new`] 创建的，则将返回 0。<br>
    #[must_use]
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Gets the number of `Weak` pointers pointing to this allocation. <br>获取指向该分配的 `Weak` 指针的数量。<br>
    ///
    /// If no strong pointers remain, this will return zero. <br>如果没有剩余的强指针，它将返回零。<br>
    #[must_use]
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // subtract the implicit weak ptr <br>减去隐含的弱指针<br>
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Returns `None` when the pointer is dangling and there is no allocated `RcBox`, (i.e., when this `Weak` was created by `Weak::new`). <br>当指针悬垂并且没有分配的 `RcBox` 时 (即，当 `Weak` 由 `Weak::new` 创建时)，返回 `None`。<br>
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // We are careful to *not* create a reference covering the "data" field, as the field may be mutated concurrently (for example, if the last `Rc` is dropped, the data field will be dropped in-place). <br>我们小心 *不要* 创建覆盖 "data" 字段的引用，因为该字段可能会同时被修改 (例如，如果最后一个 `Rc` 被丢弃，则数据字段将被原地丢弃)。<br>
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Returns `true` if the two `Weak`s point to the same allocation (similar to [`ptr::eq`]), or if both don't point to any allocation (because they were created with `Weak::new()`). <br>如果两个 `Weak' 指向相同的分配 (类似于 [`ptr::eq`])，或者两个都不指向任何分配 (因为它们是用 `Weak::new()` 创建的)，则返回 `true`。<br>
    ///
    ///
    /// # Notes
    ///
    /// Since this compares pointers it means that `Weak::new()` will equal each other, even though they don't point to any allocation. <br>由于这将比较指针，这意味着 `Weak::new()` 将彼此相等，即使它们不指向任何分配。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparing `Weak::new`. <br>比较 `Weak::new`。<br>
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    ///
    #[inline]
    #[must_use]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Weak<T> {
    /// Drops the `Weak` pointer. <br>丢弃 `Weak` 指针。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Doesn't print anything <br>不打印任何东西<br>
    /// drop(foo);        // Prints "dropped!" <br>打印 "dropped!"<br>
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // the weak count starts at 1, and will only go to zero if all the strong pointers have disappeared. <br>弱引用计数从 1 开始，并且仅在所有强指针都消失后才变为零。<br>
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Makes a clone of the `Weak` pointer that points to the same allocation. <br>克隆 `Weak` 指针，该指针指向相同的分配。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Constructs a new `Weak<T>`, without allocating any memory. <br>创建一个新的 `Weak<T>`，而不分配任何内存。<br>
    /// Calling [`upgrade`] on the return value always gives [`None`]. <br>在返回值上调用 [`upgrade`] 总是得到 [`None`]。<br>
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: We checked_add here to deal with mem::forget safely. <br>我们在这里 check_add 来安全地处理 mem::forget。<br>
// In particular if you mem::forget Rcs (or Weaks), the ref-count can overflow, and then you can free the allocation while outstanding Rcs (or Weaks) exist. <br>特别是如果您使用 mem::forget Rcs (或 Weaks)，则引用计数可能会溢出，然后您可以在存在出色的 Rcs (或 Weaks) 的情况下释放分配。<br>
//
// We abort because this is such a degenerate scenario that we don't care about what happens -- no real program should ever experience this. <br>我们终止是因为这是一个简陋的场景，我们不在乎会发生什么 - 真正的程序都不会遇到这种情况。<br>
//
// This should have negligible overhead since you don't actually need to clone these much in Rust thanks to ownership and move-semantics. <br>这应该具有可忽略的开销，因为由于所有权和移动语义，您实际上不需要在 Rust 中克隆太多代码。<br>
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // We want to abort on overflow instead of dropping the value. <br>我们要终止溢出而不是丢弃该值。<br>
        // The reference count will never be zero when this is called; <br>调用时，引用计数永远不会为零；<br>
        // nevertheless, we insert an abort here to hint LLVM at an otherwise missed optimization. <br>但是，我们在此处插入一个终止以向 LLVM 提示进行其他优化时所错过的优化。<br>
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // We want to abort on overflow instead of dropping the value. <br>我们要终止溢出而不是丢弃该值。<br>
        // The reference count will never be zero when this is called; <br>调用时，引用计数永远不会为零；<br>
        // nevertheless, we insert an abort here to hint LLVM at an otherwise missed optimization. <br>但是，我们在此处插入一个终止以向 LLVM 提示进行其他优化时所错过的优化。<br>
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Get the offset within an `RcBox` for the payload behind a pointer. <br>为指针后面的有效载荷获取 `RcBox` 内的偏移量。<br>
///
/// # Safety
///
/// The pointer must point to (and have valid metadata for) a previously valid instance of T, but the T is allowed to be dropped. <br>指针必须指向 T 的先前有效实例 (并具有有效的元数据)，但是允许丢弃 T。<br>
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Align the unsized value to the end of the RcBox. <br>将未定义大小的值与 RcBox 的末端对齐。<br>
    // Because RcBox is repr(C), it will always be the last field in memory. <br>由于 RcBox 是 repr(C)，因此它将始终是内存中的最后一个字段。<br>
    // SAFETY: since the only unsized types possible are slices, trait objects, and extern types, the input safety requirement is currently enough to satisfy the requirements of align_of_val_raw; <br>由于唯一可能的未定义大小类型是切片，trait 对象和外部类型，因此当前输入的安全要求足以满足 align_of_val_raw 的要求；<br> this is an implementation detail of the language that must not be relied upon outside of std. <br>这是 std 之外不得依赖的语言的实现细节。<br>
    //
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}
