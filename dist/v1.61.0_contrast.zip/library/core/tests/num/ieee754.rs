//! IEEE 754 floating point compliance tests <br>IEEE 754 浮点符合性测试<br>
//!
//! To understand IEEE 754's requirements on a programming language, one must understand that the requirements of IEEE 754 rest on the total programming environment, and not entirely on any one component. <br>要了解 IEEE 754 对编程语言的要求，必须了解 IEEE 754 的要求取决于整个编程环境，而不是完全取决于任何一个组件。<br>
//! That means the hardware, language, and even libraries are considered part of conforming floating point support in a programming environment. <br>这意味着硬件、语言甚至库都被视为编程环境中符合浮点支持的一部分。<br>
//!
//! A programming language's duty, accordingly, is: <br>因此，编程语言的职责是：<br>
//!   1. offer access to the hardware where the hardware offers support <br>提供对硬件提供支持的硬件的访问<br>
//!   2. provide operations that fulfill the remaining requirements of the standard <br>提供满足标准剩余要求的操作<br>
//!   3. provide the ability to write additional software that can fulfill those requirements <br>提供编写能够满足这些需求的附加软件的能力<br>
//!
//! This may be fulfilled in any combination that the language sees fit. <br>这可以通过语言认为合适的任何组合来实现。<br> However, to claim that a language supports IEEE 754 is to suggest that it has fulfilled requirements 1 and 2, without deferring minimum requirements to libraries. <br>然而，声称一种语言支持 IEEE 754 是在暗示它已经满足了要求 1 和 2，而没有将最低要求提交给库<br>
//! This is because support for IEEE 754 is defined as complete support for at least one specified floating point type as an "arithmetic" and "interchange" format, plus specified type conversions to "external character sequences" and integer types. <br>这是因为对 IEEE 754 的支持被定义为完全支持至少一种指定的浮点类型，如算术和交换格式，以及到外部字符序列和整数类型的指定类型转换。<br>
//!
//!
//! For our purposes, "interchange format"          => f32, f64 "arithmetic format"           => f32, f64, and any "soft floats" "external character sequence" => str from any float "integer format"              => {i,u}{8,16,32,64,128} <br>出于我们的目的，"交换格式" => f32、f64 "算术格式" => f32、f64 和任何 "软浮点数" "外部字符序列" => 来自任何浮点数 "整数格式" => {i,u}{8,16,32,64,128} 的 str<br>
//!
//! None of these tests are against Rust's own implementation. <br>这些测试都不是针对 Rust 自己的实现的。<br> They are only tests against the standard. <br>它们只是针对标准的测试。<br> That is why they accept wildly diverse inputs or may seem to duplicate other tests. <br>这就是为什么他们接受各种各样的输入或似乎重复其他测试的原因。<br>
//! Please consider this carefully when adding, removing, or reorganizing these tests. <br>在添加、删除或重新组织这些测试时，请仔细考虑这一点。<br> They are here so that it is clear what tests are required by the standard and what can be changed. <br>它们在这里是为了清楚标准要求哪些测试以及可以更改哪些测试。<br>
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
use ::core::str::FromStr;

// IEEE 754 for many tests is applied to specific bit patterns. <br>许多测试的 IEEE 754 适用于特定的位模式。<br>
// These generally are not applicable to NaN, however. <br>但是，这些通常不适用于 NaN。<br>
macro_rules! assert_biteq {
    ($lhs:expr, $rhs:expr) => {
        assert_eq!($lhs.to_bits(), $rhs.to_bits())
    };
}

// ToString uses the default fmt::Display impl without special concerns, and bypasses other parts of the formatting infrastructure, which makes it ideal for testing here. <br>ToString 使用默认的 fmt::Display impl 没有特别的顾虑，并绕过格式结构体的其他部分，这使得它非常适合这里的测试。<br>
//
#[allow(unused_macros)]
macro_rules! roundtrip {
    ($f:expr => $t:ty) => {
        ($f).to_string().parse::<$t>().unwrap()
    };
}

macro_rules! assert_floats_roundtrip {
    ($f:ident) => {
        assert_biteq!(f32::$f, roundtrip!(f32::$f => f32));
        assert_biteq!(f64::$f, roundtrip!(f64::$f => f64));
    };
    ($f:expr) => {
        assert_biteq!($f as f32, roundtrip!($f => f32));
        assert_biteq!($f as f64, roundtrip!($f => f64));
    }
}

macro_rules! assert_floats_bitne {
    ($lhs:ident, $rhs:ident) => {
        assert_ne!(f32::$lhs.to_bits(), f32::$rhs.to_bits());
        assert_ne!(f64::$lhs.to_bits(), f64::$rhs.to_bits());
    };
    ($lhs:expr, $rhs:expr) => {
        assert_ne!(f32::to_bits($lhs), f32::to_bits($rhs));
        assert_ne!(f64::to_bits($lhs), f64::to_bits($rhs));
    };
}

// We must preserve signs on all numbers. <br>我们必须保留所有数字上的符号。<br> That includes zero. <br>这包括零。<br>
// -0 and 0 are == normally, so test bit equality. <br>-0 和 0 通常是 == 的，所以测试位相等。<br>
#[test]
fn preserve_signed_zero() {
    assert_floats_roundtrip!(-0.0);
    assert_floats_roundtrip!(0.0);
    assert_floats_bitne!(0.0, -0.0);
}

#[test]
fn preserve_signed_infinity() {
    assert_floats_roundtrip!(INFINITY);
    assert_floats_roundtrip!(NEG_INFINITY);
    assert_floats_bitne!(INFINITY, NEG_INFINITY);
}

#[test]
fn infinity_to_str() {
    assert!(match f32::INFINITY.to_string().to_lowercase().as_str() {
        "+infinity" | "infinity" => true,
        "+inf" | "inf" => true,
        _ => false,
    });
    assert!(
        match f64::INFINITY.to_string().to_lowercase().as_str() {
            "+infinity" | "infinity" => true,
            "+inf" | "inf" => true,
            _ => false,
        },
        "Infinity must write to a string as some casing of inf or infinity, with an optional +."
    );
}

#[test]
fn neg_infinity_to_str() {
    assert!(match f32::NEG_INFINITY.to_string().to_lowercase().as_str() {
        "-infinity" | "-inf" => true,
        _ => false,
    });
    assert!(
        match f64::NEG_INFINITY.to_string().to_lowercase().as_str() {
            "-infinity" | "-inf" => true,
            _ => false,
        },
        "Negative Infinity must write to a string as some casing of -inf or -infinity"
    )
}

#[test]
fn nan_to_str() {
    assert!(
        match f32::NAN.to_string().to_lowercase().as_str() {
            "nan" | "+nan" | "-nan" => true,
            _ => false,
        },
        "NaNs must write to a string as some casing of nan."
    )
}

// "+"?("inf"|"infinity") in any case => Infinity <br>"+"?("inf"|"infinity") 在任何情况下 => 无穷大<br>
#[test]
fn infinity_from_str() {
    assert_biteq!(f32::INFINITY, f32::from_str("infinity").unwrap());
    assert_biteq!(f32::INFINITY, f32::from_str("inf").unwrap());
    assert_biteq!(f32::INFINITY, f32::from_str("+infinity").unwrap());
    assert_biteq!(f32::INFINITY, f32::from_str("+inf").unwrap());
    // yes! this means you are weLcOmE tO mY iNfInItElY tWiStEd MiNd <br>是的。这意味着欢迎您来到我无限扭曲的心灵<br>
    assert_biteq!(f32::INFINITY, f32::from_str("+iNfInItY").unwrap());
}

// "-inf"|"-infinity" in any case => Negative Infinity <br>"-inf"|"-infinity" 在任何情况下 => 负无穷大<br>
#[test]
fn neg_infinity_from_str() {
    assert_biteq!(f32::NEG_INFINITY, f32::from_str("-infinity").unwrap());
    assert_biteq!(f32::NEG_INFINITY, f32::from_str("-inf").unwrap());
    assert_biteq!(f32::NEG_INFINITY, f32::from_str("-INF").unwrap());
    assert_biteq!(f32::NEG_INFINITY, f32::from_str("-INFinity").unwrap());
}

// ("+"|"-"")?"s"?"nan" in any case => qNaN <br>("+"|"-"")?"s"?"nan" 在任何情况下 => qNaN<br>
#[test]
fn qnan_from_str() {
    assert!("nan".parse::<f32>().unwrap().is_nan());
    assert!("-nan".parse::<f32>().unwrap().is_nan());
    assert!("+nan".parse::<f32>().unwrap().is_nan());
    assert!("+NAN".parse::<f32>().unwrap().is_nan());
    assert!("-NaN".parse::<f32>().unwrap().is_nan());
}
