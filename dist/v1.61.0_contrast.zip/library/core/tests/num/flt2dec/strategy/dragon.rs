use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri is too slow <br>Miri 太慢<br>
fn exact_sanity_test() {
    // This test ends up running what I can only assume is some corner-ish case of the `exp2` library function, defined in whatever C runtime we're using. <br>该测试最终运行的是我只能假定的 `exp2` 库函数的某种极端情况，该情况在我们使用的任何 C 运行时中都已定义。<br>
    // In VS 2013 this function apparently had a bug as this test fails when linked, but with VS 2015 the bug appears fixed as the test runs just fine. <br>在 VS 2013 中，此函数显然存在一个错误，因为该测试在链接时失败，但是在 VS 2015 中，该错误似乎已修复，因为测试运行良好。<br>
    //
    // The bug seems to be a difference in return value of `exp2(-1057)`, where in VS 2013 it returns a double with the bit pattern 0x2 and in VS 2015 it returns 0x20000. <br>该错误似乎是 `exp2(-1057)` 返回值的差异，在 VS 2013 中，它返回带有位模式 0x2 的双精度值，而在 VS 2015 中，它返回 0x20000。<br>
    //
    //
    // For now just ignore this test entirely on MSVC as it's tested elsewhere anyway and we're not super interested in testing each platform's exp2 implementation. <br>现在，只需要完全忽略 MSVC 上的此测试，因为它无论如何都已在其他地方进行了测试，我们对测试每个平台的 exp2 实现并不十分感兴趣。<br>
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}
