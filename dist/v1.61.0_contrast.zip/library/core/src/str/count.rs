//! Code for efficiently counting the number of `char`s in a UTF-8 encoded string. <br>用于有效计算 UTF-8 编码字符串中的 `char` 数量的代码。<br>
//!
//! Broadly, UTF-8 encodes `char`s as a "leading" byte which begins the `char`, followed by some number (possibly 0) of continuation bytes. <br>广义上讲，UTF-8 将 `char` 编码为一个 "leading" 字节，它以 `char` 开头，后跟一些 (可能为 0) 的连续字节。<br>
//!
//! The leading byte can have a number of bit-patterns (with the specific pattern indicating how many continuation bytes follow), but the continuation bytes are always in the format `0b10XX_XXXX` (where the `X`s can take any value). <br>前导字节可以有多个位模式 (特定的模式指示后面有多少个延续字节)，但连续字节的格式始终为 `0b10XX_XXXX` 格式 (其中 `X` 可以取任何值)。<br>
//! That is, the most significant bit is set, and the second most significant bit is unset. <br>也就是说，设置了最高有效位，未设置第二个最高有效位。<br>
//!
//! To count the number of characters, we can just count the number of bytes in the string which are not continuation bytes, which can be done many bytes at a time fairly easily. <br>为了计算字符的数量，我们可以只计算字符串中非连续字节的字节数，这可以很容易地一次计算多个字节。<br>
//!
//! Note: Because the term "leading byte" can sometimes be ambiguous (for example, it could also refer to the first byte of a slice), we'll often use the term "non-continuation byte" to refer to these bytes in the code. <br>因为术语 "leading byte" 有时可能是模棱两可的 (例如，它也可以指切片的第一个字节)，所以我们经常使用术语 "non-continuation byte" 来指代代码中的这些字节。<br>
//!
//!
//!
//!
//!
//!
//!
//!
//!
use core::intrinsics::unlikely;

const USIZE_SIZE: usize = core::mem::size_of::<usize>();
const UNROLL_INNER: usize = 4;

#[inline]
pub(super) fn count_chars(s: &str) -> usize {
    if s.len() < USIZE_SIZE * UNROLL_INNER {
        // Avoid entering the optimized implementation for strings where the difference is not likely to matter, or where it might even be slower. <br>避免输入字符串的优化实现，因为差异可能无关紧要，或者可能会更慢。<br>
        //
        // That said, a ton of thought was not spent on the particular threshold here, beyond "this value seems to make sense". <br>也就是说，除了 "这个值似乎有意义" 之外，没有花太多心思在这个特定的门槛上。<br>
        //
        char_count_general_case(s.as_bytes())
    } else {
        do_count_chars(s)
    }
}

fn do_count_chars(s: &str) -> usize {
    // For correctness, `CHUNK_SIZE` must be: <br>为了正确起见，`CHUNK_SIZE` 必须是:<br>
    //
    // - Less than or equal to 255, otherwise we'll overflow bytes in `counts`. <br>小于或等于 255，否则我们将在 `counts` 中溢出字节。<br>
    // - A multiple of `UNROLL_INNER`, otherwise our `break` inside the `body.chunks(CHUNK_SIZE)` loop is incorrect. <br>`UNROLL_INNER` 的倍数，否则我们在 `body.chunks(CHUNK_SIZE)` 循环里面的 `break` 是不正确的。<br>
    //
    //
    // For performance, `CHUNK_SIZE` should be: <br>对于性能，`CHUNK_SIZE` 应该是:<br>
    // - Relatively cheap to `/` against (so some simple sum of powers of two). <br>相对于 `/` 来说相对便宜 (所以一些简单的 2 次方之和)。<br>
    // - Large enough to avoid paying for the cost of the `sum_bytes_in_usize` too often. <br>足够大，可以避免过于频繁地支付 `sum_bytes_in_usize` 的费用。<br>
    //
    const CHUNK_SIZE: usize = 192;

    // Check the properties of `CHUNK_SIZE` and `UNROLL_INNER` that are required for correctness. <br>检查正确性所需的 `CHUNK_SIZE` 和 `UNROLL_INNER` 的属性。<br>
    //
    const _: () = assert!(CHUNK_SIZE < 256);
    const _: () = assert!(CHUNK_SIZE % UNROLL_INNER == 0);

    // SAFETY: transmuting `[u8]` to `[usize]` is safe except for size differences which are handled by `align_to`. <br>将 `[u8]` 转换为 `[usize]` 是安全的，但 `align_to` 处理的大小差异除外。<br>
    //
    let (head, body, tail) = unsafe { s.as_bytes().align_to::<usize>() };

    // This should be quite rare, and basically exists to handle the degenerate cases where align_to fails (as well as miri under symbolic alignment mode). <br>这应该是非常罕见的，并且基本上存在处理 align_to 失败的退化情况 (以及符号对齐模式下的 miri )。<br>
    //
    // The `unlikely` helps discourage LLVM from inlining the body, which is nice, as we would rather not mark the `char_count_general_case` function as cold. <br>`unlikely` 有助于阻止 LLVM 内联主体，这很好，因为我们宁愿不将 `char_count_general_case` 函数标记为冷。<br>
    //
    //
    //
    //
    if unlikely(body.is_empty() || head.len() > USIZE_SIZE || tail.len() > USIZE_SIZE) {
        return char_count_general_case(s.as_bytes());
    }

    let mut total = char_count_general_case(head) + char_count_general_case(tail);
    // Split `body` into `CHUNK_SIZE` chunks to reduce the frequency with which we call `sum_bytes_in_usize`. <br>将 `body` 拆分为 `CHUNK_SIZE` 块以减少调用 `sum_bytes_in_usize` 的频率。<br>
    //
    for chunk in body.chunks(CHUNK_SIZE) {
        // We accumulate intermediate sums in `counts`, where each byte contains a subset of the sum of this chunk, like a `[u8; size_of::<usize>()]`. <br>我们在 `counts` 中累积中间和，其中每个字节包含这个块的总和的子集，就像 `[u8; size_of::<usize>()]`。<br>
        //
        let mut counts = 0;

        let (unrolled_chunks, remainder) = chunk.as_chunks::<UNROLL_INNER>();
        for unrolled in unrolled_chunks {
            for &word in unrolled {
                // Because `CHUNK_SIZE` is < 256, this addition can't cause the count in any of the bytes to overflow into a subsequent byte. <br>因为 `CHUNK_SIZE` < 256，所以这个加法不会导致任何字节中的计数溢出到后续字节中。<br>
                //
                counts += contains_non_continuation_byte(word);
            }
        }

        // Sum the values in `counts` (which, again, is conceptually a `[u8; <br>对 `counts` 中的值求和 (同样，它在概念上是一个 `[u8;<br>
        // size_of::<usize>()]`), and accumulate the result into `total`. <br>size_of::<usize>()]`)，并将结果累加到 `total` 中。<br>
        total += sum_bytes_in_usize(counts);

        // If there's any data in `remainder`, then handle it. <br>如果 `remainder` 中有数据，则进行处理。<br>
        // This will only happen for the last `chunk` in `body.chunks()` (because `CHUNK_SIZE` is divisible by `UNROLL_INNER`), so we explicitly break at the end (which seems to help LLVM out). <br>这只会发生在 `body.chunks()` 中的最后一个 `chunk` 上 (因为 `CHUNK_SIZE` 可以被 `UNROLL_INNER` 整除)，所以我们在最后显式中断 (这似乎有助于 LLVM)。<br>
        //
        //
        if !remainder.is_empty() {
            // Accumulate all the data in the remainder. <br>将余数中的所有数据累加。<br>
            let mut counts = 0;
            for &word in remainder {
                counts += contains_non_continuation_byte(word);
            }
            total += sum_bytes_in_usize(counts);
            break;
        }
    }
    total
}

// Checks each byte of `w` to see if it contains the first byte in a UTF-8 sequence. <br>检查 `w` 的每个字节以查看它是否包含 UTF-8 序列中的第一个字节。<br>
// Bytes in `w` which are continuation bytes are left as `0x00` (e.g. <br>`w` 中作为连续字节的字节保留为 `0x00` (例如<br>
// false), and bytes which are non-continuation bytes are left as `0x01` (e.g. true) <br>false)，非连续字节的字节保留为 `0x01` (例如 true)<br>
//
#[inline]
fn contains_non_continuation_byte(w: usize) -> usize {
    const LSB: usize = 0x0101_0101_0101_0101u64 as usize;
    ((!w >> 7) | (w >> 6)) & LSB
}

// Morally equivalent to `values.to_ne_bytes().into_iter().sum::<usize>()`, but more efficient. <br>道德上相当于 `values.to_ne_bytes().into_iter().sum::<usize>()`，但效率更高。<br>
//
#[inline]
fn sum_bytes_in_usize(values: usize) -> usize {
    const LSB_SHORTS: usize = 0x0001_0001_0001_0001_u64 as usize;
    const SKIP_BYTES: usize = 0x00ff_00ff_00ff_00ff_u64 as usize;

    let pair_sum: usize = (values & SKIP_BYTES) + ((values >> 8) & SKIP_BYTES);
    pair_sum.wrapping_mul(LSB_SHORTS) >> ((USIZE_SIZE - 2) * 8)
}

// This is the most direct implementation of the concept of "count the number of bytes in the string which are not continuation bytes", and is used for the head and tail of the input string (the first and last item in the tuple returned by `slice::align_to`). <br>这是 "count the number of bytes in the string which are not continuation bytes" 概念最直接的实现，用于输入字符串的首尾 (`slice::align_to` 返回的元组中的第一个和最后一个项)。<br>
//
//
//
fn char_count_general_case(s: &[u8]) -> usize {
    s.iter().filter(|&&byte| !super::validations::utf8_is_cont_byte(byte)).count()
}
