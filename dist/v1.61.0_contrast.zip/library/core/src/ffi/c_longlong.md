Equivalent to C's `signed long long` (`long long`) type. <br>等效于 C 的 `signed long long` (`long long`) 类型。<br>

This type will almost always be [`i64`], but may differ on some systems. <br>此类型几乎总是 [`i64`]，但在某些系统上可能有所不同。<br> The C standard technically only requires that this type be a signed integer that is at least 64 bits and at least the size of a [`long`], although in practice, no system would have a `long long` that is not an `i64`, as most systems do not have a standardised [`i128`] type. <br>C 标准从技术上仅要求此类型为至少 64 位且至少为 [`long`] 大小的有符号整数，尽管实际上，没有系统会拥有不是 `long long` 的 `long long`，因为大多数系统都没有标准化的 [`i128`] 类型。<br>

[`long`]: c_int
