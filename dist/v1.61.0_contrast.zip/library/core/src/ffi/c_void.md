Equivalent to C's `void` type when used as a [pointer]. <br>当用作 [指针][pointer] 时，等效于 C 的 `void` 类型。<br>

In essence, `*const c_void` is equivalent to C's `const void*` and `*mut c_void` is equivalent to C's `void*`. <br>本质上，`*const c_void` 等效于 C 的 `const void*`，而 `*mut c_void` 等效于 C 的 `void*`。<br>
That said, this is *not* the same as C's `void` return type, which is Rust's `()` type. <br>也就是说，这与 C 的 `void` 返回类型 (即 Rust 的 `()` 类型) 不同。<br>

To model pointers to opaque types in FFI, until `extern type` is stabilized, it is recommended to use a newtype wrapper around an empty byte array. <br>要在 FFI 中对指向不透明类型的指针进行建模，直到 `extern type` 稳定为止，建议在空字节数组周围使用 newtype 包装器。<br>

See the [Nomicon] for details. <br>有关详细信息，请参见 [Nomicon]。<br>

One could use `std::os::raw::c_void` if they want to support old Rust compiler down to 1.1.0. <br>如果他们想支持低至 1.1.0 的旧 Rust 编译器，则可以使用 `std::os::raw::c_void`。<br>
After Rust 1.30.0, it was re-exported by this definition. <br>Rust 1.30.0 之后，此定义将其重导出。<br>
For more information, please read [RFC 2521]. <br>有关更多信息，请阅读 [RFC 2521]。<br>

[Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
[RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
