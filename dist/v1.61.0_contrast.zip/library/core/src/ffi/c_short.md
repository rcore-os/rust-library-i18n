Equivalent to C's `signed short` (`short`) type. <br>等效于 C 的 `signed short` (`short`) 类型。<br>

This type will almost always be [`i16`], but may differ on some esoteric systems. <br>这种类型几乎总是 [`i16`]，但在某些深奥的系统上可能有所不同。<br> The C standard technically only requires that this type be a signed integer with at least 16 bits; <br>C 标准从技术上仅要求此类型是至少 16 位的有符号整数；<br> some systems may define it as `i32`, for example. <br>例如，某些系统可能将其定义为 `i32`。<br>

[`char`]: c_char
