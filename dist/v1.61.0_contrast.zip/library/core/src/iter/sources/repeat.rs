use crate::iter::{FusedIterator, TrustedLen};

/// Creates a new iterator that endlessly repeats a single element. <br>创建一个新的迭代器，该迭代器不断重复单个元素。<br>
///
/// The `repeat()` function repeats a single value over and over again. <br>`repeat()` 函数一次又一次地重复单个值。<br>
///
/// Infinite iterators like `repeat()` are often used with adapters like [`Iterator::take()`], in order to make them finite. <br>无限迭代器 (如 `repeat()`) 通常与适配器 (如 [`Iterator::take()`]) 一起使用，以使其具有有限性。<br>
///
/// If the element type of the iterator you need does not implement `Clone`, or if you do not want to keep the repeated element in memory, you can instead use the [`repeat_with()`] function. <br>如果所需的迭代器元素类型未实现 `Clone`，或者不想将重复的元素保留在内存中，则可以改用 [`repeat_with()`] 函数。<br>
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::iter;
///
/// // the number four 4ever: <br>第四个 4ever：<br>
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, still four <br>是的，还是四个<br>
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Going finite with [`Iterator::take()`]: <br>用 [`Iterator::take()`] 进行有限化：<br>
///
/// ```
/// use std::iter;
///
/// // that last example was too many fours. <br>最后一个例子太多了。<br> Let's only have four fours. <br>我们只有四个四。<br>
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... and now we're done <br>现在我们完成了<br>
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "iter_repeat")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// An iterator that repeats an element endlessly. <br>一个无限重复元素的迭代器。<br>
///
/// This `struct` is created by the [`repeat()`] function. <br>该 `struct` 由 [`repeat()`] 函数创建。<br> See its documentation for more. <br>有关更多信息，请参见其文档。<br>
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        // Advancing an infinite iterator of a single element is a no-op. <br>推进单个元素的无限迭代器是不可行的。<br>
        let _ = n;
        Ok(())
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let _ = n;
        Some(self.element.clone())
    }

    fn last(self) -> Option<A> {
        loop {}
    }

    fn count(self) -> usize {
        loop {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }

    #[inline]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        // Advancing an infinite iterator of a single element is a no-op. <br>推进单个元素的无限迭代器是不可行的。<br>
        let _ = n;
        Ok(())
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        let _ = n;
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}
