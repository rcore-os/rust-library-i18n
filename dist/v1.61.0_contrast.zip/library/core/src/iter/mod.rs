//! Composable external iteration. <br>可组合的外部迭代。<br>
//!
//! If you've found yourself with a collection of some kind, and needed to perform an operation on the elements of said collection, you'll quickly run into 'iterators'. <br>如果您发现自己具有某种类型的集合，并且需要对所述集合的元素执行操作，那么您会很快遇到 'iterators'。<br>
//! Iterators are heavily used in idiomatic Rust code, so it's worth becoming familiar with them. <br>迭代器在惯用的 Rust 代码中大量使用，所以值得熟悉它们。<br>
//!
//! Before explaining more, let's talk about how this module is structured: <br>在解释更多内容之前，让我们讨论一下该模块的结构：<br>
//!
//! # Organization
//!
//! This module is largely organized by type: <br>该模块主要是按类型来组织的：<br>
//!
//! * [Traits] are the core portion: these traits define what kind of iterators exist and what you can do with them. <br>[Traits] 是核心部分：这些 traits 定义了存在什么样的迭代器，以及您可以用它们做什么。<br> The methods of these traits are worth putting some extra study time into. <br>这些 traits 的方法值得投入一些额外的学习时间。<br>
//! * [Functions] provide some helpful ways to create some basic iterators. <br>[Functions] 提供了一些有用的方法来创建一些基本的迭代器。<br>
//! * [Structs] are often the return types of the various methods on this module's traits. <br>[Structs] 通常是该模块的 traits 上各种方法的返回类型。<br> You'll usually want to look at the method that creates the `struct`, rather than the `struct` itself. <br>通常，您将需要查看创建 `struct` 的方法，而不是 `struct` 本身。<br>
//! For more detail about why, see '[Implementing Iterator](#implementing-iterator)'. <br>有关原因的更多详细信息，请参见 [实现迭代器](#implementing-iterator)。<br>
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! That's it! <br>就是这样！<br> Let's dig into iterators. <br>让我们深入研究迭代器。<br>
//!
//! # Iterator
//!
//! The heart and soul of this module is the [`Iterator`] trait. <br>该模块的核心是 [`Iterator`] trait。<br> The core of [`Iterator`] looks like this: <br>[`Iterator`] 的核心是这样的：<br>
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! An iterator has a method, [`next`], which when called, returns an <code>[Option]\<Item></code>. <br>迭代器有一个方法 [`next`]，当调用它时，返回一个 <code>[Option]\<Item></code>.<br>
//! Calling [`next`] will return [`Some(Item)`] as long as there are elements, and once they've all been exhausted, will return `None` to indicate that iteration is finished. <br>只要有元素，调用 [`next`] 就会返回 [`Some(Item)`]，一旦它们全部消费完，将返回 `None` 表示迭代完成。<br>
//! Individual iterators may choose to resume iteration, and so calling [`next`] again may or may not eventually start returning [`Some(Item)`] again at some point (for example, see [`TryIter`]). <br>各个迭代器可能选择恢复迭代，因此再次调用 [`next`] 可能会或可能不会最终在某个时候再次开始返回 [`Some(Item)`] (例如，请参见 [`TryIter`])。<br>
//!
//!
//! [`Iterator`]'s full definition includes a number of other methods as well, but they are default methods, built on top of [`next`], and so you get them for free. <br>[`Iterator`] 的完整定义还包括许多其他方法，但是它们是默认方法，基于 [`next`] 构建，因此您可以免费获得它们。<br>
//!
//! Iterators are also composable, and it's common to chain them together to do more complex forms of processing. <br>迭代器也是可组合的，通常将它们链接在一起以进行更复杂的处理形式。<br> See the [Adapters](#adapters) section below for more details. <br>有关更多详细信息，请参见下面的 [适配器](#adapters) 部分。<br>
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # The three forms of iteration <br>三种迭代形式<br>
//!
//! There are three common methods which can create iterators from a collection: <br>有三种常见的方法可以从集合中创建迭代器：<br>
//!
//! * `iter()`, which iterates over `&T`. <br>`iter()`，它在 `&T` 上迭代。<br>
//! * `iter_mut()`, which iterates over `&mut T`. <br>`iter_mut()`，它在 `&mut T` 上迭代。<br>
//! * `into_iter()`, which iterates over `T`. <br>`into_iter()`，它在 `T` 上迭代。<br>
//!
//! Various things in the standard library may implement one or more of the three, where appropriate. <br>在适当的情况下，标准库中的各种内容都可以实现这三个中的一个或多个。<br>
//!
//! # Implementing Iterator <br>实现迭代器<br>
//!
//! Creating an iterator of your own involves two steps: creating a `struct` to hold the iterator's state, and then implementing [`Iterator`] for that `struct`. <br>创建自己的迭代器涉及两个步骤：创建一个 `struct` 来保存迭代器的状态，然后为该 `struct` 实现 [`Iterator`]。<br>
//! This is why there are so many `struct`s in this module: there is one for each iterator and iterator adapter. <br>这就是为什么此模块中有这么多 `struct` 的原因：每个迭代器和迭代器适配器都有一个。<br>
//!
//! Let's make an iterator named `Counter` which counts from `1` to `5`: <br>让我们创建一个名为 `Counter` 的迭代器，该迭代器的范围从 `1` 到 `5`：<br>
//!
//! ```
//! // First, the struct: <br>首先，结构体：<br>
//!
//! /// An iterator which counts from one to five <br>从 1 到 5 计数的迭代器<br>
//! struct Counter {
//!     count: usize,
//! }
//!
//! // we want our count to start at one, so let's add a new() method to help. <br>我们希望计数从一开始，所以让我们添加一个 new() 方法来提供帮助。<br>
//! // This isn't strictly necessary, but is convenient. <br>这不是严格必要的，但很方便。<br>
//! // Note that we start `count` at zero, we'll see why in `next()`'s implementation below. <br>请注意，我们将 `count` 从零开始，我们将在下面的 `next () ` 实现中看到其原因。<br>
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Then, we implement `Iterator` for our `Counter`: <br>然后，我们为 `Counter` 实现 `Iterator`：<br>
//!
//! impl Iterator for Counter {
//!     // we will be counting with usize <br>我们将使用 usize 进行计数<br>
//!     type Item = usize;
//!
//!     // next() is the only required method <br>next() 是唯一必需的方法<br>
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Increment our count. <br>增加我们的数量。<br> This is why we started at zero. <br>这就是为什么我们从零开始。<br>
//!         self.count += 1;
//!
//!         // Check to see if we've finished counting or not. <br>检查我们是否已经完成计数。<br>
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // And now we can use it! <br>现在我们可以使用它了！<br>
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Calling [`next`] this way gets repetitive. <br>以这种方式调用 [`next`] 将重复进行。<br> Rust has a construct which can call [`next`] on your iterator, until it reaches `None`. <br>Rust 有一个构造，可以在迭代器上调用 [`next`]，直到它到达 `None`。<br> Let's go over that next. <br>让我们接下来讨论。<br>
//!
//! Also note that `Iterator` provides a default implementation of methods such as `nth` and `fold` which call `next` internally. <br>还要注意，`Iterator` 提供了内部调用 `next` 的方法的默认实现，例如 `nth` 和 `fold`。<br>
//! However, it is also possible to write a custom implementation of methods like `nth` and `fold` if an iterator can compute them more efficiently without calling `next`. <br>但是，如果迭代器可以在不调用 `next` 的情况下更有效地计算它们，则还可以编写方法的自定义实现，例如 `nth` 和 `fold`。<br>
//!
//! # `for` loops and `IntoIterator` <br>`for` 循环和 `IntoIterator`<br>
//!
//! Rust's `for` loop syntax is actually sugar for iterators. <br>Rust 的 `for` 循环语法实际上是迭代器的语法糖。<br> Here's a basic example of `for`: <br>这是 `for` 的一个基本示例：<br>
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{x}");
//! }
//! ```
//!
//! This will print the numbers one through five, each on their own line. <br>这将打印数字 1 到 5，每个数字都在各自的行上。<br> But you'll notice something here: we never called anything on our vector to produce an iterator. <br>但是您会在这里注意到：我们从未在 vector 上调用任何东西来产生迭代器。<br> What gives? <br>是什么给的？<br>
//!
//! There's a trait in the standard library for converting something into an iterator: [`IntoIterator`]. <br>标准库中有一个 trait 用于将某些内容转换为迭代器: [`IntoIterator`]。<br>
//! This trait has one method, [`into_iter`], which converts the thing implementing [`IntoIterator`] into an iterator. <br>这个 trait 具有一个 [`into_iter`] 方法，该方法可以将实现 [`IntoIterator`] 的类型转换为迭代器。<br>
//! Let's take a look at that `for` loop again, and what the compiler converts it into: <br>让我们再次看一下 `for` 循环，以及编译器将其转换为什么：<br>
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{x}");
//! }
//! ```
//!
//! Rust de-sugars this into: <br>Rust 将其反糖化为：<br>
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{x}"); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! First, we call `into_iter()` on the value. <br>首先，我们在值上调用 `into_iter()`。<br> Then, we match on the iterator that returns, calling [`next`] over and over until we see a `None`. <br>然后，我们在返回的迭代器上进行匹配，一遍又一遍地调用 [`next`]，直到我们看到一个 `None`。<br>
//! At that point, we `break` out of the loop, and we're done iterating. <br>到那时，我们 `break` 退出了循环，我们已经完成了迭代。<br>
//!
//! There's one more subtle bit here: the standard library contains an interesting implementation of [`IntoIterator`]: <br>这里还有一点微妙之处：标准库包含一个有趣的 [`IntoIterator`] 实现：<br>
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! In other words, all [`Iterator`]s implement [`IntoIterator`], by just returning themselves. <br>换句话说，所有 [`Iterator`] 都通过返回自身来实现 [`IntoIterator`]。<br> This means two things: <br>这意味着两件事：<br>
//!
//! 1. If you're writing an [`Iterator`], you can use it with a `for` loop. <br>如果要编写 [`Iterator`]，则可以将其与 `for` 循环一起使用。<br>
//! 2. If you're creating a collection, implementing [`IntoIterator`] for it will allow your collection to be used with the `for` loop. <br>如果要创建集合，则为其实现 [`IntoIterator`] 将使您的集合可以与 `for` 循环一起使用。<br>
//!
//! # Iterating by reference <br>通过引用进行迭代<br>
//!
//! Since [`into_iter()`] takes `self` by value, using a `for` loop to iterate over a collection consumes that collection. <br>由于 [`into_iter()`] 将 `self` 作为值，因此使用 `for` 循环遍历一个集合将消耗该集合。<br> Often, you may want to iterate over a collection without consuming it. <br>通常，您可能需要迭代一个集合而不使用它。<br>
//! Many collections offer methods that provide iterators over references, conventionally called `iter()` and `iter_mut()` respectively: <br>许多集合提供了在引用上提供迭代器的方法，通常分别称为 `iter()` 和 `iter_mut()`：<br>
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` is still owned by this function. <br>`values` 仍然属于此函数。<br>
//! ```
//!
//! If a collection type `C` provides `iter()`, it usually also implements `IntoIterator` for `&C`, with an implementation that just calls `iter()`. <br>如果集合类型 `C` 提供 `iter()`，则它通常还为 `&C` 实现 `IntoIterator`，而该实现只是调用 `iter()`。<br>
//! Likewise, a collection `C` that provides `iter_mut()` generally implements `IntoIterator` for `&mut C` by delegating to `iter_mut()`. <br>同样，提供 `iter_mut()` 的集合 `C` 通常通过委派给 `iter_mut()` 来为 `&mut C` 实现 `IntoIterator`。<br> This enables a convenient shorthand: <br>这样可以方便快捷地实现以下目的：<br>
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // same as `values.iter_mut()` <br>与 `values.iter_mut()` 相同<br>
//!     *x += 1;
//! }
//! for x in &values { // same as `values.iter()` <br>与 `values.iter()` 相同<br>
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! While many collections offer `iter()`, not all offer `iter_mut()`. <br>尽管许多集合都提供 `iter()`，但并非所有人都提供 `iter_mut()`。<br>
//! For example, mutating the keys of a [`HashSet<T>`] could put the collection into an inconsistent state if the key hashes change, so this collection only offers `iter()`. <br>例如，如果 key 的哈希发生变化，更改 [`HashSet<T>`] 的键可能会使集合处于不一致的状态，因此这个集合仅提供 `iter()`。<br>
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//!
//! # Adapters
//!
//! Functions which take an [`Iterator`] and return another [`Iterator`] are often called 'iterator adapters', as they're a form of the 'adapter pattern'. <br>接受一个 [`Iterator`] 并返回另一个 [`Iterator`] 的函数通常被称为迭代器适配器，因为它们是适配器模式的一种形式。<br>
//!
//! Common iterator adapters include [`map`], [`take`], and [`filter`]. <br>常见的迭代器适配器包括 [`map`]，[`take`] 和 [`filter`]。<br>
//! For more, see their documentation. <br>有关更多信息，请参见它们的文档。<br>
//!
//! If an iterator adapter panics, the iterator will be in an unspecified (but memory safe) state. <br>如果迭代器适配器为 panics，则迭代器将处于未指定 (但内存安全) 状态。<br>
//! This state is also not guaranteed to stay the same across versions of Rust, so you should avoid relying on the exact values returned by an iterator which panicked. <br>也不能保证此状态在 Rust 的各个版本中都保持不变，因此您应避免依赖 panicked 的迭代器返回的确切值。<br>
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (and iterator [adapters](#adapters)) are *lazy*. <br>迭代器 (和迭代器 [适配器](#adapters)) 是懒惰的)。<br> This means that just creating an iterator doesn't _do_ a whole lot. <br>这意味着仅仅创建一个迭代器并不会做很多事情。<br> Nothing really happens until you call [`next`]. <br>除非您调用 [`next`]，否则什么都不会发生。<br>
//! This is sometimes a source of confusion when creating an iterator solely for its side effects. <br>当创建仅出于其副作用的迭代器时，这有时会引起混乱。<br>
//! For example, the [`map`] method calls a closure on each element it iterates over: <br>例如，[`map`] 方法在其迭代的每个元素上调用一个闭包：<br>
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{x}"));
//! ```
//!
//! This will not print any values, as we only created an iterator, rather than using it. <br>这将不会打印任何值，因为我们只是创建了一个迭代器，而不是使用它。<br> The compiler will warn us about this kind of behavior: <br>编译器将警告我们这种行为：<br>
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! The idiomatic way to write a [`map`] for its side effects is to use a `for` loop or call the [`for_each`] method: <br>编写 [`map`] 的副作用的惯用方式是使用 `for` 循环或调用 [`for_each`] 方法：<br>
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{x}"));
//! // or
//! for x in &v {
//!     println!("{x}");
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Another common way to evaluate an iterator is to use the [`collect`] method to produce a new collection. <br>评估迭代器的另一种常见方法是使用 [`collect`] 方法来生成新的集合。<br>
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators do not have to be finite. <br>迭代器不必一定是有限的。<br> As an example, an open-ended range is an infinite iterator: <br>例如，开放式范围是一个无限迭代器：<br>
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! It is common to use the [`take`] iterator adapter to turn an infinite iterator into a finite one: <br>通常使用 [`take`] 迭代器适配器将无限迭代器转换为有限迭代器：<br>
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{number}");
//! }
//! ```
//!
//! This will print the numbers `0` through `4`, each on their own line. <br>这将在各自的行上打印数字 `0` 至 `4`。<br>
//!
//! Bear in mind that methods on infinite iterators, even those for which a result can be determined mathematically in finite time, might not terminate. <br>请记住，无限迭代器上的方法，即使是可以在有限时间内通过数学方法确定结果的方法，也可能不会终止。<br>
//! Specifically, methods such as [`min`], which in the general case require traversing every element in the iterator, are likely not to return successfully for any infinite iterators. <br>具体来说，通常需要遍历迭代器中每个元素的方法 (如 [`min`]) 对于任何无限迭代器都可能不会成功返回。<br>
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh no! <br>不好了！<br> An infinite loop! <br>无限循环！<br>
//! // `ones.min()` causes an infinite loop, so we won't reach this point! <br>`ones.min()` 会导致无限循环，所以我们不会达到这一点！<br>
//! println!("The smallest number one is {least}.");
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[unstable(feature = "trusted_step", issue = "85731")]
pub use self::traits::TrustedStep;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_zip", since = "1.59.0")]
pub use self::adapters::zip;
#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[stable(feature = "iter_map_while", since = "1.57.0")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccessNoCoerce;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::{try_process, ByRefSized};

mod adapters;
mod range;
mod sources;
mod traits;
