use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::num::NonZeroUsize;
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` but non-zero and covariant. <br>`*mut T` 但是非零且协变。<br>
///
/// This is often the correct thing to use when building data structures using raw pointers, but is ultimately more dangerous to use because of its additional properties. <br>在使用裸指针构建数据结构时，这通常是正确的选择，但由于其额外的属性，最终使用起来更加危险。<br> If you're not sure if you should use `NonNull<T>`, just use `*mut T`! <br>如果不确定是否应使用 `NonNull<T>`，请使用 `*mut T`!<br>
///
/// Unlike `*mut T`, the pointer must always be non-null, even if the pointer is never dereferenced. <br>与 `*mut T` 不同，即使从未解引用指针，指针也必须始终为非 null。<br> This is so that enums may use this forbidden value as a discriminant -- `Option<NonNull<T>>` has the same size as `*mut T`. <br>这样一来，枚举就可以将此禁止值用作判别式 - `Option<NonNull<T>>` 与 `*mut T` 具有相同的大小。<br>
/// However the pointer may still dangle if it isn't dereferenced. <br>但是，如果指针未解引用，它可能仍会悬垂。<br>
///
/// Unlike `*mut T`, `NonNull<T>` was chosen to be covariant over `T`. <br>与 `*mut T` 不同，选择 `NonNull<T>` 作为 `T` 的协变。<br> This makes it possible to use `NonNull<T>` when building covariant types, but introduces the risk of unsoundness if used in a type that shouldn't actually be covariant. <br>这样就可以在构建协变类型时使用 `NonNull<T>`，但是如果在实际上不应该协变的类型中使用，则会带来不健全的风险。<br>
/// (The opposite choice was made for `*mut T` even though technically the unsoundness could only be caused by calling unsafe functions.) <br>(尽管从技术上讲，不健全只能由调用不安全的函数引起，但对于 `*mut T` 却做出了相反的选择。)<br>
///
/// Covariance is correct for most safe abstractions, such as `Box`, `Rc`, `Arc`, `Vec`, and `LinkedList`. <br>对于大多数安全抽象，例如 `Box`，`Rc`，`Arc`，`Vec` 和 `LinkedList`，协方差是正确的。<br> This is the case because they provide a public API that follows the normal shared XOR mutable rules of Rust. <br>之所以如此，是因为它们提供了遵循 Rust 的常规共享 XOR 可变规则的公共 API。<br>
///
/// If your type cannot safely be covariant, you must ensure it contains some additional field to provide invariance. <br>如果您的类型不能安全地协变，则必须确保它包含一些附加字段以提供不变性。<br> Often this field will be a [`PhantomData`] type like `PhantomData<Cell<T>>` or `PhantomData<&'a mut T>`. <br>通常，此字段是 [`PhantomData`] 类型，例如 `PhantomData<Cell<T>>` 或 `PhantomData<&'a mut T>`。<br>
///
/// Notice that `NonNull<T>` has a `From` instance for `&T`. <br>请注意，`NonNull<T>` 具有 `&T` 的 `From` 实例。<br> However, this does not change the fact that mutating through a (pointer derived from a) shared reference is undefined behavior unless the mutation happens inside an [`UnsafeCell<T>`]. <br>但是，这不会改变以下事实：除非通过 [`UnsafeCell<T>`] 内部发生可变的，否则通过 (从 a 派生的指针) 进行共享引用的可变的是未定义的行为。<br> The same goes for creating a mutable reference from a shared reference. <br>从共享引用创建变量引用也是如此。<br>
///
/// When using this `From` instance without an `UnsafeCell<T>`, it is your responsibility to ensure that `as_mut` is never called, and `as_ptr` is never used for mutation. <br>当使用不带 `UnsafeCell<T>` 的 `From` 实例时，您有责任确保从不调用 `as_mut`，并且从不使用 `as_ptr` 进行可变的。<br>
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pointers are not `Send` because the data they reference may be aliased. <br>`NonNull` 指针不是 `Send`，因为它们引用的数据可能是别名。<br>
// N.B., this impl is unnecessary, but should provide better error messages. <br>注意，此暗示不是必需的，但应提供更好的错误消息。<br>
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pointers are not `Sync` because the data they reference may be aliased. <br>`NonNull` 指针不是 `Sync`，因为它们引用的数据可能是别名。<br>
// N.B., this impl is unnecessary, but should provide better error messages. <br>注意，此暗示不是必需的，但应提供更好的错误消息。<br>
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Creates a new `NonNull` that is dangling, but well-aligned. <br>创建一个悬垂但对齐良好的新 `NonNull`。<br>
    ///
    /// This is useful for initializing types which lazily allocate, like `Vec::new` does. <br>与 `Vec::new` 一样，这对于初始化延迟分配的类型很有用。<br>
    ///
    /// Note that the pointer value may potentially represent a valid pointer to a `T`, which means this must not be used as a "not yet initialized" sentinel value. <br>请注意，该指针值可能表示一个指向 `T` 的有效指针，这意味着不得将其用作 "尚未初始化" 标记值。<br>
    /// Types that lazily allocate must track initialization by some other means. <br>延迟分配的类型必须通过其他某种方式来跟踪初始化。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr::NonNull;
    ///
    /// let ptr = NonNull::<u32>::dangling();
    /// // Important: don't try to access the value of `ptr` without initializing it first! <br>重要提示：不要尝试访问 `ptr` 的值而不先初始化它！<br> The pointer is not null but isn't valid either! <br>指针不为空，但也无效！<br>
    /////
    /// ```
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.36.0")]
    #[must_use]
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() returns a non-zero usize which is then casted to a *mut T. <br>mem::align_of () 返回一个非零的 usize，然后将其强制转换为 *mut T。<br>
        // Therefore, `ptr` is not null and the conditions for calling new_unchecked() are respected. <br>因此，`ptr` 不为空，并且遵守了调用 new_unchecked() 的条件。<br>
        //
        unsafe {
            let ptr = crate::ptr::invalid_mut::<T>(mem::align_of::<T>());
            NonNull::new_unchecked(ptr)
        }
    }

    /// Returns a shared references to the value. <br>返回该值的共享引用。<br> In contrast to [`as_ref`], this does not require that the value has to be initialized. <br>与 [`as_ref`] 相比，这不需要将该值初始化。<br>
    ///
    /// For the mutable counterpart see [`as_uninit_mut`]. <br>对于可变的对应物，请参见 [`as_uninit_mut`]。<br>
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that all of the following is true: <br>调用此方法时，必须确保满足以下所有条件：<br>
    ///
    /// * The pointer must be properly aligned. <br>指针必须正确对齐。<br>
    ///
    /// * It must be "dereferenceable" in the sense defined in [the module documentation]. <br>在 [模块的文档][the module documentation] 中定义的含义上，它必须是 "dereferenceable"。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get mutated (except inside `UnsafeCell`). <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能被可变的 (`UnsafeCell` 内部除外)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[must_use]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    pub const unsafe fn as_uninit_ref<'a>(&self) -> &'a MaybeUninit<T> {
        // SAFETY: the caller must guarantee that `self` meets all the requirements for a reference. <br>调用者必须保证 `self` 满足引用的所有要求。<br>
        //
        unsafe { &*self.cast().as_ptr() }
    }

    /// Returns a unique references to the value. <br>返回该值的唯一引用。<br> In contrast to [`as_mut`], this does not require that the value has to be initialized. <br>与 [`as_mut`] 相比，这不需要将该值初始化。<br>
    ///
    /// For the shared counterpart see [`as_uninit_ref`]. <br>有关共享副本，请参见 [`as_uninit_ref`]。<br>
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that all of the following is true: <br>调用此方法时，必须确保满足以下所有条件：<br>
    ///
    /// * The pointer must be properly aligned. <br>指针必须正确对齐。<br>
    ///
    /// * It must be "dereferenceable" in the sense defined in [the module documentation]. <br>在 [模块的文档][the module documentation] 中定义的含义上，它必须是 "dereferenceable"。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get accessed (read or written) through any other pointer. <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能通过任何其他指针进行访问 (读取或写入)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[must_use]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    pub const unsafe fn as_uninit_mut<'a>(&mut self) -> &'a mut MaybeUninit<T> {
        // SAFETY: the caller must guarantee that `self` meets all the requirements for a reference. <br>调用者必须保证 `self` 满足引用的所有要求。<br>
        //
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Creates a new `NonNull`. <br>创建一个新的 `NonNull`。<br>
    ///
    /// # Safety
    ///
    /// `ptr` must be non-null. <br>`ptr` 必须不能为空。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr::NonNull;
    ///
    /// let mut x = 0u32;
    /// let ptr = unsafe { NonNull::new_unchecked(&mut x as *mut _) };
    /// ```
    ///
    /// *Incorrect* usage of this function: <br>此函数的不正确用法：<br>
    ///
    /// ```rust,no_run
    /// use std::ptr::NonNull;
    ///
    /// // NEVER DO THAT!!! <br>永远不要这样做！! !<br> This is undefined behavior. <br>这是未定义的行为。<br> ⚠️
    /// let ptr = unsafe { NonNull::<u32>::new_unchecked(std::ptr::null_mut()) };
    /// ```
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.25.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: the caller must guarantee that `ptr` is non-null. <br>调用者必须保证 `ptr` 不为空。<br>
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Creates a new `NonNull` if `ptr` is non-null. <br>如果 `ptr` 不为空，则创建一个新的 `NonNull`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr::NonNull;
    ///
    /// let mut x = 0u32;
    /// let ptr = NonNull::<u32>::new(&mut x as *mut _).expect("ptr is null!");
    ///
    /// if let Some(ptr) = NonNull::<u32>::new(std::ptr::null_mut()) {
    ///     unreachable!();
    /// }
    /// ```
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_unstable(feature = "const_nonnull_new", issue = "93235")]
    #[inline]
    pub const fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: The pointer is already checked and is not null <br>指针已被检查并且不为 null<br>
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Performs the same functionality as [`std::ptr::from_raw_parts`], except that a `NonNull` pointer is returned, as opposed to a raw `*const` pointer. <br>执行与 [`std::ptr::from_raw_parts`] 相同的功能，除了返回 `NonNull` 指针 (与原始 `*const` 指针相反)。<br>
    ///
    ///
    /// See the documentation of [`std::ptr::from_raw_parts`] for more details. <br>有关更多详细信息，请参见 [`std::ptr::from_raw_parts`] 的文档。<br>
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SAFETY: The result of `ptr::from::raw_parts_mut` is non-null because `data_address` is. <br>`ptr::from::raw_parts_mut` 的结果为非空值，因为 `data_address` 为非。<br>
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Decompose a (possibly wide) pointer into its address and metadata components. <br>将指针 (可能是宽指针) 分解为其地址和元数据组件。<br>
    ///
    /// The pointer can be later reconstructed with [`NonNull::from_raw_parts`]. <br>以后可以使用 [`NonNull::from_raw_parts`] 重建指针。<br>
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Gets the "address" portion of the pointer. <br>获取指针的 "address" 部分。<br>
    ///
    /// This API and its claimed semantics are part of the Strict Provenance experiment, see the [module documentation][crate::ptr] for details. <br>此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。<br>
    ///
    #[must_use]
    #[inline]
    #[unstable(feature = "strict_provenance", issue = "95228")]
    pub fn addr(self) -> NonZeroUsize
    where
        T: Sized,
    {
        // SAFETY: The pointer is guaranteed by the type to be non-null, meaning that the address will be non-zero. <br>指针由类型保证为非空，这意味着地址将非零。<br>
        //
        unsafe { NonZeroUsize::new_unchecked(self.pointer.addr()) }
    }

    /// Creates a new pointer with the given address. <br>使用给定地址创建一个新指针。<br>
    ///
    /// This API and its claimed semantics are part of the Strict Provenance experiment, see the [module documentation][crate::ptr] for details. <br>此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。<br>
    ///
    #[must_use]
    #[inline]
    #[unstable(feature = "strict_provenance", issue = "95228")]
    pub fn with_addr(self, addr: NonZeroUsize) -> Self
    where
        T: Sized,
    {
        // SAFETY: The result of `ptr::from::with_addr` is non-null because `addr` is guaranteed to be non-zero. <br>`ptr::from::with_addr` 的结果是非空的，因为 `addr` 保证非零。<br>
        unsafe { NonNull::new_unchecked(self.pointer.with_addr(addr.get()) as *mut _) }
    }

    /// Creates a new pointer by mapping `self`'s address to a new one. <br>通过将 `self` 的地址映射到新地址来创建新指针。<br>
    ///
    /// This is a convenience for [`with_addr`][Self::with_addr], see that method for details. <br>这对 [`with_addr`][Self::with_addr] 来说是一种方便，详见该方法。<br>
    ///
    /// This API and its claimed semantics are part of the Strict Provenance experiment, see the [module documentation][crate::ptr] for details. <br>此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。<br>
    ///
    #[must_use]
    #[inline]
    #[unstable(feature = "strict_provenance", issue = "95228")]
    pub fn map_addr(self, f: impl FnOnce(NonZeroUsize) -> NonZeroUsize) -> Self
    where
        T: Sized,
    {
        self.with_addr(f(self.addr()))
    }

    /// Acquires the underlying `*mut` pointer. <br>获取底层的 `*mut` 指针。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr::NonNull;
    ///
    /// let mut x = 0u32;
    /// let ptr = NonNull::new(&mut x).expect("ptr is null!");
    ///
    /// let x_value = unsafe { *ptr.as_ptr() };
    /// assert_eq!(x_value, 0);
    ///
    /// unsafe { *ptr.as_ptr() += 2; }
    /// let x_value = unsafe { *ptr.as_ptr() };
    /// assert_eq!(x_value, 2);
    /// ```
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[must_use]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Returns a shared reference to the value. <br>返回该值的共享引用。<br> If the value may be uninitialized, [`as_uninit_ref`] must be used instead. <br>如果该值可能未初始化，则必须改用 [`as_uninit_ref`]。<br>
    ///
    /// For the mutable counterpart see [`as_mut`]. <br>对于可变的对应物，请参见 [`as_mut`]。<br>
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that all of the following is true: <br>调用此方法时，必须确保满足以下所有条件：<br>
    ///
    /// * The pointer must be properly aligned. <br>指针必须正确对齐。<br>
    ///
    /// * It must be "dereferenceable" in the sense defined in [the module documentation]. <br>在 [模块的文档][the module documentation] 中定义的含义上，它必须是 "dereferenceable"。<br>
    ///
    /// * The pointer must point to an initialized instance of `T`. <br>指针必须指向 `T` 的初始化实例。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get mutated (except inside `UnsafeCell`). <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能被可变的 (`UnsafeCell` 内部除外)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    /// (The part about being initialized is not yet fully decided, but until it is, the only safe approach is to ensure that they are indeed initialized.) <br>(关于初始化的部分尚未完全决定，但是直到确定之前，唯一安全的方法是确保它们确实被初始化。)<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr::NonNull;
    ///
    /// let mut x = 0u32;
    /// let ptr = NonNull::new(&mut x as *mut _).expect("ptr is null!");
    ///
    /// let ref_x = unsafe { ptr.as_ref() };
    /// println!("{ref_x}");
    /// ```
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    #[must_use]
    #[inline]
    pub const unsafe fn as_ref<'a>(&self) -> &'a T {
        // SAFETY: the caller must guarantee that `self` meets all the requirements for a reference. <br>调用者必须保证 `self` 满足引用的所有要求。<br>
        //
        unsafe { &*self.as_ptr() }
    }

    /// Returns a unique reference to the value. <br>返回该值的唯一引用。<br> If the value may be uninitialized, [`as_uninit_mut`] must be used instead. <br>如果该值可能未初始化，则必须改用 [`as_uninit_mut`]。<br>
    ///
    /// For the shared counterpart see [`as_ref`]. <br>有关共享副本，请参见 [`as_ref`]。<br>
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that all of the following is true: <br>调用此方法时，必须确保满足以下所有条件：<br>
    ///
    /// * The pointer must be properly aligned. <br>指针必须正确对齐。<br>
    ///
    /// * It must be "dereferenceable" in the sense defined in [the module documentation]. <br>在 [模块的文档][the module documentation] 中定义的含义上，它必须是 "dereferenceable"。<br>
    ///
    /// * The pointer must point to an initialized instance of `T`. <br>指针必须指向 `T` 的初始化实例。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get accessed (read or written) through any other pointer. <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能通过任何其他指针进行访问 (读取或写入)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    /// (The part about being initialized is not yet fully decided, but until it is, the only safe approach is to ensure that they are indeed initialized.) <br>(关于初始化的部分尚未完全决定，但是直到确定之前，唯一安全的方法是确保它们确实被初始化。)<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr::NonNull;
    ///
    /// let mut x = 0u32;
    /// let mut ptr = NonNull::new(&mut x).expect("null pointer");
    ///
    /// let x_ref = unsafe { ptr.as_mut() };
    /// assert_eq!(*x_ref, 0);
    /// *x_ref += 2;
    /// assert_eq!(*x_ref, 2);
    /// ```
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    #[must_use]
    #[inline]
    pub const unsafe fn as_mut<'a>(&mut self) -> &'a mut T {
        // SAFETY: the caller must guarantee that `self` meets all the requirements for a mutable reference. <br>调用者必须保证 `self` 满足可变引用的所有要求。<br>
        //
        unsafe { &mut *self.as_ptr() }
    }

    /// Casts to a pointer of another type. <br>强制转换为另一种类型的指针。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr::NonNull;
    ///
    /// let mut x = 0u32;
    /// let ptr = NonNull::new(&mut x as *mut _).expect("null pointer");
    ///
    /// let casted_ptr = ptr.cast::<i8>();
    /// let raw_ptr: *mut i8 = casted_ptr.as_ptr();
    /// ```
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.36.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAFETY: `self` is a `NonNull` pointer which is necessarily non-null <br>`self` 是一个 `NonNull` 指针，该指针必须非空<br>
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Creates a non-null raw slice from a thin pointer and a length. <br>根据细指针和长度创建非空的原始切片。<br>
    ///
    /// The `len` argument is the number of **elements**, not the number of bytes. <br>`len` 参数是 **元素** 的数量，而不是字节数。<br>
    ///
    /// This function is safe, but dereferencing the return value is unsafe. <br>此函数是安全的，但解引用的返回值不安全。<br>
    /// See the documentation of [`slice::from_raw_parts`] for slice safety requirements. <br>有关切片的安全要求，请参见 [`slice::from_raw_parts`] 的文档。<br>
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // create a slice pointer when starting out with a pointer to the first element <br>从指向第一个元素的指针开始创建切片指针<br>
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Note that this example artificially demonstrates a use of this method, but `let slice = NonNull::from(&x[..]);` would be a better way to write code like this.) <br>(请注意，此示例人为地演示了此方法的用法，但是 `let slice = NonNull::from(&x[..]);` 是编写这样的代码的更好方法。)<br>
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[must_use]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAFETY: `data` is a `NonNull` pointer which is necessarily non-null <br>`data` 是一个 `NonNull` 指针，该指针必须非空<br>
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Returns the length of a non-null raw slice. <br>返回非空原始切片的长度。<br>
    ///
    /// The returned value is the number of **elements**, not the number of bytes. <br>返回的值是 **元素** 的数量，而不是字节数。<br>
    ///
    /// This function is safe, even when the non-null raw slice cannot be dereferenced to a slice because the pointer does not have a valid address. <br>即使由于指针没有有效地址而无法将非空原始切片重新引用到切片时，此函数也是安全的。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[must_use]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Returns a non-null pointer to the slice's buffer. <br>返回指向切片缓冲区的非 null 指针。<br>
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::<i8>::dangling());
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAFETY: We know `self` is non-null. <br>我们知道 `self` 不为空。<br>
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Returns a raw pointer to the slice's buffer. <br>将裸指针返回到切片的缓冲区。<br>
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), NonNull::<i8>::dangling().as_ptr());
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Returns a shared reference to a slice of possibly uninitialized values. <br>返回对可能未初始化的值的切片的共享引用。<br> In contrast to [`as_ref`], this does not require that the value has to be initialized. <br>与 [`as_ref`] 相比，这不需要将该值初始化。<br>
    ///
    /// For the mutable counterpart see [`as_uninit_slice_mut`]. <br>对于可变的对应物，请参见 [`as_uninit_slice_mut`]。<br>
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that all of the following is true: <br>调用此方法时，必须确保满足以下所有条件：<br>
    ///
    /// * The pointer must be [valid] for reads for `ptr.len() * mem::size_of::<T>()` many bytes, and it must be properly aligned. <br>指针必须为 [有效][valid] 的，才能读取许多字节的 `ptr.len() * mem::size_of::<T>()`，并且必须正确对齐。<br> This means in particular: <br>这尤其意味着：<br>
    ///
    ///     * The entire memory range of this slice must be contained within a single allocated object! <br>该切片的整个存储范围必须包含在一个分配的对象中！<br>
    ///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br>
    ///
    ///     * The pointer must be aligned even for zero-length slices. <br>即使对于零长度的切片，指针也必须对齐。<br>
    ///     One reason for this is that enum layout optimizations may rely on references (including slices of any length) being aligned and non-null to distinguish them from other data. <br>这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。<br>
    ///
    ///     You can obtain a pointer that is usable as `data` for zero-length slices using [`NonNull::dangling()`]. <br>您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。<br>
    ///
    /// * The total size `ptr.len() * mem::size_of::<T>()` of the slice must be no larger than `isize::MAX`. <br>切片的总大小 `ptr.len() * mem::size_of::<T>()` 不能大于 `isize::MAX`。<br>
    ///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get mutated (except inside `UnsafeCell`). <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能被可变的 (`UnsafeCell` 内部除外)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    ///
    /// See also [`slice::from_raw_parts`]. <br>另请参见 [`slice::from_raw_parts`]。<br>
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[must_use]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    pub const unsafe fn as_uninit_slice<'a>(&self) -> &'a [MaybeUninit<T>] {
        // SAFETY: the caller must uphold the safety contract for `as_uninit_slice`. <br>调用者必须遵守 `as_uninit_slice` 的安全保证。<br>
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Returns a unique reference to a slice of possibly uninitialized values. <br>返回可能未初始化值的切片的唯一引用。<br> In contrast to [`as_mut`], this does not require that the value has to be initialized. <br>与 [`as_mut`] 相比，这不需要将该值初始化。<br>
    ///
    /// For the shared counterpart see [`as_uninit_slice`]. <br>有关共享副本，请参见 [`as_uninit_slice`]。<br>
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that all of the following is true: <br>调用此方法时，必须确保满足以下所有条件：<br>
    ///
    /// * The pointer must be [valid] for reads and writes for `ptr.len() * mem::size_of::<T>()` many bytes, and it must be properly aligned. <br>指针必须是 [有效][valid] 的才能进行 `ptr.len() * mem::size_of::<T>()` 多个字节的读取和写入，并且必须正确对齐。<br> This means in particular: <br>这尤其意味着：<br>
    ///
    ///     * The entire memory range of this slice must be contained within a single allocated object! <br>该切片的整个存储范围必须包含在一个分配的对象中！<br>
    ///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br>
    ///
    ///     * The pointer must be aligned even for zero-length slices. <br>即使对于零长度的切片，指针也必须对齐。<br>
    ///     One reason for this is that enum layout optimizations may rely on references (including slices of any length) being aligned and non-null to distinguish them from other data. <br>这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。<br>
    ///
    ///     You can obtain a pointer that is usable as `data` for zero-length slices using [`NonNull::dangling()`]. <br>您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。<br>
    ///
    /// * The total size `ptr.len() * mem::size_of::<T>()` of the slice must be no larger than `isize::MAX`. <br>切片的总大小 `ptr.len() * mem::size_of::<T>()` 不能大于 `isize::MAX`。<br>
    ///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get accessed (read or written) through any other pointer. <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能通过任何其他指针进行访问 (读取或写入)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    ///
    /// See also [`slice::from_raw_parts_mut`]. <br>另请参见 [`slice::from_raw_parts_mut`]。<br>
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // This is safe as `memory` is valid for reads and writes for `memory.len()` many bytes. <br>这是安全的，因为 `memory` 对于许多字节的 `memory.len()` 读和写有效。<br>
    /// // Note that calling `memory.as_mut()` is not allowed here as the content may be uninitialized. <br>请注意，此处不允许调用 `memory.as_mut()`，因为内容可能未初始化。<br>
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[must_use]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    pub const unsafe fn as_uninit_slice_mut<'a>(&self) -> &'a mut [MaybeUninit<T>] {
        // SAFETY: the caller must uphold the safety contract for `as_uninit_slice_mut`. <br>调用者必须遵守 `as_uninit_slice_mut` 的安全保证。<br>
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Returns a raw pointer to an element or subslice, without doing bounds checking. <br>将裸指针返回到元素或子切片，而不进行边界检查。<br>
    ///
    /// Calling this method with an out-of-bounds index or when `self` is not dereferenceable is *[undefined behavior]* even if the resulting pointer is not used. <br>使用越界索引或当 `self` 不可解引用时调用此方法是 *[未定义行为][undefined behavior]*，即使未使用结果指针。<br>
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
    #[inline]
    pub const unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: ~const SliceIndex<[T]>,
    {
        // SAFETY: the caller ensures that `self` is dereferenceable and `index` in-bounds. <br>调用者确保 `self` 是可解引用的，并且 `index` 在边界内。<br>
        // As a consequence, the resulting pointer cannot be null. <br>因此，得到的指针不能为空。<br>
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
#[rustc_const_unstable(feature = "const_clone", issue = "91805")]
impl<T: ?Sized> const Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T: ?Sized> const From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SAFETY: A Unique pointer cannot be null, so the conditions for new_unchecked() are respected. <br>唯一指针不能为空，因此必须遵守 new_unchecked() 的条件。<br>
        //
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T: ?Sized> const From<&mut T> for NonNull<T> {
    /// Converts a `&mut T` to a `NonNull<T>`. <br>将 `&mut T` 转换为 `NonNull<T>`。<br>
    ///
    /// This conversion is safe and infallible since references cannot be null. <br>这种转换是安全且可靠的，因为引用不能为空。<br>
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: A mutable reference cannot be null. <br>可变引用不能为空。<br>
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T: ?Sized> const From<&T> for NonNull<T> {
    /// Converts a `&T` to a `NonNull<T>`. <br>将 `&T` 转换为 `NonNull<T>`。<br>
    ///
    /// This conversion is safe and infallible since references cannot be null. <br>这种转换是安全且可靠的，因为引用不能为空。<br>
    #[inline]
    fn from(reference: &T) -> Self {
        // SAFETY: A reference cannot be null, so the conditions for new_unchecked() are respected. <br>引用不能为空，因此必须遵守 new_unchecked() 的条件。<br>
        //
        unsafe { NonNull { pointer: reference as *const T } }
    }
}
