//! Manually manage memory through raw pointers. <br>通过裸指针手动管理内存。<br>
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Many functions in this module take raw pointers as arguments and read from or write to them. <br>该模块中的许多函数都将裸指针作为参数，并对其进行读取或写入。<br> For this to be safe, these pointers must be *valid*. <br>为了安全起见，这些指针必须是 *valid*。<br>
//! Whether a pointer is valid depends on the operation it is used for (read or write), and the extent of the memory that is accessed (i.e., how many bytes are read/written). <br>指针是否有效取决于指针用于 (读或写) 的操作以及所访问的内存范围 (即 read/written 多少个字节)。<br> Most functions use `*mut T` and `*const T` to access only a single value, in which case the documentation omits the size and implicitly assumes it to be `size_of::<T>()` bytes. <br>大多数函数使用 `*mut T` 和 `*const T` 来访问单个值，在这种情况下，文档将忽略该大小，并隐式地假定其为 `size_of::<T>()` 字节。<br>
//!
//! The precise rules for validity are not determined yet. <br>有效性的确切规则尚未确定。<br> The guarantees that are provided at this point are very minimal: <br>此时提供的保证非常小：<br>
//!
//! * A [null] pointer is *never* valid, not even for accesses of [size zero][zst]. <br>[null] 指针从来都是无效的，甚至对于 [大小为零][zst] 的访问也是无效的。<br>
//! * For a pointer to be valid, it is necessary, but not always sufficient, that the pointer be *dereferenceable*: the memory range of the given size starting at the pointer must all be within the bounds of a single allocated object. <br>为了使指针有效，有必要 (但并不总是足够) 使指针 *可引用*: 从指针开始的给定大小的内存范围必须全部在单个已分配对象的范围内。<br>
//! Note that in Rust, every (stack-allocated) variable is considered a separate allocated object. <br>请注意，在 Rust 中，每个 (stack-allocated) 变量都被视为一个单独的分配对象。<br>
//! * Even for operations of [size zero][zst], the pointer must not be pointing to deallocated memory, i.e., deallocation makes pointers invalid even for zero-sized operations. <br>即使对于 [大小为零][zst] 的操作，指针也不得指向已释放的内存，即，即使对于大小为零的操作，释放也会使指针无效。<br>
//! However, casting any non-zero integer *literal* to a pointer is valid for zero-sized accesses, even if some memory happens to exist at that address and gets deallocated. <br>但是，将任何非零整数 *字面量* 强制转换为指针对于零大小的访问都是有效的，即使该地址恰好存在一些内存并被释放了。<br> This corresponds to writing your own allocator: allocating zero-sized objects is not very hard. <br>这相当于编写自己的分配器：分配零大小的对象不是很困难。<br> The canonical way to obtain a pointer that is valid for zero-sized accesses is [`NonNull::dangling`]. <br>获得对零大小访问有效的指针的规范方法是 [`NonNull::dangling`]。<br>
//! * All accesses performed by functions in this module are *non-atomic* in the sense of [atomic operations] used to synchronize between threads. <br>在用于在线程之间同步的 [原子操作][atomic operations] 的意义上，此模块中的函数执行的所有访问都是非原子的。<br> This means it is undefined behavior to perform two concurrent accesses to the same location from different threads unless both accesses only read from memory. <br>这意味着从两个不同的线程对同一位置执行两次并发访问是一种未定义的行为，除非两个访问均仅从内存中读取。<br>
//! Notice that this explicitly includes [`read_volatile`] and [`write_volatile`]: Volatile accesses cannot be used for inter-thread synchronization. <br>请注意，这明确包含 [`read_volatile`] 和 [`write_volatile`]: 易失性访问不能用于线程间同步。<br>
//! * The result of casting a reference to a pointer is valid for as long as the underlying object is live and no reference (just raw pointers) is used to access the same memory. <br>只要底层对象处于活动状态，并且不使用引用 (仅仅是裸指针) 来访问同一内存，则转换对指针的引用的结果就是有效的。<br>
//!
//! These axioms, along with careful use of [`offset`] for pointer arithmetic, are enough to correctly implement many useful things in unsafe code. <br>这些公理，以及仔细地使用 [`offset`] 进行指针运算，足以在不安全的代码中正确实现许多有用的东西。<br> Stronger guarantees will be provided eventually, as the [aliasing] rules are being determined. <br>随着 [aliasing] 规则的确定，最终将提供更强有力的保证。<br> For more information, see the [book] as well as the section in the reference devoted to [undefined behavior][ub]. <br>有关更多信息，请参见 [书籍][book] 以及专门针对 [未定义的行为][ub] 的引用中的部分。<br>
//!
//! ## Alignment
//!
//! Valid raw pointers as defined above are not necessarily properly aligned (where "proper" alignment is defined by the pointee type, i.e., `*const T` must be aligned to `mem::align_of::<T>()`). <br>上面定义的有效裸指针不一定正确对齐 (其中 "proper" 对齐由 pointee 类型定义，即 `*const T` 必须与 `mem::align_of::<T>()` 对齐)。<br> However, most functions require their arguments to be properly aligned, and will explicitly state this requirement in their documentation. <br>但是，大多数函数要求其参数正确对齐，并将在其文档中明确说明此要求。<br>
//! Notable exceptions to this are [`read_unaligned`] and [`write_unaligned`]. <br>[`read_unaligned`] 和 [`write_unaligned`] 除外。<br>
//!
//! When a function requires proper alignment, it does so even if the access has size 0, i.e., even if memory is not actually touched. <br>当一个函数需要适当的对齐时，即使访问的大小为 0，即实际上没有触摸到内存，它也需要进行适当的对齐。<br> Consider using [`NonNull::dangling`] in such cases. <br>在这种情况下，请考虑使用 [`NonNull::dangling`]。<br>
//!
//! ## Allocated object <br>分配对象<br>
//!
//! For several operations, such as [`offset`] or field projections (`expr.field`), the notion of an "allocated object" becomes relevant. <br>对于一些操作，例如 [`offset`] 或 projection (`expr.field`)，"allocated object" 的概念变得相关。<br> An allocated object is a contiguous region of memory. <br>分配的对象是一个连续的内存区域。<br>
//! Common examples of allocated objects include stack-allocated variables (each variable is a separate allocated object), heap allocations (each allocation created by the global allocator is a separate allocated object), and `static` variables. <br>分配对象的常见示例包括栈分配变量 (每个变量都是一个单独的分配对象)、堆分配 (每个分配器创建的分配都是一个单独的分配对象) 和 `static` 变量。<br>
//!
//! # Strict Provenance
//!
//! **The following text is non-normative, insufficiently formal, and is an extremely strict interpretation of provenance. <br>以下文本是非规范性的，不够正式，并且是对 Provenance 的极其严格的解释。<br> It's ok if your code doesn't strictly conform to it. <br>如果您的代码没有严格遵循它，那也没关系。<br>**
//!
//! [Strict Provenance][] is an experimental set of APIs that help tools that try to validate the memory-safety of your program's execution. <br>[Strict Provenance][] 是一组实验性 API，可帮助工具尝试验证程序执行的内存安全性。<br> Notably this includes [miri][] and [CHERI][], which can detect when you access out of bounds memory or otherwise violate Rust's memory model. <br>值得注意的是，这包括 [miri][] 和 [CHERI][]，它们可以检测您何时访问越界内存或以其他方式违反 Rust 的内存模型。<br>
//!
//! Provenance must exist in some form for any programming language compiled for modern computer architectures, but specifying a model for provenance in a way that is useful to both compilers and programmers is an ongoing challenge. <br>任何为现代计算机架构编译的编程语言都必须以某种形式存在 Provenance，但是以对编译器和程序员都有用的方式指定 Provenance 模型是一个持续的挑战。<br>
//! The [Strict Provenance][] experiment seeks to explore the question: *what if we just said you couldn't do all the nasty operations that make provenance so messy?* <br>[Strict Provenance][] 实验旨在探索这个问题: 如果我们只是说您不能做所有使 provenance 如此混乱的讨厌的操作，那会怎么样?<br>
//!
//! What APIs would have to be removed? <br>必须删除哪些 API?<br> What APIs would have to be added? <br>必须添加哪些 API?<br> How much would code have to change, and is it worse or better now? <br>代码需要改变多少，现在是更糟还是更好?<br> Would any patterns become truly inexpressible? <br>任何模式都会变得真正无法表达吗?<br>
//! Could we carve out special exceptions for those patterns? <br>我们可以为这些模式开辟特殊的例外吗?<br> Should we? <br>我们应该吗?<br>
//!
//! A secondary goal of this project is to see if we can disambiguate the many functions of pointer<->integer casts enough for the definition of `usize` to be loosened so that it isn't *pointer*-sized but address-space/offset/allocation-sized (we'll probably continue to conflate these notions). <br>这个项目的第二个目标是看看我们是否可以消除指针 <-> 整数转换的许多函数的歧义，以便放宽 `usize` 的定义，使其不是 *pointer* 大小而是 address-space/offset/allocation-sized (我们可能会继续混淆这些概念)。<br>
//! This would potentially make it possible to more efficiently target platforms where pointers are larger than offsets, such as CHERI and maybe some segmented architecures. <br>这可能使更有效地定位指针大于偏移量的平台成为可能，例如 CHERI 和一些分段架构。<br>
//!
//! ## Provenance
//!
//! **This section is *non-normative* and is part of the [Strict Provenance][] experiment. <br>这部分是非规范性的，是 [Strict Provenance][] 实验的一部分。<br>**
//!
//! Pointers are not *simply* an "integer" or "address". <br>指针并不是简单的 "integer" 或 "address"。<br> For instance, it's uncontroversial to say that a Use After Free is clearly Undefined Behaviour, even if you "get lucky" and the freed memory gets reallocated before your read/write (in fact this is the worst-case scenario, UAFs would be much less concerning if this didn't happen!). <br>例如，可以毫无争议地说，释放后使用显然是未定义的行为，即使你运气好，并且释放的内存在读或写之前得到了重新分配 (事实上，这是最坏的情况，如果不发生这种情况，UAFs 也不会太担心!)。<br>
//! To rationalize this claim, pointers need to somehow be *more* than just their addresses: <br>为了使这种说法合理化，指针需要以某种方式不仅仅是它们的地址:<br>
//! they must have provenance. <br>他们必须有 provenance。<br>
//!
//! When an allocation is created, that allocation has a unique Original Pointer. <br>创建分配时，该分配具有唯一的原始指针。<br> For alloc APIs this is literally the pointer the call returns, and for local variables and statics, this is the name of the variable/static. <br>对于 alloc API，这实际上是调用返回的指针，对于本地变量和静态变量，这是变量或静态的名称。<br> This is mildly overloading the term "pointer" for the sake of brevity/exposition. <br>为了简洁明了起见，这稍微过多地使用了 "pointer" 这个术语。<br>
//!
//! The Original Pointer for an allocation is guaranteed to have unique access to the entire allocation and *only* that allocation. <br>保证分配的原始指针对整个分配具有唯一的访问权限，并且只对该分配具有唯一的访问权。<br> In this sense, an allocation can be thought of as a "sandbox" that cannot be broken into or out of. <br>从这个意义上说，分配可以被认为是一个不能被打破的 "sandbox"。<br> *Provenance* is the permission to access an allocation's sandbox and has both a *spatial* and *temporal* component: <br>*Provenance* 是访问分配沙箱的权限，并具有 *spatial* 和 *temporal* 组件:<br>
//!
//! * Spatial: A range of bytes that the pointer is allowed to access. <br>Spatial: 允许指针访问的字节范围。<br>
//! * Temporal: The lifetime (of the allocation) that access to these bytes is tied to. <br>Temporal: 访问这些字节相关的 (分配的) 生命周期。<br>
//!
//! Spatial provenance makes sure you don't go beyond your sandbox, while temporal provenance makes sure that you can't "get lucky" after your permission to access some memory has been revoked (either through deallocations or borrows expiring). <br>Spatial provenance 确保您不会超出沙盒，而时间 provenance 确保您在访问某些内存的权限被撤销 (通过释放或借用到期) 后不能侥幸成功。<br>
//!
//! Provenance is implicitly shared with all pointers transitively derived from The Original Pointer through operations like [`offset`], borrowing, and pointer casts. <br>通过 [`offset`]、借用和指针转换等操作从原始指针传递派生的所有指针隐式共享 provenance。<br>
//! Some operations may *shrink* the derived provenance, limiting how much memory it can access or how long it's valid for (i.e. borrowing a subfield and subslicing). <br>一些操作可能会收缩派生的 provenance，从而限制它可以访问多少内存或它的有效期有多长 (即借用一个子字段和子切片)。<br>
//!
//! Shrinking provenance cannot be undone: even if you "know" there is a larger allocation, you can't derive a pointer with a larger provenance. <br>收缩的 provenance 无法撤消: 即使您知道有一个更大的分配，你也不能派生一个具有更大起源的指针。<br> Similarly, you cannot "recombine" two contiguous provenances back into one (i.e. with a `fn merge(&[T], &[T]) -> &[T]`). <br>同样，您不能 "recombine" 将两个连续的 provenances 重新合二为一 (即使用 `fn merge(&[T], &[T]) -> &[T]`).<br>
//!
//! A reference to a value always has provenance over exactly the memory that field occupies. <br>对某个值的引用始终具有该字段占用的内存的确切来源。<br>
//! A reference to a slice always has provenance over exactly the range that slice describes. <br>对切片的引用总是在切片描述的范围内 provenances。<br>
//!
//! If an allocation is deallocated, all pointers with provenance to that allocation become invalidated, and effectively lose their provenance. <br>如果一个分配被释放，所有指向该分配的指针都会失效，并且实际上失去了它们的出处。<br>
//!
//! The strict provenance experiment is mostly only interested in exploring stricter *spatial* provenance. <br>strict provenance 实验主要只对探索更严格的 *空间* provenance 感兴趣。<br> In this sense it can be thought of as a subset of the more ambitious and formal [Stacked Borrows][] research project, which is what tools like [miri][] are based on. <br>从这个意义上说，它可以被认为是更雄心勃勃和正式的 [Stacked Borrows][] 研究项目的一个子集，这是 [miri][] 等工具的基础。<br>
//! In particular, Stacked Borrows is necessary to properly describe what borrows are allowed to do and when they become invalidated. <br>特别是，堆叠借用对于正确描述允许借用做什么以及何时失效是必要的。<br> This necessarily involves much more complex *temporal* reasoning than simply identifying allocations. <br>这必然涉及比简单地识别分配更复杂的*时间*推理。<br> Adjusting APIs and code for the strict provenance experiment will also greatly help Stacked Borrows. <br>为 strict provenance 实验调整 API 和代码也将极大地帮助 Stacked 借用。<br>
//!
//! ## Pointer Vs Addresses <br>指针与地址<br>
//!
//! **This section is *non-normative* and is part of the [Strict Provenance][] experiment. <br>这部分是非规范性的，是 [Strict Provenance][] 实验的一部分。<br>**
//!
//! One of the largest historical issues with trying to define provenance is that programmers freely convert between pointers and integers. <br>试图定义 provenance 的最大历史问题之一是程序员在指针和整数之间自由转换。<br> Once you allow for this, it generally becomes impossible to accurately track and preserve provenance information, and you need to appeal to very complex and unreliable heuristics. <br>一旦您允许这一点，通常就不可能准确地跟踪和保存 provenance 信息，您需要求助于非常复杂和不可靠的启发式方法。<br>
//! But of course, converting between pointers and integers is very useful, so what can we do? <br>但是当然，指针和整数之间的转换是非常有用的，那么我们能做什么呢?<br>
//!
//! Also did you know WASM is actually a "Harvard Architecture"? <br>您还知道 WASM 实际上是 "Harvard Architecture" 吗?<br> As in function pointers are handled completely differently from data pointers? <br>正如函数指针与数据指针的处理方式完全不同?<br> And we kind of just shipped Rust on WASM without really addressing the fact that we let you freely convert between function pointers and data pointers, because it mostly Just Works? <br>而且我们只是在 WASM 上发布了 Rust 并没有真正解决我们让您在函数指针和数据指针之间自由转换的事实，因为它主要是 Just Works?<br> Let's just put that on the "pointer casts are dubious" pile. <br>让我们把它放在 "指针强制转换是可疑的" 堆上。<br>
//!
//!
//! Strict Provenance attempts to square these circles by decoupling Rust's traditional conflation of pointers and `usize` (and `isize`), and defining a pointer to semantically contain the following information: <br>Strict Provenance 试图通过解耦 Rust 的指针和 `usize` (和 `isize`) 的传统合并，并定义一个指向语义上包含以下信息的指针来解决这些问题:<br>
//!
//! * The **address-space** it is part of (e.g. "data" vs "code" in WASM). <br>**address-space** 它是它的一部分 (例如 "data" 与 WASM 中的 "code")。<br>
//! * The **address** it points to, which can be represented by a `usize`. <br>它指向的 **地址**，可以用 `usize` 表示。<br>
//! * The **provenance** it has, defining the memory it has permission to access. <br>它拥有所有权的 **出处**，定义了它有权访问的内存。<br>
//!
//! Under Strict Provenance, a usize *cannot* accurately represent a pointer, and converting from a pointer to a usize is generally an operation which *only* extracts the address. <br>在 Strict Provenance 下，usize *不能* 准确地表示指针，从指针转换为 usize 通常是 *only* 提取地址的操作。<br> It is therefore *impossible* to construct a valid pointer from a usize because there is no way to restore the address-space and provenance. <br>因此*不可能*从一个 usize 创建一个有效的指针，因为没有办法恢复地址空间和 provenance。<br>
//!
//! The key insight to making this model *at all* viable is the [`with_addr`][] method: <br>使这个模型 *完全* 可行的关键见解是 [`with_addr`][] 方法:<br>
//!
//! ```text
//!     /// Creates a new pointer with the given address. <br>使用给定地址创建一个新指针。<br>
//!     ///
//!     /// This performs the same operation as an `addr as ptr` cast, but copies the *address-space* and *provenance* of `self` to the new pointer. <br>这执行与 `addr as ptr` 强制转换相同的操作，但将 `self` 的 *address-space* 和 *provenance* 复制到新指针。<br>
//!     /// This allows us to dynamically preserve and propagate this important information in a way that is otherwise impossible with a unary cast. <br>这使我们能够动态地保存和传播这些重要信息，而这在其他情况下使用一元强制转换是不可能的。<br>
//!     ///
//!     /// This is equivalent to using `wrapping_offset` to offset `self` to the given address, and therefore has all the same capabilities and restrictions. <br>这相当于使用 `wrapping_offset` 将 `self` 偏移到给定地址，因此具有所有相同的功能和限制。<br>
//!     ///
//!     ///
//!     ///
//!     pub fn with_addr(self, addr: usize) -> Self;
//! ```
//!
//! So you're still able to drop down to the address representation and do whatever clever bit tricks you want *as long as* you're able to keep around a pointer into the allocation you care about that can "reconstitute" the other parts of the pointer. <br>所以您仍然可以丢弃一个地址表示并做任何您想要的聪明的技巧 *只要* 您能够将指针保持在您关心的分配中，可以 "reconstitute" 指针的其他部分.<br>
//! Usually this is very easy, because you only are taking a pointer, messing with the address, and then immediately converting back to a pointer. <br>通常这很容易，因为您只需要一个指针，弄乱地址，然后立即转换回指针。<br>
//! To make this use case more ergonomic, we provide the [`map_addr`][] method. <br>为了使这个用例更符合人体工程学，我们提供了 [`map_addr`][] 方法。<br>
//!
//! To help make it clear that code is "following" Strict Provenance semantics, we also provide an [`addr`][] method which is currently equivalent to `ptr as usize`. <br>为了帮助明确代码是 "following" Strict Provenance 语义，我们还提供了一个当前等效于 `ptr as usize` 的 [`addr`][] 方法。<br> In the future we may provide a lint for pointer<->integer casts to help you audit if your code conforms to strict provenance. <br>在 future 中，我们可以为指针 <-> 整数转换提供 lint，以帮助您审核您的代码是否符合严格的 provenance。<br>
//!
//! ## Using Strict Provenance <br>使用 Strict Provenance<br>
//!
//! Most code needs no changes to conform to strict provenance, as the only really concerning operation that *wasn't* obviously already Undefined Behaviour is casts from usize to a pointer. <br>大多数代码不需要更改以符合 strict provenance，因为 *不是* 显然已经存在未定义行为的唯一真正相关的操作是从 usize 强制转换为指针。<br> For code which *does* cast a usize to a pointer, the scope of the change depends on exactly what you're doing. <br>对于 *does* 将 usize 转换为指针的代码，更改的作用域取决于您正在做什么。<br>
//!
//! In general you just need to make sure that if you want to convert a usize address to a pointer and then use that pointer to read/write memory, you need to keep around a pointer that has sufficient provenance to perform that read/write itself. <br>通常，您只需要确保如果要将使用地址转换为指针，然后使用该指针指向 read/write 内存，则需要保留一个具有足够来源来执行 read/write 本身的指针。<br> In this way all of your casts from an address to a pointer are essentially just applying offsets/indexing. <br>这样，从地址到指针的所有强制转换基本上都只是应用 offsets/indexing。<br>
//!
//! This is generally trivial to do for simple cases like tagged pointers *as long as you represent the tagged pointer as an actual pointer and not a usize*. <br>对于像标记指针 *as 这样的简单情况，只要将标记指针表示为实际指针而不是 usize*，这通常是微不足道的。<br> For instance: <br>例如:<br>
//!
//! ```
//! #![feature(strict_provenance)]
//!
//! unsafe {
//!     // A flag we want to pack into our pointer <br>我们要打包到指针中的标志<br>
//!     static HAS_DATA: usize = 0x1;
//!     static FLAG_MASK: usize = !HAS_DATA;
//!
//!     // Our value, which must have enough alignment to have spare least-significant-bits. <br>我们的值，它必须有足够的对齐，以便有备用的最低有效位。<br>
//!     let my_precious_data: u32 = 17;
//!     assert!(core::mem::align_of::<u32>() > 1);
//!
//!     // Create a tagged pointer <br>创建一个标记指针<br>
//!     let ptr = &my_precious_data as *const u32;
//!     let tagged = ptr.map_addr(|addr| addr | HAS_DATA);
//!
//!     // Check the flag: <br>检查标志:<br>
//!     if tagged.addr() & HAS_DATA != 0 {
//!         // Untag and read the pointer <br>取消标记并读取指针<br>
//!         let data = *tagged.map_addr(|addr| addr & FLAG_MASK);
//!         assert_eq!(data, 17);
//!     } else {
//!         unreachable!()
//!     }
//! }
//! ```
//!
//! (Yes, if you've been using AtomicUsize for pointers in concurrent datastructures, you should be using AtomicPtr instead. <br>(是的，如果您一直使用 AtomicUsize 作为同步数据结构中的指针，则应该改用 AtomicPtr。<br>
//! If that messes up the way you atomically manipulate pointers, we would like to know why, and what needs to be done to fix it.) <br>如果这弄乱了您以原子方式操作指针的方式，我们想知道原因，以及需要做些什么来修复它。)<br>
//!
//! Something more complicated and just generally *evil* like an XOR-List requires more significant changes like allocating all nodes in a pre-allocated Vec or Arena and using a pointer to the whole allocation to reconstitute the XORed addresses. <br>像 XOR 列表这样更复杂且通常 *evil* 的东西需要更重大的更改，例如在预分配的 Vec 或 Arena 中分配所有节点，并使用指向整个分配的指针来重构 XORed 地址。<br>
//!
//! Situations where a valid pointer *must* be created from just an address, such as baremetal code accessing a memory-mapped interface at a fixed address, are an open question on how to support. <br>必须从一个地址创建有效指针的情况，例如访问固定地址的内存映射接口的裸机代码，是一个关于如何支持的悬而未决的问题。<br>
//! These situations *will* still be allowed, but we might require some kind of "I know what I'm doing" annotation to explain the situation to the compiler. <br>这些情况仍然是允许的，但我们可能需要某种 "I know what I'm doing" 注解来向编译器解释这种情况。<br> It's also possible they need no special attention at all, because they're generally accessing memory outside the scope of "the abstract machine", or already using "I know what I'm doing" annotations like "volatile". <br>也有可能它们根本不需要特别注意，因为它们通常在 "the abstract machine" 的作用域之外访问内存，或者已经像 "volatile" 一样使用 "I know what I'm doing" 注解。<br>
//!
//! Under [Strict Provenance] it is Undefined Behaviour to: <br>在 [Strict Provenance] 下，未定义行为:<br>
//!
//! * Access memory through a pointer that does not have provenance over that memory. <br>通过与该内存没有 provenance 的指针访问内存。<br>
//!
//! * [`offset`] a pointer to or from an address it doesn't have provenance over. <br>[`offset`] 指向或来自没有 provenance 的地址的指针。<br>
//!   This means it's always UB to offset a pointer derived from something deallocated, even if the offset is 0. <br>这意味着它总是 UB 来偏移一个指针，这个指针是从一个被释放的对象中派生出来的，即使这个偏移量是 0。<br> Note that a pointer "one past the end" of its provenance is not actually outside its provenance, it just has 0 bytes it can load/store. <br>请注意，其 provenance 的指针 "one past the end" 实际上并不在其 provenance 之外，它只有 0 个字节可以 load/store。<br>
//!
//! But it *is* still sound to: <br>但它仍然听起来像是:<br>
//!
//! * Create an invalid pointer from just an address (see [`ptr::invalid`][]). <br>仅从地址创建无效指针 (请参见 [`ptr::invalid`][])。<br> This can be used for sentinel values like `null` *or* to represent a tagged pointer that will never be dereferencable. <br>这可用于 `null` 或之类的标记值，以表示永远不会被解引用的标记指针。<br> In general, it is always sound for an integer to pretend to be a pointer "for fun" as long as you don't use operations on it which require it to be valid (offset, read, write, etc). <br>通常，只要您不对整数使用要求它有效的操作 (偏移、读取、写入等)，将整数伪装成指针 "for fun" 总是合理的。<br>
//!
//! * Forge an allocation of size zero at any sufficiently aligned non-null address. <br>在任何充分对齐的非空地址处伪造大小为零的分配。<br>
//!   i.e. the usual "ZSTs are fake, do what you want" rules apply *but* this only applies for actual forgery (integers cast to pointers). <br>即通常的 "ST 是假的，做你想做的事" 规则适用 *但是* 这仅适用于实际伪造 (整数转换为指针)。<br> If you borrow some struct's field that *happens* to be zero-sized, the resulting pointer will have provenance tied to that allocation and it will still get invalidated if the allocation gets deallocated. <br>如果您借用一些结构体的字段，它 *碰巧* 是零大小，则结果指针将与该分配相关联，如果分配被释放，它仍然会失效。<br>
//!   In the future we may introduce an API to make such a forged allocation explicit. <br>在 future 中，我们可能会引入一个 API 来明确这种伪造的分配。<br>
//!
//! * [`wrapping_offset`][] a pointer outside its provenance. <br>[`wrapping_offset`][] 指向其 provenance 之外的指针。<br> This includes invalid pointers which have "no" provenance. <br>这包括具有 "no"  provenance 的无效指针。<br> Unfortunately there may be practical limits on this for a particular platform, and it's an open question as to how to specify this (if at all). <br>不幸的是，对于特定平台，这可能存在实际限制，如何指定它 (如果有的话) 是一个悬而未决的问题。<br>
//!   Notably, [CHERI][] relies on a compression scheme that can't handle a pointer getting offset "too far" out of bounds. <br>值得注意的是，[CHERI][] 依赖于一种压缩方案，该方案无法处理使偏移量 "too far" 越界的指针。<br> If this happens, the address returned by `addr` will be the value you expect, but the provenance will get invalidated and using it to read/write will fault. <br>如果发生这种情况，`addr` 返回的地址将是您期望的值，但 provenance 将失效，并且将其用于 read/write 会出错。<br>
//!   The details of this are architecture-specific and based on alignment, but the buffer on either side of the pointer's range is pretty generous (think kilobytes, not bytes). <br>这方面的细节是特定于架构的并且基于对齐，但是指针范围两侧的缓冲区非常大 (想想千字节，而不是字节)。<br>
//!
//! * Compare arbitrary pointers by address. <br>按地址比较任意指针。<br> Addresses *are* just integers and so there is always a coherent answer, even if the pointers are invalid or from different address-spaces/provenances. <br>地址是只是整数，因此总是有一个连贯的答案，即使指针无效或来自不同的 address-spaces/provenances。<br> Of course, comparing addresses from different address-spaces is generally going to be *meaningless*, but so is comparing Kilograms to Meters, and Rust doesn't prevent that either. <br>当然，比较来自不同地址空间的地址通常 *毫无意义*，但是将千克与米进行比较也是如此，并且 Rust 也不会阻止这种情况。<br>
//! Similarly, if you get "lucky" and notice that a pointer one-past-the-end is the "same" address as the start of an unrelated allocation, anything you do with that fact is *probably* going to be gibberish. <br>类似地，如果您得到 "lucky"，并且注意到一个指针过去是 "same" 地址作为不相关分配的开始，那么您对这个事实所做的任何事情都是 *可能* 会是莫名其妙的。<br>
//! The scope of that gibberish is kept under control by the fact that the two pointers *still* aren't allowed to access the other's allocation (bytes), because they still have different provenance. <br>由于两个指针仍然不允许访问另一个指针的分配 (bytes)，因为它们仍然有不同的 provenance，所以这种莫名其妙的范围受到控制。<br>
//!
//! * Perform pointer tagging tricks. <br>执行指针标记技巧。<br> This falls out of [`wrapping_offset`] but is worth mentioning in more detail because of the limitations of [CHERI][]. <br>这不属于 [`wrapping_offset`]，但由于 [CHERI][] 的局限性，值得更详细地提及。<br> Low-bit tagging is very robust, and often doesn't even go out of bounds because types ensure size >= align (and over-aligning actually gives CHERI more flexibility). <br>低位标记非常健壮，并且通常甚至不会越界，因为类型确保大小 >= 对齐 (并且过度对齐实际上给了 CHERI 更大的灵活性)。<br>
//! Anything more complex than this rapidly enters "extremely platform-specific" territory as certain things may or may not be allowed based on specific supported operations. <br>任何比这更复杂的东西都会迅速进入 "extremely platform-specific" 领域，因为根据特定支持的操作可能会或可能不会允许某些事情。<br>
//!   For instance, ARM explicitly supports high-bit tagging, and so CHERI on ARM inherits that and should support it. <br>例如，ARM 明确支持高位标记，因此 ARM 上的 CHERI 继承了它并且应该支持它。<br>
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//! [`wrapping_offset`]: pointer::wrapping_offset
//! [`with_addr`]: pointer::with_addr
//! [`map_addr`]: pointer::map_addr
//! [`addr`]: pointer::addr
//! [`ptr::invalid`]: core::ptr::invalid
//! [miri]: https://github.com/rust-lang/miri
//! [CHERI]: https://www.cl.cam.ac.uk/research/security/ctsrd/cheri/
//! [Strict Provenance]: https://github.com/rust-lang/rust/issues/95228
//! [Stacked Borrows]: https://plv.mpi-sws.org/rustbelt/stacked-borrows/
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{
    self, assert_unsafe_precondition, is_aligned_and_not_null, is_nonoverlapping,
};

use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

mod metadata;
pub(crate) use metadata::PtrRepr;
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Executes the destructor (if any) of the pointed-to value. <br>执行指向值的析构函数 (如果有)。<br>
///
/// This is semantically equivalent to calling [`ptr::read`] and discarding the result, but has the following advantages: <br>从语义上讲，这等效于调用 [`ptr::read`] 并丢弃结果，但是具有以下优点：<br>
///
/// * It is *required* to use `drop_in_place` to drop unsized types like trait objects, because they can't be read out onto the stack and dropped normally. <br>强制要求使用 `drop_in_place` 丢弃未定义大小的类型 (例如 trait 对象)，因为它们无法被读取到栈上并且无法正常丢弃。<br>
///
/// * It is friendlier to the optimizer to do this over [`ptr::read`] when dropping manually allocated memory (e.g., in the implementations of `Box`/`Rc`/`Vec`), as the compiler doesn't need to prove that it's sound to elide the copy. <br>当丢弃手动分配的内存时 (例如，在 `Box`/`Rc`/`Vec` 的实现中)，通过 [`ptr::read`] 进行此操作对优化器来说更友好，因为编译器不需要证明丢弃副本是合理的。<br>
///
///
/// * It can be used to drop [pinned] data when `T` is not `repr(packed)` (pinned data must not be moved before it is dropped). <br>当 `T` 不是 `repr(packed)` 时，可用于丢弃 [固定][pinned] 数据 (在丢弃固定的数据之前，不得移动固定的数据)。<br>
///
/// Unaligned values cannot be dropped in place, they must be copied to an aligned location first using [`ptr::read_unaligned`]. <br>未对齐的值不能被直接丢弃，必须先使用 [`ptr::read_unaligned`] 将它们复制到对齐的位置。<br> For packed structs, this move is done automatically by the compiler. <br>对于包装的结构体，此移动由编译器自动完成。<br>
/// This means the fields of packed structs are not dropped in-place. <br>这意味着已打包结构的字段不会被原地丢弃。<br>
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `to_drop` must be [valid] for both reads and writes. <br>对于读取和写入，`to_drop` 必须是 [有效][valid]。<br>
///
/// * `to_drop` must be properly aligned. <br>`to_drop` 必须正确对齐。<br>
///
/// * The value `to_drop` points to must be valid for dropping, which may mean it must uphold additional invariants - this is type-dependent. <br>`to_drop` 指向的值必须对丢弃有效，这可能意味着它必须支持其他不变量 - 这与类型有关。<br>
///
/// Additionally, if `T` is not [`Copy`], using the pointed-to value after calling `drop_in_place` can cause undefined behavior. <br>此外，如果 `T` 不是 [`Copy`]，则在调用 `drop_in_place` 之后使用指向的值可能会导致未定义的行为。<br> Note that `*to_drop = foo` counts as a use because it will cause the value to be dropped again. <br>请注意，`*to_drop = foo` 被视为使用，因为它将导致该值再次被丢弃。<br>
/// [`write()`] can be used to overwrite data without causing it to be dropped. <br>[`write()`] 可用于覆盖数据，而不会导致数据被丢弃。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
///
/// # Examples
///
/// Manually remove the last item from a vector: <br>从 vector 手动删除最后一个项：<br>
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Get a raw pointer to the last element in `v`. <br>获取指向 `v` 中最后一个元素的裸指针。<br>
///     let ptr = &mut v[1] as *mut _;
///     // Shorten `v` to prevent the last item from being dropped. <br>缩短 `v`，以防止丢弃最后一个项。<br>
///     // We do that first, to prevent issues if the `drop_in_place` below panics. <br>我们首先这样做是为了防止 `drop_in_place` 低于 panics。<br>
///     v.set_len(1);
///     // Without a call `drop_in_place`, the last item would never be dropped, and the memory it manages would be leaked. <br>如果没有调用 `drop_in_place`，则最后一个项将永远不会被删除，并且它管理的内存也会泄漏。<br>
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Ensure that the last item was dropped. <br>确保丢弃了最后一项。<br>
/// assert!(weak.upgrade().is_none());
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Code here does not matter - this is replaced by the real drop glue by the compiler. <br>这里的代码并不重要 - 编译器会将其替换为真正的 drop glue。<br>
    //

    // SAFETY: see comment above <br>请看上面的注释<br>
    unsafe { drop_in_place(to_drop) }
}

/// Creates a null raw pointer. <br>创建一个空的裸指针。<br>
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.24.0")]
#[rustc_diagnostic_item = "ptr_null"]
pub const fn null<T>() -> *const T {
    invalid(0)
}

/// Creates a null mutable raw pointer. <br>创建一个空的可变裸露指针。<br>
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.24.0")]
#[rustc_diagnostic_item = "ptr_null_mut"]
pub const fn null_mut<T>() -> *mut T {
    invalid_mut(0)
}

/// Creates an invalid pointer with the given address. <br>创建具有给定地址的无效指针。<br>
///
/// This is *currently* equivalent to `addr as *const T` but it expresses the intended semantic more clearly, and may become important under future memory models. <br>目前，这相当于 `addr as *const T`，但它更清楚地表达了预期的语义，并且在未来的记忆模型中可能会变得很重要。<br>
///
/// The module's top-level documentation discusses the precise meaning of an "invalid" pointer but essentially this expresses that the pointer is not associated with any actual allocation and is little more than a usize address in disguise. <br>该模块的顶层文档讨论了 "invalid" 指针的确切含义，但本质上这表示该指针与任何实际分配无关，只不过是一个伪装的 usize 地址。<br>
///
///
/// This pointer will have no provenance associated with it and is therefore UB to read/write/offset. <br>该指针将没有与之关联的 provenance，因此 read/write/offset 是 UB 的。<br> This mostly exists to facilitate things like ptr::null and NonNull::dangling which make invalid pointers. <br>这主要是为了方便 ptr::null 和 NonNull::dangling 这样的东西，它们会产生无效的指针。<br>
///
/// (Standard "Zero-Sized-Types get to cheat and lie" caveats apply, although it may be desirable to give them their own API just to make that 100% clear.) <br>(标准 "Zero-Sized-Types get to cheat and lie" 的警告是适用的，尽管可能需要为它们提供自己的 API，以便 100% 清楚地说明这一点。)<br>
///
/// This API and its claimed semantics are part of the Strict Provenance experiment, see the [module documentation][crate::ptr] for details. <br>此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。<br>
///
///
///
///
///
///
#[inline(always)]
#[must_use]
#[rustc_const_stable(feature = "stable_things_using_strict_provenance", since = "1.61.0")]
#[unstable(feature = "strict_provenance", issue = "95228")]
pub const fn invalid<T>(addr: usize) -> *const T {
    // FIXME(strict_provenance_magic): I am magic and should be a compiler intrinsic. <br>我是魔法，应该是编译器内部函数。<br>
    addr as *const T
}

/// Creates an invalid mutable pointer with the given address. <br>用给定的地址创建一个无效的可变指针。<br>
///
/// This is *currently* equivalent to `addr as *mut T` but it expresses the intended semantic more clearly, and may become important under future memory models. <br>目前，这相当于 `addr as *mut T`，但它更清楚地表达了预期的语义，并且在未来的记忆模型中可能会变得很重要。<br>
///
/// The module's top-level documentation discusses the precise meaning of an "invalid" pointer but essentially this expresses that the pointer is not associated with any actual allocation and is little more than a usize address in disguise. <br>该模块的顶层文档讨论了 "invalid" 指针的确切含义，但本质上这表示该指针与任何实际分配无关，只不过是一个伪装的 usize 地址。<br>
///
///
/// This pointer will have no provenance associated with it and is therefore UB to read/write/offset. <br>该指针将没有与之关联的 provenance，因此 read/write/offset 是 UB 的。<br> This mostly exists to facilitate things like ptr::null and NonNull::dangling which make invalid pointers. <br>这主要是为了方便 ptr::null 和 NonNull::dangling 这样的东西，它们会产生无效的指针。<br>
///
/// (Standard "Zero-Sized-Types get to cheat and lie" caveats apply, although it may be desirable to give them their own API just to make that 100% clear.) <br>(标准 "Zero-Sized-Types get to cheat and lie" 的警告是适用的，尽管可能需要为它们提供自己的 API，以便 100% 清楚地说明这一点。)<br>
///
/// This API and its claimed semantics are part of the Strict Provenance experiment, see the [module documentation][crate::ptr] for details. <br>此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。<br>
///
///
///
///
///
///
#[inline(always)]
#[must_use]
#[rustc_const_stable(feature = "stable_things_using_strict_provenance", since = "1.61.0")]
#[unstable(feature = "strict_provenance", issue = "95228")]
pub const fn invalid_mut<T>(addr: usize) -> *mut T {
    // FIXME(strict_provenance_magic): I am magic and should be a compiler intrinsic. <br>我是魔法，应该是编译器内部函数。<br>
    addr as *mut T
}

/// Forms a raw slice from a pointer and a length. <br>根据指针和长度形成原始切片。<br>
///
/// The `len` argument is the number of **elements**, not the number of bytes. <br>`len` 参数是 **元素** 的数量，而不是字节数。<br>
///
/// This function is safe, but actually using the return value is unsafe. <br>此函数是安全的，但实际上使用返回值是不安全的。<br>
/// See the documentation of [`slice::from_raw_parts`] for slice safety requirements. <br>有关切片的安全要求，请参见 [`slice::from_raw_parts`] 的文档。<br>
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // create a slice pointer when starting out with a pointer to the first element <br>从指向第一个元素的指针开始创建切片指针<br>
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    from_raw_parts(data.cast(), len)
}

/// Performs the same functionality as [`slice_from_raw_parts`], except that a raw mutable slice is returned, as opposed to a raw immutable slice. <br>执行与 [`slice_from_raw_parts`] 相同的功能，但返回的是原始可变切片，而不是原始的不可变切片。<br>
///
///
/// See the documentation of [`slice_from_raw_parts`] for more details. <br>有关更多详细信息，请参见 [`slice_from_raw_parts`] 的文档。<br>
///
/// This function is safe, but actually using the return value is unsafe. <br>此函数是安全的，但实际上使用返回值是不安全的。<br>
/// See the documentation of [`slice::from_raw_parts_mut`] for slice safety requirements. <br>有关切片的安全要求，请参见 [`slice::from_raw_parts_mut`] 的文档。<br>
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // assign a value at an index in the slice <br>在切片中的索引处分配值<br>
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    from_raw_parts_mut(data.cast(), len)
}

/// Swaps the values at two mutable locations of the same type, without deinitializing either. <br>在相同类型的两个可变位置交换值，而无需取消初始化任何一个。<br>
///
/// But for the following two exceptions, this function is semantically equivalent to [`mem::swap`]: <br>但是对于以下两个例外，此函数在语义上等效于 [`mem::swap`]：<br>
///
///
/// * It operates on raw pointers instead of references. <br>它对裸指针而不是引用进行操作。<br>
/// When references are available, [`mem::swap`] should be preferred. <br>如果引用可用，则应首选 [`mem::swap`]。<br>
///
/// * The two pointed-to values may overlap. <br>两个指向的值可能会重叠。<br>
/// If the values do overlap, then the overlapping region of memory from `x` will be used. <br>如果值确实重叠，则将使用 `x` 的内存重叠区域。<br>
/// This is demonstrated in the second example below. <br>在下面的第二个示例中对此进行了演示。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * Both `x` and `y` must be [valid] for both reads and writes. <br>对于读取和写入，`x` 和 `y` 都必须为 [有效][valid] 的。<br>
///
/// * Both `x` and `y` must be properly aligned. <br>`x` 和 `y` 必须正确对齐。<br>
///
/// Note that even if `T` has size `0`, the pointers must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
///
/// # Examples
///
/// Swapping two non-overlapping regions: <br>交换两个不重叠的区域：<br>
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let (x, y) = array.split_at_mut(2);
/// let x = x.as_mut_ptr().cast::<[u32; 2]>(); // this is `array[0..2]` <br>这是 `array[0..2]`<br>
/// let y = y.as_mut_ptr().cast::<[u32; 2]>(); // this is `array[2..4]` <br>这是 `array[2..4]`<br>
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Swapping two overlapping regions: <br>交换两个重叠的区域：<br>
///
/// ```
/// use std::ptr;
///
/// let mut array: [i32; 4] = [0, 1, 2, 3];
///
/// let array_ptr: *mut i32 = array.as_mut_ptr();
///
/// let x = array_ptr as *mut [i32; 3]; // this is `array[0..3]` <br>这是 `array[0..3]`<br>
/// let y = unsafe { array_ptr.add(1) } as *mut [i32; 3]; // this is `array[1..4]` <br>这是 `array[1..4]`<br>
///
/// unsafe {
///     ptr::swap(x, y);
///     // The indices `1..3` of the slice overlap between `x` and `y`. <br>切片的索引 `1..3` 在 `x` 和 `y` 之间重叠。<br>
///     // Reasonable results would be for to them be `[2, 3]`, so that indices `0..3` are `[1, 2, 3]` (matching `y` before the `swap`); <br>合理的结果将是 `[2, 3]`，因此索引 `0..3` 为 `[1, 2, 3]` (与 `swap` 匹配的 `y`) ；<br> or for them to be `[0, 1]` so that indices `1..4` are `[0, 1, 2]` (matching `x` before the `swap`). <br>或将它们设为 `[0, 1]`，以使索引 `1..4` 为 `[0, 1, 2]` (与 `swap` 之前的 `x` 匹配)。<br>
/////
///     // This implementation is defined to make the latter choice. <br>定义此实现是为了做出后一种选择。<br>
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Give ourselves some scratch space to work with. <br>给自己一些工作的空间。<br>
    // We do not have to worry about drops: `MaybeUninit` does nothing when dropped. <br>我们不必担心丢弃: `MaybeUninit` 在丢弃时什么也不做。<br>
    let mut tmp = MaybeUninit::<T>::uninit();

    // Perform the swap <br>执行交换<br>
    // SAFETY: the caller must guarantee that `x` and `y` are valid for writes and properly aligned. <br>调用者必须保证 `x` 和 `y` 对写入有效并且正确对齐。<br>
    // `tmp` cannot be overlapping either `x` or `y` because `tmp` was just allocated on the stack as a separate allocated object. <br>`tmp` 不能与 `x` 或 `y` 重叠，因为 `tmp` 只是作为单独的分配对象在栈上分配。<br>
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` and `y` may overlap <br>`x` 和 `y` 可能重叠<br>
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Swaps `count * size_of::<T>()` bytes between the two regions of memory beginning at `x` and `y`. <br>从 `x` 和 `y` 开始在两个内存区域之间交换 `count * size_of::<T>()` 字节。<br>
/// The two regions must *not* overlap. <br>这两个区域必须 *不能* 重叠。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * Both `x` and `y` must be [valid] for both reads and writes of `count <br>`x` 和 `y` 都必须 [有效][valid] 才能读取和写入 `count<br> *
///   size_of::<T>()` bytes. <br>size_of::<T>()` 个字节。<br>
///
/// * Both `x` and `y` must be properly aligned. <br>`x` 和 `y` 必须正确对齐。<br>
///
/// * The region of memory beginning at `x` with a size of `count <br>从 `x` 开始的内存区域，大小为 `count<br> *
///   size_of::<T>()` bytes must *not* overlap with the region of memory beginning at `y` with the same size. <br>size_of::<T>()` 字节不得与以 `y` 开始且大小相同的内存区域重叠。<br>
///
/// Note that even if the effectively copied size (`count * size_of::<T>()`) is `0`, the pointers must be non-null and properly aligned. <br>请注意，即使有效复制的大小 (`count * size_of::<T>()`) 是 `0`，指针也必须非空的并且正确对齐。<br>
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    #[allow(unused)]
    macro_rules! attempt_swap_as_chunks {
        ($ChunkTy:ty) => {
            if mem::align_of::<T>() >= mem::align_of::<$ChunkTy>()
                && mem::size_of::<T>() % mem::size_of::<$ChunkTy>() == 0
            {
                let x: *mut MaybeUninit<$ChunkTy> = x.cast();
                let y: *mut MaybeUninit<$ChunkTy> = y.cast();
                let count = count * (mem::size_of::<T>() / mem::size_of::<$ChunkTy>());
                // SAFETY: these are the same bytes that the caller promised were ok, just typed as `MaybeUninit<ChunkTy>`s instead of as `T`s. <br>这些是调用者承诺的相同字节，只是输入为 `MaybeUninit<ChunkTy>`s 而不是 `T`s。<br>
                // The `if` condition above ensures that we're not violating alignment requirements, and that the division is exact so that we don't lose any bytes off the end. <br>上面的 `if` 条件确保我们没有违反对齐要求，并且划分是准确的，这样我们就不会丢失任何最后的字节。<br>
                //
                //
                //
                return unsafe { swap_nonoverlapping_simple(x, y, count) };
            }
        };
    }

    // SAFETY: the caller must guarantee that `x` and `y` are valid for writes and properly aligned. <br>调用者必须保证 `x` 和 `y` 对写入有效并且正确对齐。<br>
    //
    unsafe {
        assert_unsafe_precondition!(
            is_aligned_and_not_null(x)
                && is_aligned_and_not_null(y)
                && is_nonoverlapping(x, y, count)
        );
    }

    // NOTE(scottmcm) MIRI is disabled here as reading in smaller units is a pessimization for it. <br>MIRI 在这里被禁用，因为以较小的单位读取对它来说是一种悲观。<br>
    // Also, if the type contains any unaligned pointers, copying those over multiple reads is difficult to support. <br>此外，如果该类型包含任何未对齐的指针，则难以支持在多次读取中复制这些指针。<br>
    //
    #[cfg(not(miri))]
    {
        // Split up the slice into small power-of-two-sized chunks that LLVM is able to vectorize (unless it's a special type with more-than-pointer alignment, because we don't want to pessimize things like slices of SIMD vectors.) <br>将切片拆分为 LLVM 能够向量化的 2 次幂大小的小块 (除非它是具有多于指针对齐的特殊类型，因为我们不想悲观 SIMD vectors 的切片之类的东西。)<br>
        //
        //
        if mem::align_of::<T>() <= mem::size_of::<usize>()
            && (!mem::size_of::<T>().is_power_of_two()
                || mem::size_of::<T>() > mem::size_of::<usize>() * 2)
        {
            attempt_swap_as_chunks!(usize);
            attempt_swap_as_chunks!(u8);
        }
    }

    // SAFETY: Same preconditions as this function <br>与此函数相同的前提条件<br>
    unsafe { swap_nonoverlapping_simple(x, y, count) }
}

/// Same behaviour and safety conditions as [`swap_nonoverlapping`] <br>与 [`swap_nonoverlapping`] 相同的行为和安全条件<br>
///
/// LLVM can vectorize this (at least it can for the power-of-two-sized types `swap_nonoverlapping` tries to use) so no need to manually SIMD it. <br>LLVM 可以对其进行矢量化 (至少它可以用于 `swap_nonoverlapping` 尝试使用的两倍大小的类型)，因此无需手动对其进行 SIMD。<br>
///
#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_simple<T>(x: *mut T, y: *mut T, count: usize) {
    let mut i = 0;
    while i < count {
        let x: &mut T =
            // SAFETY: By precondition, `i` is in-bounds because it's below `n` <br>根据前提条件，`i` 是在界内，因为它低于 `n`<br>
            unsafe { &mut *x.add(i) };
        let y: &mut T =
            // SAFETY: By precondition, `i` is in-bounds because it's below `n` and it's distinct from `x` since the ranges are non-overlapping <br>根据前提条件，`i` 是在界内，因为它低于 `n`，并且它不同于 `x`，因为范围不重叠<br>
            //
            unsafe { &mut *y.add(i) };
        mem::swap_simple(x, y);

        i += 1;
    }
}

/// Moves `src` into the pointed `dst`, returning the previous `dst` value. <br>将 `src` 移至指定的 `dst`，返回先前的 `dst` 值。<br>
///
/// Neither value is dropped. <br>这两个值都不会被丢弃。<br>
///
/// This function is semantically equivalent to [`mem::replace`] except that it operates on raw pointers instead of references. <br>该函数在语义上等效于 [`mem::replace`]，除了它在裸指针上而不是在引用上运行。<br>
/// When references are available, [`mem::replace`] should be preferred. <br>如果引用可用，则应首选 [`mem::replace`]。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `dst` must be [valid] for both reads and writes. <br>对于读取和写入，`dst` 必须是 [有效的][valid]。<br>
///
/// * `dst` must be properly aligned. <br>`dst` 必须正确对齐。<br>
///
/// * `dst` must point to a properly initialized value of type `T`. <br>`dst` 必须指向 `T` 类型的正确初始化值。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` would have the same effect without requiring the unsafe block. <br>`mem::replace` 将具有相同的效果，而无需 unsafe 块。<br>
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_replace", issue = "83164")]
pub const unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAFETY: the caller must guarantee that `dst` is valid to be cast to a mutable reference (valid for writes, aligned, initialized), and cannot overlap `src` since `dst` must point to a distinct allocated object. <br>调用者必须保证 `dst` 有效，可以强制转换为变量引用 (对写入，对齐，初始化有效)，并且不能与 `src` 重叠，因为 `dst` 必须指向不同的分配对象。<br>
    //
    //
    //
    unsafe {
        assert_unsafe_precondition!(is_aligned_and_not_null(dst));
        mem::swap(&mut *dst, &mut src); // cannot overlap <br>不能重叠<br>
    }
    src
}

/// Reads the value from `src` without moving it. <br>从 `src` 读取值而不移动它。<br> This leaves the memory in `src` unchanged. <br>这将使 `src` 中的内存保持不变。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `src` must be [valid] for reads. <br>`src` 必须是 [有效的][valid] 才能读取。<br>
///
/// * `src` must be properly aligned. <br>`src` 必须正确对齐。<br> Use [`read_unaligned`] if this is not the case. <br>如果不是这种情况，请使用 [`read_unaligned`]。<br>
///
/// * `src` must point to a properly initialized value of type `T`. <br>`src` 必须指向 `T` 类型的正确初始化值。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manually implement [`mem::swap`]: <br>手动实现 [`mem::swap`]：<br>
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Create a bitwise copy of the value at `a` in `tmp`. <br>在 `tmp` 中的 `a` 处创建值的按位副本。<br>
///         let tmp = ptr::read(a);
///
///         // Exiting at this point (either by explicitly returning or by calling a function which panics) would cause the value in `tmp` to be dropped while the same value is still referenced by `a`. <br>此时退出 (通过显式返回或调用 panics 的函数) 将导致 `tmp` 中的值被丢弃，而 `a` 仍引用相同的值。<br>
///         // This could trigger undefined behavior if `T` is not `Copy`. <br>如果 `T` 不是 `Copy`，则可能触发未定义的行为。<br>
/////
/////
///
///         // Create a bitwise copy of the value at `b` in `a`. <br>在 `a` 中的 `b` 处创建值的按位副本。<br>
///         // This is safe because mutable references cannot alias. <br>这是安全的，因为可变引用不能使用别名。<br>
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // As above, exiting here could trigger undefined behavior because the same value is referenced by `a` and `b`. <br>如上所述，退出此处可能会触发未定义的行为，因为 `a` 和 `b` 引用了相同的值。<br>
/////
///
///         // Move `tmp` into `b`. <br>将 `tmp` 移至 `b`。<br>
///         ptr::write(b, tmp);
///
///         // `tmp` has been moved (`write` takes ownership of its second argument), so nothing is dropped implicitly here. <br>`tmp` 已移动 (`write` 对其第二个参数的所有权)，因此这里没有隐含地丢弃任何东西。<br>
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Ownership of the Returned Value <br>归还值的所有权<br>
///
/// `read` creates a bitwise copy of `T`, regardless of whether `T` is [`Copy`]. <br>`read` 创建 `T` 的按位副本，无论 `T` 是否为 [`Copy`]。<br>
/// If `T` is not [`Copy`], using both the returned value and the value at `*src` can violate memory safety. <br>如果 `T` 不是 [`Copy`]，则同时使用返回的值和 `*src` 的值可能会违反内存安全性。<br>
/// Note that assigning to `*src` counts as a use because it will attempt to drop the value at `*src`. <br>请注意，将分配给 `*src` 视为一种用途，因为它将尝试丢弃 `*src` 处的值。<br>
///
/// [`write()`] can be used to overwrite data without causing it to be dropped. <br>[`write()`] 可用于覆盖数据，而不会导致数据被丢弃。<br>
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` now points to the same underlying memory as `s`. <br>`s2` 现在指向与 `s` 相同的底层内存。<br>
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Assigning to `s2` causes its original value to be dropped. <br>分配给 `s2` 会导致其原始值被丢弃。<br>
///     // Beyond this point, `s` must no longer be used, as the underlying memory has been freed. <br>除此之外，由于已释放底层内存，因此不能再使用 `s`。<br>
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Assigning to `s` would cause the old value to be dropped again, resulting in undefined behavior. <br>分配给 `s` 将导致旧值再次被丢弃，从而导致未定义的行为。<br>
/////
///     // s = String::from("bar");  // ERROR <br>// 错误<br>
///
///     // `ptr::write` can be used to overwrite a value without dropping it. <br>`ptr::write` 可用于覆盖一个值而无需丢弃它。<br>
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    // We are calling the intrinsics directly to avoid function calls in the generated code as `intrinsics::copy_nonoverlapping` is a wrapper function. <br>我们直接调用内部函数是为了避免在生成的代码中调用函数，因为 `intrinsics::copy_nonoverlapping` 是一个包装函数。<br>
    //
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: the caller must guarantee that `src` is valid for reads. <br>调用者必须保证 `src` 对于读取有效。<br>
    // `src` cannot overlap `tmp` because `tmp` was just allocated on the stack as a separate allocated object. <br>`src` 不能与 `tmp` 重叠，因为 `tmp` 只是作为单独的分配对象在栈上分配的。<br>
    //
    //
    // Also, since we just wrote a valid value into `tmp`, it is guaranteed to be properly initialized. <br>另外，由于我们只是将有效值写入 `tmp`，因此可以确保正确初始化它。<br>
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Reads the value from `src` without moving it. <br>从 `src` 读取值而不移动它。<br> This leaves the memory in `src` unchanged. <br>这将使 `src` 中的内存保持不变。<br>
///
/// Unlike [`read`], `read_unaligned` works with unaligned pointers. <br>与 [`read`] 不同，`read_unaligned` 使用未对齐的指针。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `src` must be [valid] for reads. <br>`src` 必须是 [有效的][valid] 才能读取。<br>
///
/// * `src` must point to a properly initialized value of type `T`. <br>`src` 必须指向 `T` 类型的正确初始化值。<br>
///
/// Like [`read`], `read_unaligned` creates a bitwise copy of `T`, regardless of whether `T` is [`Copy`]. <br>与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`read_unaligned` 都会创建 `T` 的按位副本。<br>
/// If `T` is not [`Copy`], using both the returned value and the value at `*src` can [violate memory safety][read-ownership]. <br>如果 `T` 不是 [`Copy`]，则同时使用返回值和 `*src` 处的值都可以 [违反内存安全][read-ownership]。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空。<br>
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## On `packed` structs <br>在 `packed` 结构体上<br>
///
/// Attempting to create a raw pointer to an `unaligned` struct field with an expression such as `&packed.unaligned as *const FieldType` creates an intermediate unaligned reference before converting that to a raw pointer. <br>尝试使用诸如 `&packed.unaligned as *const FieldType` 的表达式创建指向 `unaligned` 结构体字段的裸指针，然后再将其转换为裸指针，这会产生一个中间未对齐的引用。<br>
///
/// That this reference is temporary and immediately cast is inconsequential as the compiler always expects references to be properly aligned. <br>引用是临时的并且立即强制转换是无关紧要的，因为编译器始终希望引用正确对齐。<br>
/// As a result, using `&packed.unaligned as *const FieldType` causes immediate *undefined behavior* in your program. <br>结果，使用 `&packed.unaligned as *const FieldType` 会在程序中立即导致* undefined 行为 *。<br>
///
/// Instead you must use the [`ptr::addr_of!`](addr_of) macro to create the pointer. <br>相反，您必须使用 [`ptr::addr_of!`](addr_of) 宏来创建指针。<br> You may use that returned pointer together with this function. <br>您可以将返回的指针与此函数一起使用。<br>
///
/// An example of what not to do and how this relates to `read_unaligned` is: <br>一个不执行的操作以及它与 `read_unaligned` 的关系的示例是：<br>
///
/// ```
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// // Take the address of a 32-bit integer which is not aligned. <br>取一个未对齐的 32 位整数的地址。<br>
/// // In contrast to `&packed.unaligned as *const _`, this has no undefined behavior. <br>与 `&packed.unaligned as *const _` 相比，它没有未定义的行为。<br>
/// let unaligned = std::ptr::addr_of!(packed.unaligned);
///
/// let v = unsafe { std::ptr::read_unaligned(unaligned) };
/// assert_eq!(v, 0x01020304);
/// ```
///
/// Accessing unaligned fields directly with e.g. `packed.unaligned` is safe however. <br>但是，例如使用 `packed.unaligned` 直接访问未对齐的字段是安全的。<br>
///
/// # Examples
///
/// Read a usize value from a byte buffer: <br>从字节缓冲区读取 usize 值：<br>
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: the caller must guarantee that `src` is valid for reads. <br>调用者必须保证 `src` 对于读取有效。<br>
    // `src` cannot overlap `tmp` because `tmp` was just allocated on the stack as a separate allocated object. <br>`src` 不能与 `tmp` 重叠，因为 `tmp` 只是作为单独的分配对象在栈上分配的。<br>
    //
    //
    // Also, since we just wrote a valid value into `tmp`, it is guaranteed to be properly initialized. <br>另外，由于我们只是将有效值写入 `tmp`，因此可以确保正确初始化它。<br>
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Overwrites a memory location with the given value without reading or dropping the old value. <br>用给定值覆盖存储位置，而无需读取或丢弃旧值。<br>
///
/// `write` does not drop the contents of `dst`. <br>`write` 不会丢弃 `dst` 的内容。<br>
/// This is safe, but it could leak allocations or resources, so care should be taken not to overwrite an object that should be dropped. <br>这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。<br>
///
///
/// Additionally, it does not drop `src`. <br>此外，它不会丢弃 `src`。<br> Semantically, `src` is moved into the location pointed to by `dst`. <br>在语义上，`src` 被移到 `dst` 指向的位置。<br>
///
/// This is appropriate for initializing uninitialized memory, or overwriting memory that has previously been [`read`] from. <br>这适用于初始化未初始化的内存，或覆盖以前是 [`read`] 的内存。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `dst` must be [valid] for writes. <br>`dst` 必须是 [有效的][valid] 才能写入。<br>
///
/// * `dst` must be properly aligned. <br>`dst` 必须正确对齐。<br> Use [`write_unaligned`] if this is not the case. <br>如果不是这种情况，请使用 [`write_unaligned`]。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manually implement [`mem::swap`]: <br>手动实现 [`mem::swap`]：<br>
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Create a bitwise copy of the value at `a` in `tmp`. <br>在 `tmp` 中的 `a` 处创建值的按位副本。<br>
///         let tmp = ptr::read(a);
///
///         // Exiting at this point (either by explicitly returning or by calling a function which panics) would cause the value in `tmp` to be dropped while the same value is still referenced by `a`. <br>此时退出 (通过显式返回或调用 panics 的函数) 将导致 `tmp` 中的值被丢弃，而 `a` 仍引用相同的值。<br>
///         // This could trigger undefined behavior if `T` is not `Copy`. <br>如果 `T` 不是 `Copy`，则可能触发未定义的行为。<br>
/////
/////
///
///         // Create a bitwise copy of the value at `b` in `a`. <br>在 `a` 中的 `b` 处创建值的按位副本。<br>
///         // This is safe because mutable references cannot alias. <br>这是安全的，因为可变引用不能使用别名。<br>
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // As above, exiting here could trigger undefined behavior because the same value is referenced by `a` and `b`. <br>如上所述，退出此处可能会触发未定义的行为，因为 `a` 和 `b` 引用了相同的值。<br>
/////
///
///         // Move `tmp` into `b`. <br>将 `tmp` 移至 `b`。<br>
///         ptr::write(b, tmp);
///
///         // `tmp` has been moved (`write` takes ownership of its second argument), so nothing is dropped implicitly here. <br>`tmp` 已移动 (`write` 对其第二个参数的所有权)，因此这里没有隐含地丢弃任何东西。<br>
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "86302")]
pub const unsafe fn write<T>(dst: *mut T, src: T) {
    // We are calling the intrinsics directly to avoid function calls in the generated code as `intrinsics::copy_nonoverlapping` is a wrapper function. <br>我们直接调用内部函数是为了避免在生成的代码中调用函数，因为 `intrinsics::copy_nonoverlapping` 是一个包装函数。<br>
    //
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAFETY: the caller must guarantee that `dst` is valid for writes. <br>调用者必须保证 `dst` 对写入有效。<br>
    // `dst` cannot overlap `src` because the caller has mutable access to `dst` while `src` is owned by this function. <br>`dst` 不能与 `dst` 重叠，因为调用者拥有 `dst` 的权限，而 `src` 是这个函数拥有所有权的。<br>
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Overwrites a memory location with the given value without reading or dropping the old value. <br>用给定值覆盖存储位置，而无需读取或丢弃旧值。<br>
///
/// Unlike [`write()`], the pointer may be unaligned. <br>与 [`write()`] 不同，指针可能未对齐。<br>
///
/// `write_unaligned` does not drop the contents of `dst`. <br>`write_unaligned` 不会丢弃 `dst` 的内容。<br> This is safe, but it could leak allocations or resources, so care should be taken not to overwrite an object that should be dropped. <br>这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。<br>
///
/// Additionally, it does not drop `src`. <br>此外，它不会丢弃 `src`。<br> Semantically, `src` is moved into the location pointed to by `dst`. <br>在语义上，`src` 被移到 `dst` 指向的位置。<br>
///
/// This is appropriate for initializing uninitialized memory, or overwriting memory that has previously been read with [`read_unaligned`]. <br>这适用于初始化未初始化的内存，或覆盖以前用 [`read_unaligned`] 读取的内存。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `dst` must be [valid] for writes. <br>`dst` 必须是 [有效的][valid] 才能写入。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空。<br>
///
/// [valid]: self#safety
///
/// ## On `packed` structs <br>在 `packed` 结构体上<br>
///
/// Attempting to create a raw pointer to an `unaligned` struct field with an expression such as `&packed.unaligned as *const FieldType` creates an intermediate unaligned reference before converting that to a raw pointer. <br>尝试使用诸如 `&packed.unaligned as *const FieldType` 的表达式创建指向 `unaligned` 结构体字段的裸指针，然后再将其转换为裸指针，这会产生一个中间未对齐的引用。<br>
///
/// That this reference is temporary and immediately cast is inconsequential as the compiler always expects references to be properly aligned. <br>引用是临时的并且立即强制转换是无关紧要的，因为编译器始终希望引用正确对齐。<br>
/// As a result, using `&packed.unaligned as *const FieldType` causes immediate *undefined behavior* in your program. <br>结果，使用 `&packed.unaligned as *const FieldType` 会在程序中立即导致* undefined 行为 *。<br>
///
/// Instead you must use the [`ptr::addr_of_mut!`](addr_of_mut) macro to create the pointer. <br>相反，您必须使用 [`ptr::addr_of_mut!`](addr_of_mut) 宏来创建指针。<br> You may use that returned pointer together with this function. <br>您可以将返回的指针与此函数一起使用。<br>
///
/// An example of how to do it and how this relates to `write_unaligned` is: <br>如何做到这一点以及这与 `write_unaligned` 的关系的一个例子是：<br>
///
/// ```
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// // Take the address of a 32-bit integer which is not aligned. <br>取一个未对齐的 32 位整数的地址。<br>
/// // In contrast to `&packed.unaligned as *mut _`, this has no undefined behavior. <br>与 `&packed.unaligned as *mut _` 相比，它没有未定义的行为。<br>
/// let unaligned = std::ptr::addr_of_mut!(packed.unaligned);
///
/// unsafe { std::ptr::write_unaligned(unaligned, 42) };
///
/// assert_eq!({packed.unaligned}, 42); // `{...}` forces copying the field instead of creating a reference. <br>`{...}` 强制复制字段而不是创建引用。<br>
/// ```
///
/// Accessing unaligned fields directly with e.g. `packed.unaligned` is safe however (as can be seen in the `assert_eq!` above). <br>然而，直接使用例如 `packed.unaligned` 访问未对齐的字段是安全的 (如上面的 `assert_eq!` 所示)。<br>
///
/// # Examples
///
/// Write a usize value to a byte buffer: <br>将 usize 值写入字节缓冲区：<br>
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "86302")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAFETY: the caller must guarantee that `dst` is valid for writes. <br>调用者必须保证 `dst` 对写入有效。<br>
    // `dst` cannot overlap `src` because the caller has mutable access to `dst` while `src` is owned by this function. <br>`dst` 不能与 `dst` 重叠，因为调用者拥有 `dst` 的权限，而 `src` 是这个函数拥有所有权的。<br>
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // We are calling the intrinsic directly to avoid function calls in the generated code. <br>我们直接调用内部函数以避免在生成的代码中进行函数调用。<br>
        intrinsics::forget(src);
    }
}

/// Performs a volatile read of the value from `src` without moving it. <br>对 `src` 的值进行易失性读取，而无需移动它。<br> This leaves the memory in `src` unchanged. <br>这将使 `src` 中的内存保持不变。<br>
///
/// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elided or reordered by the compiler across other volatile operations. <br>易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。<br>
///
/// # Notes
///
/// Rust does not currently have a rigorously and formally defined memory model, so the precise semantics of what "volatile" means here is subject to change over time. <br>Rust 当前没有严格和正式定义的内存模型，因此 "volatile" 此处所指的确切语义会随时间而变化。<br>
/// That being said, the semantics will almost always end up pretty similar to [C11's definition of volatile][c11]. <br>话虽如此，其语义几乎总是以与 [C11 对 volatile 的定义][c11] 相似的方式结束。<br>
///
/// The compiler shouldn't change the relative order or number of volatile memory operations. <br>编译器不应更改易失性存储器操作的相对顺序或数量。<br>
/// However, volatile memory operations on zero-sized types (e.g., if a zero-sized type is passed to `read_volatile`) are noops and may be ignored. <br>但是，零大小类型 (例如，如果将零大小类型传递给 `read_volatile`) 上的易失性存储器操作为无操作，可以忽略。<br>
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `src` must be [valid] for reads. <br>`src` 必须是 [有效的][valid] 才能读取。<br>
///
/// * `src` must be properly aligned. <br>`src` 必须正确对齐。<br>
///
/// * `src` must point to a properly initialized value of type `T`. <br>`src` 必须指向 `T` 类型的正确初始化值。<br>
///
/// Like [`read`], `read_volatile` creates a bitwise copy of `T`, regardless of whether `T` is [`Copy`]. <br>与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`read_volatile` 都会创建 `T` 的按位副本。<br>
/// If `T` is not [`Copy`], using both the returned value and the value at `*src` can [violate memory safety][read-ownership]. <br>如果 `T` 不是 [`Copy`]，则同时使用返回值和 `*src` 处的值都可以 [违反内存安全][read-ownership]。<br>
/// However, storing non-[`Copy`] types in volatile memory is almost certainly incorrect. <br>但是，几乎可以肯定地将非 [`Copy`] 类型存储在易失性存储器中。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Just like in C, whether an operation is volatile has no bearing whatsoever on questions involving concurrent access from multiple threads. <br>就像在 C 语言中一样，操作是否易失性与涉及从多个线程进行并发访问的问题无关。<br> Volatile accesses behave exactly like non-atomic accesses in that regard. <br>在这方面，易失性访问的行为与非原子访问完全相同。<br>
///
/// In particular, a race between a `read_volatile` and any write operation to the same location is undefined behavior. <br>特别是，`read_volatile` 与任何对同一位置的写操作之间的争夺是未定义的行为。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    // SAFETY: the caller must uphold the safety contract for `volatile_load`. <br>调用者必须遵守 `volatile_load` 的安全保证。<br>
    unsafe {
        assert_unsafe_precondition!(is_aligned_and_not_null(src));
        intrinsics::volatile_load(src)
    }
}

/// Performs a volatile write of a memory location with the given value without reading or dropping the old value. <br>使用给定值对存储单元执行易失性写操作，而无需读取或丢弃旧值。<br>
///
/// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elided or reordered by the compiler across other volatile operations. <br>易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。<br>
///
/// `write_volatile` does not drop the contents of `dst`. <br>`write_volatile` 不会丢弃 `dst` 的内容。<br> This is safe, but it could leak allocations or resources, so care should be taken not to overwrite an object that should be dropped. <br>这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。<br>
///
/// Additionally, it does not drop `src`. <br>此外，它不会丢弃 `src`。<br> Semantically, `src` is moved into the location pointed to by `dst`. <br>在语义上，`src` 被移到 `dst` 指向的位置。<br>
///
/// # Notes
///
/// Rust does not currently have a rigorously and formally defined memory model, so the precise semantics of what "volatile" means here is subject to change over time. <br>Rust 当前没有严格和正式定义的内存模型，因此 "volatile" 此处所指的确切语义会随时间而变化。<br>
/// That being said, the semantics will almost always end up pretty similar to [C11's definition of volatile][c11]. <br>话虽如此，其语义几乎总是以与 [C11 对 volatile 的定义][c11] 相似的方式结束。<br>
///
/// The compiler shouldn't change the relative order or number of volatile memory operations. <br>编译器不应更改易失性存储器操作的相对顺序或数量。<br>
/// However, volatile memory operations on zero-sized types (e.g., if a zero-sized type is passed to `write_volatile`) are noops and may be ignored. <br>但是，零大小类型 (例如，如果将零大小类型传递给 `write_volatile`) 上的易失性存储器操作为无操作，可以忽略。<br>
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `dst` must be [valid] for writes. <br>`dst` 必须是 [有效的][valid] 才能写入。<br>
///
/// * `dst` must be properly aligned. <br>`dst` 必须正确对齐。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
///
/// Just like in C, whether an operation is volatile has no bearing whatsoever on questions involving concurrent access from multiple threads. <br>就像在 C 语言中一样，操作是否易失性与涉及从多个线程进行并发访问的问题无关。<br> Volatile accesses behave exactly like non-atomic accesses in that regard. <br>在这方面，易失性访问的行为与非原子访问完全相同。<br>
///
/// In particular, a race between a `write_volatile` and any other operation (reading or writing) on the same location is undefined behavior. <br>特别是，`write_volatile` 与同一位置上的任何其他操作 (读取或写入) 之间的争夺是未定义的行为。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    // SAFETY: the caller must uphold the safety contract for `volatile_store`. <br>调用者必须遵守 `volatile_store` 的安全保证。<br>
    unsafe {
        assert_unsafe_precondition!(is_aligned_and_not_null(dst));
        intrinsics::volatile_store(dst, src);
    }
}

/// Align pointer `p`. <br>对齐指针 `p`。<br>
///
/// Calculate offset (in terms of elements of `stride` stride) that has to be applied to pointer `p` so that pointer `p` would get aligned to `a`. <br>计算必须应用于指针 `p` 的偏移量 (根据 `stride` 步幅)，以便指针 `p` 与 `a` 对齐。<br>
///
/// Note: This implementation has been carefully tailored to not panic. <br>此实现已针对非 panic 进行了精心设计。<br> It is UB for this to panic. <br>到 panic 是 UB。<br>
/// The only real change that can be made here is change of `INV_TABLE_MOD_16` and associated constants. <br>此处唯一可以进行的更改是 `INV_TABLE_MOD_16` 及其关联常量的更改。<br>
///
/// If we ever decide to make it possible to call the intrinsic with `a` that is not a power-of-two, it will probably be more prudent to just change to a naive implementation rather than trying to adapt this to accommodate that change. <br>如果我们决定可以使用不是二次幂的 `a` 来调用内部函数，那么可能更谨慎的做法是只更改为一个简单的实现，而不是尝试调整它以适应这种更改。<br>
///
///
/// Any questions go to @nagisa. <br>如有任何疑问，请发送至 @nagisa。<br>
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Direct use of these intrinsics improves codegen significantly at opt-level <= <br>直接使用这些内部函数可以显着提高 codegen 在 opt-level <=<br>
    // 1, where the method versions of these operations are not inlined. <br>1，其中未内联这些操作的方法版本。<br>
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    let addr = p.addr();

    /// Calculate multiplicative modular inverse of `x` modulo `m`. <br>计算 `x` 模 `m` 的乘法模逆。<br>
    ///
    /// This implementation is tailored for `align_offset` and has following preconditions: <br>此实现是针对 `align_offset` 量身定制的，并具有以下先决条件：<br>
    ///
    /// * `m` is a power-of-two; <br>`m` 是二的幂；<br>
    /// * `x < m`; (if `x ≥ m`, pass in `x % m` instead) <br>(如果使用 `x ≥ m`，请改为传入 `x % m`)<br>
    ///
    /// Implementation of this function shall not panic. <br>此函数的实现不得为 panic。<br> Ever.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplicative modular inverse table modulo 2⁴ = 16. <br>乘模逆矩阵模 2⁴=16。<br>
        ///
        /// Note, that this table does not contain values where inverse does not exist (i.e., for `0⁻¹ mod 16`, `2⁻¹ mod 16`, etc.) <br>注意，该表不包含不存在反值的值 (例如，对于 `0⁻¹ mod 16`，`2⁻¹ mod 16` 等)。<br>
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo for which the `INV_TABLE_MOD_16` is intended. <br>`INV_TABLE_MOD_16` 的模数。<br>
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SAFETY: `m` is required to be a power-of-two, hence non-zero. <br>`m` 必须为 2 的幂，因此不能为零。<br>
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // We iterate "up" using the following formula: <br>我们使用以下公式迭代 "up"：<br>
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2 - xy) ≡ 1 (mod 2²ⁿ)  $$
            //
            // until 2²ⁿ ≥ m. <br>直到 2²ⁿ ≥ m。<br> Then we can reduce to our desired `m` by taking the result `mod m`. <br>然后，我们可以通过取结果 `mod m` 减少到所需的 `m`。<br>
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y = y * (2 - xy) mod n
                //
                // Note, that we use wrapping operations here intentionally – the original formula uses e.g., subtraction `mod n`. <br>注意，这里我们有意使用包装操作 - 原始公式使用减法 `mod n`。<br>
                // It is entirely fine to do them `mod usize::MAX` instead, because we take the result `mod n` at the end anyway. <br>改用 `mod usize::MAX` 完全可以，因为无论如何我们将结果 `mod n` 放在最后。<br>
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: `a` is a power-of-two, therefore non-zero. <br>`a` 为 2 的幂，因此非零。<br>
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case can be computed more simply through `-p (mod a)`, but doing so inhibits LLVM's ability to select instructions like `lea`. <br>`stride == 1` case 可以通过 `-p (mod a)` 更简单地计算，但这样做会抑制 LLVM 选择像 `lea` 这样的指令的能力。<br> Instead we compute <br>相反，我们计算<br>
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // which distributes operations around the load-bearing, but pessimizing `and` sufficiently for LLVM to be able to utilize the various optimizations it knows about. <br>它围绕承重来分配操作，但是对 `and` 进行了充分的模拟，以使 LLVM 能够利用它所了解的各种优化。<br>
        //
        //
        return wrapping_sub(wrapping_add(addr, a_minus_one) & wrapping_sub(0, a), addr);
    }

    let pmoda = addr & a_minus_one;
    if pmoda == 0 {
        // Already aligned. <br>已经对齐。<br> Yay!
        return 0;
    } else if stride == 0 {
        // If the pointer is not aligned, and the element is zero-sized, then no amount of elements will ever align the pointer. <br>如果指针未对齐，并且元素大小为零，则将没有任何元素可以对齐指针。<br>
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SAFETY: a is power-of-two hence non-zero. <br>a 是 2 的幂，因此非零。<br> stride == 0 case is handled above. <br>stride == 0 情况已在上面处理。<br>
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: gcdpow has an upper-bound that’s at most the number of bits in a usize. <br>gcdpow 有一个上限，最多是 usize 中的位数。<br>
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAFETY: gcd is always greater or equal to 1. <br>gcd 始终大于或等于 1。<br>
    if addr & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // This branch solves for the following linear congruence equation: <br>该分支求解以下线性同余方程：<br>
        //
        // ` p + so = 0 mod a `
        //
        // `p` here is the pointer value, `s` - stride of `T`, `o` offset in `T`s, and `a` - the requested alignment. <br>这里的 `p` 是指针值，`s`-`T` 的步幅，`T` 中的 `o` 偏移量，以及 `a` - 请求的对齐方式。<br>
        //
        // With `g = gcd(a, s)`, and the above condition asserting that `p` is also divisible by `g`, we can denote `a' = a/g`, `s' = s/g`, `p' = p/g`, then this becomes equivalent to: <br>使用 `g = gcd(a, s)`，并且上面的条件断言 `p` 也可以被 `g` 整除，我们可以表示 `a' = a/g`，`s' = s/g`，`p' = p/g`，那么它等效于：<br>
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // The first term is "the relative alignment of `p` to `a`" (divided by the `g`), the second term is "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (again divided by `g`). <br>第一项是 "the relative alignment of `p` to `a`" (除以 `g`)，第二项是 "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (再次除以 `g`)。<br>
        //
        // Division by `g` is necessary to make the inverse well formed if `a` and `s` are not co-prime. <br>如果 `a` 和 `s` 不是互质的，则 `g` 的除法对于使逆结构良好是必要的。<br>
        //
        // Furthermore, the result produced by this solution is not "minimal", so it is necessary to take the result `o mod lcm(s, a)`. <br>此外，此解决方案产生的结果不是 "minimal"，因此必须获得结果 `o mod lcm(s, a)`。<br> We can replace `lcm(s, a)` with just a `a'`. <br>我们可以只用 `a'` 代替 `lcm(s, a)`。<br>
        //
        //
        //
        //
        //

        // SAFETY: `gcdpow` has an upper-bound not greater than the number of trailing 0-bits in `a`. <br>`gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。<br>
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAFETY: `a2` is non-zero. <br>`a2` 不为零。<br>
        // Shifting `a` by `gcdpow` cannot shift out any of the set bits in `a` (of which it has exactly one). <br>将 `a` 移位 `gcdpow` 不能移出 `a` 中的任何设置位 (其中只有一位)。<br>
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAFETY: `gcdpow` has an upper-bound not greater than the number of trailing 0-bits in `a`. <br>`gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。<br>
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAFETY: `gcdpow` has an upper-bound not greater than the number of trailing 0-bits in `a`. <br>`gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。<br>
        // Furthermore, the subtraction cannot overflow, because `a2 = a >> gcdpow` will always be strictly greater than `(p % a) >> gcdpow`. <br>此外，减法不会溢出，因为 `a2 = a >> gcdpow` 将始终严格大于 `(p % a) >> gcdpow`。<br>
        //
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: `a2` is a power-of-two, as proven above. <br>如上所述，`a2` 是 2 的幂。<br>
        // `s2` is strictly less than `a2` because `(s % a) >> gcdpow` is strictly less than `a >> gcdpow`. <br>`s2` 严格小于 `a2`，因为 `(s % a) >> gcdpow` 严格小于 `a >> gcdpow`。<br>
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Cannot be aligned at all. <br>根本无法对齐。<br>
    usize::MAX
}

/// Compares raw pointers for equality. <br>比较裸指针是否相等。<br>
///
/// This is the same as using the `==` operator, but less generic: <br>这与使用 `==` 运算符相同，但泛型较少：<br>
/// the arguments have to be `*const T` raw pointers, not anything that implements `PartialEq`. <br>参数必须是 `*const T` 裸指针，而不是任何实现 `PartialEq` 的东西。<br>
///
/// This can be used to compare `&T` references (which coerce to `*const T` implicitly) by their address rather than comparing the values they point to (which is what the `PartialEq for &T` implementation does). <br>这可用于按地址比较 `&T` 引用 (隐式强制为 `*const T`)，而不是比较它们指向的值 (`PartialEq for &T` 实现的作用)。<br>
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Slices are also compared by their length (fat pointers): <br>切片还通过它们的长度 (胖指针) 进行比较：<br>
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits are also compared by their implementation: <br>还可以通过 traits 的实现进行比较：<br>
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Pointers have equal addresses. <br>指针具有相等的地址。<br>
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objects have equal addresses, but `Trait` has different implementations. <br>对象具有相等的地址，但是 `Trait` 具有不同的实现。<br>
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Converting the reference to a `*const u8` compares by address. <br>将引用转换为 `*const u8` 时，将按地址进行比较。<br>
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash a raw pointer. <br>散列一个裸指针。<br>
///
/// This can be used to hash a `&T` reference (which coerces to `*const T` implicitly) by its address rather than the value it points to (which is what the `Hash for &T` implementation does). <br>这可用于通过其地址而不是其指向的值 (`Hash for &T` 实现的作用) 对 `&T` 引用 (隐式强制为 `*const T`) 进行哈希处理。<br>
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// FIXME(strict_provenance_magic): function pointers have buggy codegen that necessitates casting to a usize to get the backend to do the right thing. <br>函数指针有错误的代码生成，这需要强制转换为 usize 才能让后端做正确的事情。<br>
//
// for now I will break AVR to silence *a billion* lints. <br>现在我将打破 AVR，以使 *10 亿* lints 安静下来。<br>
// We should probably have a proper "opaque function pointer type" to handle this kind of thing. <br>我们可能应该有一个合适的 "不透明函数指针类型" 来处理这种事情。<br>

// Impls for function pointers <br>函数指针的 Impls<br>
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: The intermediate cast as usize is required for AVR so that the address space of the source function pointer is preserved in the final function pointer. <br>AVR 需要使用 asize 中间转换，以便将源函数指针的地址空间保留在最终函数指针中。<br>
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                //
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: The intermediate cast as usize is required for AVR so that the address space of the source function pointer is preserved in the final function pointer. <br>AVR 需要使用 asize 中间转换，以便将源函数指针的地址空间保留在最终函数指针中。<br>
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                //
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // No variadic functions with 0 parameters <br>没有参数为 0 的可变参数函数<br>
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Create a `const` raw pointer to a place, without creating an intermediate reference. <br>创建一个 `const` 裸指针到一个位置，而无需创建中间引用。<br>
///
/// Creating a reference with `&`/`&mut` is only allowed if the pointer is properly aligned and points to initialized data. <br>仅当指针正确对齐并指向初始化数据时，才允许使用 `&`/`&mut` 创建引用。<br>
/// For cases where those requirements do not hold, raw pointers should be used instead. <br>对于那些不满足要求的情况，应改用裸指针。<br>
/// However, `&expr as *const _` creates a reference before casting it to a raw pointer, and that reference is subject to the same rules as all other references. <br>但是，`&expr as *const _` 在将其强制转换为裸指针之前会创建一个引用，并且该引用与所有其他引用都遵循相同的规则。<br>
///
/// This macro can create a raw pointer *without* creating a reference first. <br>该宏可以创建一个裸指针，而无需先创建一个引用。<br>
///
/// Note, however, that the `expr` in `addr_of!(expr)` is still subject to all the usual rules. <br>但是请注意，`addr_of!(expr)` 中的 `expr` 仍受所有常规规则的约束。<br>
/// In particular, `addr_of!(*ptr::null())` is Undefined Behavior because it dereferences a null pointer. <br>特别是，`addr_of!(*ptr::null())` 是未定义行为，因为它解引用空指针。<br>
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` would create an unaligned reference, and thus be Undefined Behavior! <br>`&packed.f2` 会创建一个未对齐的引用，因此是未定义的行为！<br>
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
/// See [`addr_of_mut`] for how to create a pointer to unininitialized data. <br>有关如何创建指向未初始化数据的指针，请参见 [`addr_of_mut`]。<br>
/// Doing that with `addr_of` would not make much sense since one could only read the data, and that would be Undefined Behavior. <br>用 `addr_of` 这样做没有多大意义，因为人们只能读取数据，这将是未定义行为。<br>
///
///
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Create a `mut` raw pointer to a place, without creating an intermediate reference. <br>创建一个 `mut` 裸指针到一个位置，而无需创建中间引用。<br>
///
/// Creating a reference with `&`/`&mut` is only allowed if the pointer is properly aligned and points to initialized data. <br>仅当指针正确对齐并指向初始化数据时，才允许使用 `&`/`&mut` 创建引用。<br>
/// For cases where those requirements do not hold, raw pointers should be used instead. <br>对于那些不满足要求的情况，应改用裸指针。<br>
/// However, `&mut expr as *mut _` creates a reference before casting it to a raw pointer, and that reference is subject to the same rules as all other references. <br>但是，`&mut expr as *mut _` 在将其强制转换为裸指针之前会创建一个引用，并且该引用与所有其他引用都遵循相同的规则。<br>
///
/// This macro can create a raw pointer *without* creating a reference first. <br>该宏可以创建一个裸指针，而无需先创建一个引用。<br>
///
/// Note, however, that the `expr` in `addr_of_mut!(expr)` is still subject to all the usual rules. <br>但请注意，`addr_of_mut!(expr)` 中的 `expr` 仍受所有常规规则的约束。<br>
/// In particular, `addr_of_mut!(*ptr::null_mut())` is Undefined Behavior because it dereferences a null pointer. <br>特别是，`addr_of_mut!(*ptr::null_mut())` 是未定义行为，因为它解引用空指针。<br>
///
/// # Examples
///
/// **Creating a pointer to unaligned data: <br>创建指向未对齐数据的指针：<br>**
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` would create an unaligned reference, and thus be Undefined Behavior! <br>`&mut packed.f2` 会创建一个未对齐的引用，因此是未定义的行为！<br>
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` forces copying the field instead of creating a reference. <br>`{...}` 强制复制字段而不是创建引用。<br>
/// ```
///
/// **Creating a pointer to uninitialized data: <br>创建指向未初始化数据的指针：<br>**
///
/// ```rust
/// use std::{ptr, mem::MaybeUninit};
///
/// struct Demo {
///     field: bool,
/// }
///
/// let mut uninit = MaybeUninit::<Demo>::uninit();
/// // `&uninit.as_mut().field` would create a reference to an uninitialized `bool`, and thus be Undefined Behavior! <br>`&uninit.as_mut().field` 会创建一个对未初始化的 `bool` 的引用，因此是未定义的行为！<br>
/////
/// let f1_ptr = unsafe { ptr::addr_of_mut!((*uninit.as_mut_ptr()).field) };
/// unsafe { f1_ptr.write(true); }
/// let init = unsafe { uninit.assume_init() };
/// ```
///
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}
