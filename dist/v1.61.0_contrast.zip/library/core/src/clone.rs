//! The `Clone` trait for types that cannot be 'implicitly copied'. <br>不能隐式复制的类型的 `Clone` trait。<br>
//!
//! In Rust, some simple types are "implicitly copyable" and when you assign them or pass them as arguments, the receiver will get a copy, leaving the original value in place. <br>在 Rust 中，一些简单类型是 "隐式可复制的"，当您分配它们或将它们作为参数传递时，接收者将获得一个副本，而将原始值保留在原位。<br>
//! These types do not require allocation to copy and do not have finalizers (i.e., they do not contain owned boxes or implement [`Drop`]), so the compiler considers them cheap and safe to copy. <br>这些类型不需要分配就可以复制并且没有终结器 (即，它们不包含拥有的 boxes 或实现 [`Drop`])，因此编译器认为它们便宜且安全地进行复制。<br>
//!
//! For other types copies must be made explicitly, by convention implementing the [`Clone`] trait and calling the [`clone`] method. <br>对于其他类型，必须通过约定实现 [`Clone`] trait 并调用 [`clone`] 方法来显式复制。<br>
//!
//! [`clone`]: Clone::clone
//!
//! Basic usage example: <br>基本用法示例：<br>
//!
//! ```
//! let s = String::new(); // String type implements Clone <br>字符串类型实现克隆<br>
//! let copy = s.clone(); // so we can clone it <br>所以我们可以克隆它<br>
//! ```
//!
//! To easily implement the Clone trait, you can also use `#[derive(Clone)]`. <br>要轻松实现 Clone trait，还可以使用 `#[derive(Clone)]`。<br> Example:
//!
//! ```
//! #[derive(Clone)] // we add the Clone trait to Morpheus struct <br>我们将克隆 trait 添加到 Morpheus 结构体<br>
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // and now we can clone it! <br>现在我们可以克隆它了！<br>
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::marker::Destruct;

/// A common trait for the ability to explicitly duplicate an object. <br>通用的 trait，用于显式复制对象。<br>
///
/// Differs from [`Copy`] in that [`Copy`] is implicit and an inexpensive bit-wise copy, while `Clone` is always explicit and may or may not be expensive. <br>与 [`Copy`] 的不同之处在于 [`Copy`] 是隐式的并且是廉价的按位复制，而 `Clone` 始终是显式的并且可能昂贵也可能不昂贵。<br>
/// In order to enforce these characteristics, Rust does not allow you to reimplement [`Copy`], but you may reimplement `Clone` and run arbitrary code. <br>为了强制执行这些特性，Rust 不允许您重新实现 [`Copy`]，但是您可以重新实现 `Clone` 并运行任意代码。<br>
///
/// Since `Clone` is more general than [`Copy`], you can automatically make anything [`Copy`] be `Clone` as well. <br>由于 `Clone` 比 [`Copy`] 更通用，因此您可以自动将 [`Copy`] 设为 `Clone`。<br>
///
/// ## Derivable
///
/// This trait can be used with `#[derive]` if all fields are `Clone`. <br>如果所有字段均为 `Clone`，则此 trait 可以与 `#[derive]` 一起使用。<br> The `derive`d implementation of [`Clone`] calls [`clone`] on each field. <br>[`Clone`] 的 `derive`d 实现在每个字段上调用 [`clone`]。<br>
///
/// [`clone`]: Clone::clone
///
/// For a generic struct, `#[derive]` implements `Clone` conditionally by adding bound `Clone` on generic parameters. <br>对于泛型结构体，`#[derive]` 通过在泛型参数上添加绑定的 `Clone` 有条件地实现 `Clone`。<br>
///
/// ```
/// // `derive` implements Clone for Reading<T> when T is Clone. <br>当 T 是 Clone 时，`derive` 为 Reading<T> 实现了 Clone。<br>
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## How can I implement `Clone`? <br>如何实现 `Clone`？<br>
///
/// Types that are [`Copy`] should have a trivial implementation of `Clone`. <br>[`Copy`] 类型应该实现 `Clone` 的简单实现。<br> More formally: <br>更正式地：<br>
/// if `T: Copy`, `x: T`, and `y: &T`, then `let x = y.clone();` is equivalent to `let x = *y;`. <br>如果 `T: Copy`，`x: T` 和 `y: &T`，则 `let x = y.clone();` 等效于 `let x = *y;`。<br>
/// Manual implementations should be careful to uphold this invariant; <br>手动执行时应注意保持不变。<br> however, unsafe code must not rely on it to ensure memory safety. <br>但是，不安全的代码一定不能依靠它来确保内存安全。<br>
///
/// An example is a generic struct holding a function pointer. <br>一个示例是持有函数指针的泛型结构体。<br> In this case, the implementation of `Clone` cannot be `derive`d, but can be implemented as: <br>在这种情况下，不能对 `Clone` 的实现进行派生操作，而可以将其实现为：<br>
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Additional implementors <br>其他实现者<br>
///
/// In addition to the [implementors listed below][impls], the following types also implement `Clone`: <br>除了下面列出的 [实现者][impls] 外，以下类型还实现了 `Clone`：<br>
///
/// * Function item types (i.e., the distinct types defined for each function) <br>函数项类型 (即，为每个函数定义的不同类型)<br>
/// * Function pointer types (e.g., `fn() -> i32`) <br>函数指针类型 (例如 `fn() -> i32`)<br>
/// * Tuple types, if each component also implements `Clone` (e.g., `()`, `(i32, bool)`) <br>如果每个组件还实现 `Clone` (例如 `()`，`(i32, bool)`)，则为元组类型<br>
/// * Closure types, if they capture no value from the environment or if all such captured values implement `Clone` themselves. <br>闭包类型，如果它们没有从环境中捕获任何值，或者所有此类捕获的值本身都实现了 `Clone`。<br>
///   Note that variables captured by shared reference always implement `Clone` (even if the referent doesn't), while variables captured by mutable reference never implement `Clone`. <br>请注意，由共享引用捕获的变量始终实现 `Clone` (即使引用对象没有实现)，而由变量引用捕获的变量从不实现 `Clone`。<br>
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
#[rustc_trivial_field_reads]
pub trait Clone: Sized {
    /// Returns a copy of the value. <br>返回值的副本。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implements Clone <br>&str 实现克隆<br>
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Performs copy-assignment from `source`. <br>从 `source` 执行复制分配。<br>
    ///
    /// `a.clone_from(&b)` is equivalent to `a = b.clone()` in functionality, but can be overridden to reuse the resources of `a` to avoid unnecessary allocations. <br>`a.clone_from(&b)` 在功能上等同于 `a = b.clone()`，但可以被覆盖以重用 `a` 的资源以避免不必要的分配。<br>
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[default_method_body_is_const]
    #[cfg_attr(not(bootstrap), allow(drop_bounds))] // FIXME remove `~const Drop` and this attr when bumping <br>当碰撞时移除 `~const Drop` 和这个属性<br>
    fn clone_from(&mut self, source: &Self)
    where
        Self: ~const Drop + ~const Destruct,
    {
        *self = source.clone()
    }
}

/// Derive macro generating an impl of the trait `Clone`. <br>派生宏，生成 `Clone` trait 的 impl。<br>
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): these structs are used solely by #[derive] to assert that every component of a type implements Clone or Copy. <br>这些结构仅由 #[derivate] 用来断言类型的每个组件都实现了 Clone 或 Copy。<br>
//
//
// These structs should never appear in user code. <br>这些结构体永远不会出现在用户代码中。<br>
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementations of `Clone` for primitive types. <br>原始类型的 `Clone` 实现。<br>
///
/// Implementations that cannot be described in Rust are implemented in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection`. <br>`rustc_trait_selection` 中的 `traits::SelectionContext::copy_clone_conditions()` 中实现了 Rust 中无法描述的实现。<br>
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                #[rustc_const_unstable(feature = "const_clone", issue = "91805")]
                impl const Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    #[rustc_const_unstable(feature = "const_clone", issue = "91805")]
    impl const Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_clone", issue = "91805")]
    impl<T: ?Sized> const Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_clone", issue = "91805")]
    impl<T: ?Sized> const Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Shared references can be cloned, but mutable references *cannot*! <br>共享的引用可以被克隆，但是可变引用 *不能*!<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_clone", issue = "91805")]
    impl<T: ?Sized> const Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Shared references can be cloned, but mutable references *cannot*! <br>共享的引用可以被克隆，但是可变引用 *不能*!<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}
